# Fix 01 — Transient `MissingEma` guard on low-volume xyz / stock markets

**File touched:** `src/passivbot.py` (only)
**Companion tests:** `tests/test_orchestrator_ema_retry.py`
**Bundle commit:** `e282552`
**Applies to:** any live run on a Hyperliquid HIP-3 / xyz stock-index market
(`xyz:SP500`, `xyz:NVDA`, …) or any market that has minutes with **no trades**.
**Never fires on:** 24/7 crypto perps (they never synthesize candles).

---

## 1. Symptom

While running the live engine on `xyz:SP500` (especially nights/weekends when the
underlying cash market is closed and the perp prints sparse, zero-volume minutes), the
loop logs a hard error with a Rust traceback roughly every ~1-in-3 candle backfills:

```
ERROR  error with run_execution_loop orchestrator compute_ideal_orders failed: MissingEma { symbol_idx: 0 }
Traceback (most recent call last):
  ...
ValueError: orchestrator compute_ideal_orders failed: MissingEma { symbol_idx: 0 }
```

It is **benign in effect** — the loop's generic `except Exception` already catches it,
sleeps, and retries next cycle, so resting orders are left untouched and nothing is
mis-traded. But it is logged as an `ERROR` with a full traceback, inflates the
`errors=` health counter, and looks alarming. The fix turns this specific, self-healing
condition into a quiet, expected skip.

A few seconds before each error you will see the candle manager's fingerprints:

```
[candle] xyz:SP500: synthesized 1 zero-candle at <ts> (no trades from exchange) using prev_close=7371.610000
[candle] xyz:SP500: real data replaced 1 synthetic candle, EMA cache invalidated
```

That second line — **EMA cache invalidated** — is the trigger.

---

## 2. Root cause

The Rust order orchestrator (`pbr.compute_ideal_orders_json`) requires a non-empty set
of **close-EMAs** for every symbol that has a position or an active (non-`manual`) mode.
If the close-EMA list for a symbol arrives empty, Rust raises
`MissingEma { symbol_idx: N }`.

On a low-volume market the close-EMA list goes momentarily empty through this race:

1. A minute passes with **no trades** from the exchange. `CandlestickManager`
   **synthesizes a zero-volume candle** (`prev_close` carried forward) so the series
   has no gap. (`src/candlestick_manager.py`, log line `synthesized N zero-candle`.)
2. Real trade data for that minute later **backfills**. `_check_synthetic_replacement`
   detects the replacement and calls `_invalidate_ema_cache(symbol)`
   (`src/candlestick_manager.py:1635-1655`, log line `real data replaced N synthetic
   candle, EMA cache invalidated`).
3. In the **brief window** right after invalidation, a candle read can return an empty
   range, so `cm.get_latest_ema_close(...)` yields **NaN**.
4. In `_load_orchestrator_ema_bundle`, `fetch_map` **drops every non-finite EMA**
   (`if math.isfinite(val)`), so the symbol's close-EMA dict comes back **`{}`**.
5. `calc_ideal_orders_orchestrator` feeds that empty `close` list to Rust →
   **`MissingEma`** → surfaces as a `ValueError` in the live loop.

The recompute settles within ~1 second, so the condition is genuinely transient.
24/7 crypto perps never hit step 1 (every minute has trades → no synthetic candles →
no invalidation), which is why this bug is xyz/stock-specific.

---

## 3. The fix, layer by layer

Five small additions to `src/passivbot.py`. All edits are anchored by **function /
symbol names and nearby code**, not line numbers (which drift between clones).

### 3a. Module-level: a typed exception, an error classifier, and a detection helper

Add these **at module scope** (top of the file, near other module-level helpers —
in this bundle they sit just above the `_trailing_bundle_tuple_to_dict` helper, after
the `get_function_name`-style helpers). The exception **must not** subclass
`ValueError`, so the loop's existing `except ValueError`/`except Exception` paths don't
swallow it before our typed handler runs.

```python
class TransientEmaUnavailable(Exception):
    """Raised when the Rust orchestrator cannot compute orders because the close-EMAs are
    momentarily unavailable. This is benign and self-healing: the candle manager invalidates
    the EMA cache when it backfills a synthetic (zero-volume) candle with real data on a
    low-volume xyz/stock market, and a candle read in that brief window can return an empty
    range, yielding NaN EMAs -> the orchestrator raises MissingEma. The live loop treats this
    as a skipped cycle (resting orders left untouched, retried next cycle) instead of a hard
    error. On 24/7 crypto perps candles are never synthesized, so this never fires there."""


def _is_missing_ema_error(exc: BaseException) -> bool:
    """True if `exc` is the Rust orchestrator's transient 'MissingEma' failure."""
    return isinstance(exc, ValueError) and "MissingEma" in str(exc)


def _symbols_missing_close_emas(symbols, need_close_spans, m1_close_emas) -> list:
    """Symbols that REQUIRE close-EMAs (need_close_spans non-empty) but whose close-EMA map came
    back empty — the signature of the post-cache-invalidation race that triggers MissingEma."""
    return [s for s in symbols if need_close_spans.get(s) and not m1_close_emas.get(s)]
```

> **Why a free `_is_missing_ema_error` instead of `except ... as e: "MissingEma" in str(e)`?**
> So we classify *only* the Rust `ValueError` carrying that exact text, and never
> swallow an unrelated `RuntimeError`/`Exception` that happens to mention the word. The
> companion tests assert exactly this (right text + wrong type ⇒ `False`).

### 3b. `__init__`: a health counter

In the bot's `__init__`, alongside the other `_health_*` counters
(`_health_orders_placed`, `_health_errors`, `_health_ws_reconnects`, …), add:

```python
self._health_ema_skips = 0  # benign cycles skipped due to momentarily-unavailable EMAs
```

(No need to initialize `_ema_recompute_retry_delay_s` — it is read with a `getattr`
default of `0.75` seconds; set it as an attribute only if you want to override the
retry delay, e.g. tests set it to `0.0`.)

### 3c. `_log_health_summary`: surface the counter

In the `logging.info("[health] …")` call, add `ema_skips=%d` to the format string
(between `errors=%d` and `ws_reconnects=%d`) and pass
`getattr(self, "_health_ema_skips", 0)` as the matching argument. Resulting line:

```python
logging.info(
    "[health] uptime=%s | positions=%d long, %d short | balance=%s | "
    "orders_placed=%d | orders_cancelled=%d | %s | errors=%d | ema_skips=%d | "
    "ws_reconnects=%d | rate_limits=%d",
    uptime_str, n_long, n_short, balance_str,
    self._health_orders_placed, self._health_orders_cancelled, fills_str,
    self._health_errors,
    getattr(self, "_health_ema_skips", 0),
    self._health_ws_reconnects, self._health_rate_limits,
)
```

### 3d. `_load_orchestrator_ema_bundle`: re-fetch close-EMAs once (first line of defense)

In `_load_orchestrator_ema_bundle`, **after** all four EMA maps have been awaited
(the loop that does `m1_close_emas[sym] = await close_tasks[sym]` etc.) and **before**
the `volumes_long`/`log_ranges_long` convenience lines and the final `return`, insert
the retry block. It re-fetches *only* the mandatory close spans for *only* the symbols
that came back empty, after a short sleep to let the recompute settle:

```python
# Transient-EMA guard for low-volume xyz/stock markets: right after the candle manager
# backfills a synthetic (zero-volume) candle with real data it invalidates the EMA cache,
# and a candle read in that brief window can return an empty range -> get_latest_ema_close
# yields NaN -> fetch_map drops every close span -> empty close-EMAs -> Rust MissingEma.
# The recompute settles within ~1s, so re-fetch the mandatory close spans once for any
# symbol that came back empty (24/7 crypto perps never synthesize candles, so this no-ops).
missing_close = _symbols_missing_close_emas(symbols, need_close_spans, m1_close_emas)
if missing_close:
    logging.warning(
        "orchestrator EMAs: close-EMA empty for %s (EMA cache likely just invalidated by "
        "synthetic-candle backfill); recomputing once",
        ", ".join(missing_close),
    )
    await asyncio.sleep(float(getattr(self, "_ema_recompute_retry_delay_s", 0.75)))
    for sym in missing_close:
        m1_close_emas[sym] = await fetch_map(sym, sorted(need_close_spans[sym]), ema_close)
```

This relies on three locals that already exist in `_load_orchestrator_ema_bundle`:
`need_close_spans` (dict[symbol] → set of required close spans, built at the top of the
method), the inner `fetch_map(symbol, spans, fn)` coroutine, and the inner `ema_close`
coroutine. If your clone named them differently, adapt accordingly — the requirement is
"re-fetch the mandatory close spans once for the empty symbols."

### 3e. `calc_ideal_orders_orchestrator`: convert a residual `MissingEma` (backstop)

Wrap the single Rust orchestrator call in `calc_ideal_orders_orchestrator` so that if
the EMAs are *still* missing after the in-bundle retry (a genuine longer data gap, not a
1-second race), the raw Rust `ValueError` is re-raised as the typed
`TransientEmaUnavailable`. Locate the line `out_json = pbr.compute_ideal_orders_json(json.dumps(input_dict))`:

```python
try:
    out_json = pbr.compute_ideal_orders_json(json.dumps(input_dict))
except ValueError as e:
    # After the in-bundle retry, a residual MissingEma means EMAs are still not ready this
    # cycle. Re-raise as a typed, benign signal so the live loop skips the cycle (leaving
    # resting orders untouched) instead of logging a hard error + full traceback.
    if _is_missing_ema_error(e):
        raise TransientEmaUnavailable(str(e)) from e
    raise
out = json.loads(out_json)
```

Any other `ValueError` is re-raised unchanged (`raise`), so unrelated bugs still surface
loudly.

### 3f. `run_execution_loop`: catch the typed exception as a quiet skip

In the main loop's `try: … except Exception:` block, add a **more specific**
`except TransientEmaUnavailable` clause **before** the generic `except Exception`
(order matters — Python tries clauses top-to-bottom). It bumps the benign counter, logs
a single-line `WARNING` (no traceback), and sleeps a beat:

```python
            except TransientEmaUnavailable as e:
                # Benign, self-healing (low-volume xyz markets): EMAs momentarily unavailable.
                # Skip this cycle — resting orders are left untouched — and retry next cycle.
                self._health_ema_skips = getattr(self, "_health_ema_skips", 0) + 1
                logging.warning(
                    "skipping cycle: EMAs momentarily unavailable (%s); resting orders untouched, "
                    "retrying next cycle [ema_skips=%d]",
                    e,
                    self._health_ema_skips,
                )
                await asyncio.sleep(1.0)
            except Exception as e:
                self._health_errors += 1
                logging.error(f"error with {get_function_name()} {e}")
                traceback.print_exc()
                await asyncio.sleep(1.0)
```

---

## 4. Control-flow summary

```
candle minute, no trades ─► synthesize zero-candle
real data backfills      ─► _invalidate_ema_cache  (EMA cache invalidated)
        │
        ▼
_load_orchestrator_ema_bundle
  fetch close-EMAs ─► NaN ─► fetch_map drops them ─► close map = {}
  _symbols_missing_close_emas() flags the symbol
  ── sleep ~0.75s, re-fetch close spans ONCE ──►  populated 99% of the time  ✅ (no log noise beyond one WARNING)
        │ (still empty? genuine gap)
        ▼
calc_ideal_orders_orchestrator
  pbr.compute_ideal_orders_json ─► raises ValueError("…MissingEma…")
  _is_missing_ema_error ─► raise TransientEmaUnavailable
        │
        ▼
run_execution_loop
  except TransientEmaUnavailable ─► ema_skips += 1, WARNING (no traceback), sleep, retry next cycle  ✅
  (resting orders are NEVER touched on a skip)
```

Two layers of defense: (3d) almost always fixes it silently with one retry; (3e)+(3f)
guarantee that even a persistent gap degrades to a benign skip instead of an `ERROR`.

---

## 5. Tests

`tests/test_orchestrator_ema_retry.py` — 7 offline tests, **no network, no money**,
part of the standard `pytest` suite. They import:

```python
from passivbot import (
    Passivbot,
    TransientEmaUnavailable,
    _is_missing_ema_error,
    _symbols_missing_close_emas,
)
```

and cover:

- `_is_missing_ema_error` matches **only** a `ValueError` whose message contains
  `MissingEma` (right-text-wrong-type ⇒ `False`).
- `TransientEmaUnavailable` is **not** a subclass of `ValueError`.
- `_symbols_missing_close_emas` flags only symbols that both *need* close spans and have
  an *empty* close map.
- `_load_orchestrator_ema_bundle` **recovers** after exactly one retry (a `_FakeCM`
  returns NaN on the first call per span, finite after — each span is fetched twice).
- No retry happens when EMAs are present first try (each span fetched once).
- A persistent miss leaves the close map empty after exactly two attempts (initial +
  one retry), so the backstop in 3e/3f handles it.

The `_FakeCM` stub and a `_bundle_bot` builder (using `object.__new__(Passivbot)` and
stubbing only the few attributes `_load_orchestrator_ema_bundle` reads —
`_pb_mode_to_orchestrator_mode`, `has_position`, `bp`, `bot_value`, and
`_ema_recompute_retry_delay_s = 0.0` to avoid a real sleep) let the test run the real
method offline.

Run them (use the `passivbot` conda env — it has the Rust ext; `pythonpath=src` is set
by `pytest.ini`):

```
pytest -q tests/test_orchestrator_ema_retry.py
```

---

## 6. Verification — confirm the fix is live

**Offline (free):** `pytest -q tests/test_orchestrator_ema_retry.py` → 7 passed.

**In production logs:** the fix is working when, around a `real data replaced N
synthetic candle, EMA cache invalidated` line, you see **either**:

- nothing further (the EMAs self-settled before the orchestrator even read them — the
  cleanest outcome; this is what was observed on the 2026-06-07 SP500 run: two real
  invalidations, **zero** `MissingEma`, zero `ema_skips`), **or**
- a single `WARNING … recomputing once` line absorbed by the in-bundle retry (3d), with
  **no** `ERROR`/traceback, **or**
- a `WARNING skipping cycle: EMAs momentarily unavailable … [ema_skips=N]` and the
  `ema_skips=` counter in the next `[health]` line ticking up by 1 — with `errors=`
  unchanged.

The bug is **gone** when you no longer see `ERROR error with run_execution_loop
… MissingEma …` with a Rust traceback, and `errors=` stays flat across synthetic-candle
backfills.

---

## 7. Quick checklist for re-applying to a clone

- [ ] Add `TransientEmaUnavailable`, `_is_missing_ema_error`, `_symbols_missing_close_emas`
      at module scope (3a). Exception must NOT subclass `ValueError`.
- [ ] Add `self._health_ema_skips = 0` in `__init__` (3b).
- [ ] Add `ema_skips=%d` to the `[health]` log line + the `getattr(...)` arg (3c).
- [ ] Insert the re-fetch block at the end of `_load_orchestrator_ema_bundle` (3d).
- [ ] Wrap the `pbr.compute_ideal_orders_json` call in
      `calc_ideal_orders_orchestrator` with the `MissingEma → TransientEmaUnavailable`
      conversion (3e).
- [ ] Add `except TransientEmaUnavailable` **before** `except Exception` in
      `run_execution_loop` (3f).
- [ ] Copy `tests/test_orchestrator_ema_retry.py`; run `pytest -q` → green.
