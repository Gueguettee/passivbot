# Fix 02 — Resubscribe the Hyperliquid orderUpdates WS after a server-side "Expired" close

**File touched:** `src/exchanges/hyperliquid.py` (only)
**Companion tests:** `tests/test_hyperliquid_ws_resubscribe.py`
**Bundle commit:** `dac5e16`
**Applies to:** every Hyperliquid live run (main perp dex *and* HIP-3 / xyz builder dexes).
**Relationship to earlier WS work:** this is the **counterpart** to the watchdog-inert
fix (commit `482e055`). That fix stopped *false* reconnects from event-driven silence;
this fix restores *true* reconnects after a genuine socket death — without reviving the
storm. Read both together.

---

## 1. Symptom

After hours of healthy live trading, a single error appears and the WS never comes back:

```
ERROR  [hyperliquid] fin=1 opcode=8 data=b'\x03\xe8Expired' - goodbye
```

(`opcode=8` = WebSocket CLOSE frame; payload `\x03\xe8` = close code 1000 + reason
`"Expired"` — the Hyperliquid server closing an idle `orderUpdates` subscription.)

After this line, in the logs you will observe:

- **no further** `subscribed to orderUpdates websocket` line (it never resubscribes),
- `ws_reconnects=0` stays **0** forever in the `[health]` line (the counter never moves),
- the bot **keeps trading** — order plans, fills, position changes continue — because the
  execution loop polls positions/orders/fills over REST every cycle. But it now reacts on
  the loop's ~30 s fallback cadence instead of instantly on a pushed fill, and it is
  effectively **fill-blind on the WS**. Unattended, it stays degraded until a manual
  restart.

Observed in production on the 2026-06-07 SP500 soak: WS died at 23:58:42, never came back
through the next ~6.5 h; `ws_reconnects=0`, `errors=0` the entire time (nothing noticed).

---

## 2. Root cause

Three things combine:

1. **`watch_orders` subscribed exactly once and never again.** The old method body was:
   subscribe inside `if not self._ws_subscribed and self.query_address: …`, set
   `self._ws_subscribed = True`, then `while not stop_websocket: await asyncio.sleep(1.0)`.
   Once subscribed it only sleeps; there is no path that resubscribes.

2. **The SDK does not auto-recover.** `Info(skip_ws=False)` creates a
   `WebsocketManager(threading.Thread)` whose `run()` calls `ws.run_forever()` **once**.
   When the server sends the close frame, `run_forever()` returns, `run()` exits, the
   thread dies, and `ws.keep_running` flips to `False`. Nothing restarts it.

3. **The base-loop recency watchdog is deliberately inert on HL.** In
   `run_execution_loop` (`src/passivbot.py`, the `WS liveness watchdog` block) the reconnect
   branch is gated on `self._ws_last_message_ms > 0`. On Hyperliquid the WS callback
   intentionally **never stamps** `_ws_last_message_ms` — because the `orderUpdates` stream
   is event-driven and silent for minutes when idle, and feeding that silence to a 120 s
   recency watchdog caused a **reconnect storm** (~39 reconnects in 3 h; fixed in `482e055`).
   So the watchdog cannot tell a *quiet* socket from a *dead* one, and stays dormant.

Net: a genuine WS death is invisible to every existing mechanism, and REST polling silently
papers over it.

The key insight for the fix: **don't detect death by message recency** (that's the storm
trap). Detect it by the **actual socket/thread state**, which only changes on a real close.

---

## 3. The fix, layer by layer

All edits are in `src/exchanges/hyperliquid.py`, anchored by symbol names (not line
numbers).

### 3a. `__init__`: a probe interval

Next to `self._ws_subscribed = False` / `self._ws_task = None`, add:

```python
self._ws_resub_check_s = 5.0  # how often watch_orders probes WS liveness
```

### 3b. Replace `watch_orders` with a resubscribing loop

The method now (re)subscribes via a helper and, every `_ws_resub_check_s`, retries a failed
subscribe (with backoff) or resubscribes a genuinely-dead socket (counted):

```python
async def watch_orders(self):
    """... resubscribing if the server closes the socket. The probe is deliberately
    silence-INDEPENDENT (socket/thread state, never message recency) so a healthy-but-quiet
    stream is never mistaken for dead -- that false signal is what caused an earlier
    reconnect storm. If WS setup fails we degrade to polling."""
    loop = asyncio.get_event_loop()
    await self._subscribe_orders_ws(loop)

    backoff_s = self._ws_resub_check_s
    while not getattr(self, "stop_websocket", False):
        await asyncio.sleep(self._ws_resub_check_s)
        if getattr(self, "stop_websocket", False) or not self.query_address:
            continue
        if not self._ws_subscribed:
            # A prior subscribe failed; retry with backoff. REST polling covers the gap.
            if await self._subscribe_orders_ws(loop):
                backoff_s = self._ws_resub_check_s
            else:
                backoff_s = min(backoff_s * 2.0, 60.0)
                await asyncio.sleep(backoff_s)
            continue
        try:
            dead = self._ws_connection_dead()
        except Exception:
            dead = False
        if dead:
            logging.warning(
                "hyperliquid: orderUpdates websocket closed server-side "
                "(e.g. 'Expired'); resubscribing"
            )
            self._health_ws_reconnects = getattr(self, "_health_ws_reconnects", 0) + 1
            await self._subscribe_orders_ws(loop, force=True)
```

### 3c. Extract `_subscribe_orders_ws` (the old subscribe block, made reusable)

This is the original subscribe code (Info teardown → new `Info(skip_ws=False)` → `_cb` →
`subscribe`), now a helper that returns a bool and accepts `force`. **Keep the `_cb`
comment about NOT stamping `_ws_last_message_ms`** — that is load-bearing (it's what keeps
the recency watchdog inert and prevents the storm):

```python
async def _subscribe_orders_ws(self, loop, force: bool = False) -> bool:
    """(Re)subscribe to the native orderUpdates websocket. Returns True if subscribed.
    Tears down any prior WS Info first (each Info(skip_ws=False) spawns a non-daemon
    websocket thread; leaking them blocks clean process exit)."""
    if force:
        self._ws_subscribed = False
    if self._ws_subscribed or not self.query_address:
        return self._ws_subscribed
    try:
        if self.info_ws is not None and hasattr(self.info_ws, "disconnect_websocket"):
            try:
                await asyncio.to_thread(self.info_ws.disconnect_websocket)
            except Exception:
                pass
        self.info_ws = Info(
            base_url=self.base_url, skip_ws=False,
            perp_dexs=[self.dex] if self.dex else None,
        )

        def _cb(msg):
            # Deliberately do NOT stamp _ws_last_message_ms here (would revive the
            # recency-watchdog reconnect storm on this event-driven stream). WS death is
            # instead detected by _ws_connection_dead() (socket/thread state).
            try:
                updates = self._parse_ws_order_updates(msg)
                if updates:
                    loop.call_soon_threadsafe(self._safe_handle_order_update, updates)
            except Exception as e:
                logging.debug(f"hyperliquid ws cb error: {e}")

        await asyncio.to_thread(
            self.info_ws.subscribe,
            {"type": "orderUpdates", "user": self.query_address},
            _cb,
        )
        self._ws_subscribed = True
        logging.info("hyperliquid: subscribed to orderUpdates websocket")
    except Exception as e:
        self._ws_subscribed = False
        logging.warning(f"hyperliquid: ws subscribe failed, falling back to polling: {e}")
    return self._ws_subscribed
```

### 3d. Add `_ws_connection_dead` — the silence-independent death probe

This is the heart of the fix. It inspects the SDK's `Info.ws_manager` (a
`WebsocketManager` thread whose `run()` calls `ws.run_forever()`):

```python
def _ws_connection_dead(self) -> bool:
    """True only when the SDK orderUpdates websocket is *definitively closed* -- not merely
    quiet. Silence-INDEPENDENT: inspects the SDK websocket thread/socket state, never message
    recency, so a healthy-but-idle stream is never mistaken for dead (that false signal is
    what caused the earlier reconnect storm). Catches HL server-initiated closes (the periodic
    'Expired' goodbye) that the SDK does not auto-recover."""
    if not self._ws_subscribed or self.info_ws is None:
        return False
    wsm = getattr(self.info_ws, "ws_manager", None)
    if wsm is None:
        return False  # nothing to introspect -> never risk a false reconnect
    try:
        if hasattr(wsm, "is_alive") and not wsm.is_alive():
            return True   # run_forever() returned -> manager thread died
    except Exception:
        pass
    ws = getattr(wsm, "ws", None)
    if ws is not None and getattr(ws, "keep_running", True) is False:
        return True       # websocket-client flips keep_running False on close
    return False
```

**Why this can't storm:** a quiet-but-healthy socket has `is_alive() == True` and
`keep_running == True`, so `_ws_connection_dead()` returns `False`. It flips `True` *only*
when the thread has actually exited or the socket actually closed — conditions that do not
spontaneously self-clear, so after one successful resubscribe the new socket reads healthy
and the loop goes quiet again. (`tests/test_hyperliquid_ws_resubscribe.py::test_resubscribe_converges_no_storm`
locks this in.)

---

## 4. Control-flow summary

```
watch_orders ── subscribe once ──► loop every 5s:
     │
     ├─ not subscribed?  ─► retry subscribe with exponential backoff (REST covers gap)
     │
     └─ _ws_connection_dead()?            (silence-independent: thread/socket state)
            │ alive + keep_running        ─► do nothing  (quiet is fine -> NO storm)
            │ thread dead / keep_running=False ─► WARN, ws_reconnects+=1, resubscribe(force)
```

Detection lives entirely inside `watch_orders`; the base-loop recency watchdog stays inert
(`_ws_last_message_ms` is still never stamped). The two mechanisms do not interact.

---

## 5. Tests

`tests/test_hyperliquid_ws_resubscribe.py` — 10 offline tests, **no network, no money**,
standard suite. Fakes mirror the SDK chain `Info → ws_manager(WebsocketManager thread) → ws`.
Coverage:

- `_ws_connection_dead`: not-subscribed / no-info_ws / missing-ws_manager ⇒ **never dead**;
  **healthy-but-quiet** (alive + keep_running) ⇒ **not dead** (the anti-storm property);
  **dead thread** (`is_alive()==False`) ⇒ dead; **closed socket** (`keep_running==False`) ⇒ dead.
- `_subscribe_orders_ws`: no-op when already subscribed (no new `Info`); `force=True` tears
  down the old `Info` (`disconnect_websocket` called) and builds exactly one fresh subscription;
  empty `query_address` ⇒ does not subscribe; after repairing a dead socket,
  `_ws_connection_dead()` reads `False` again (convergence / no storm).

Run (use the `passivbot` conda env; `pytest.ini` sets `pythonpath=src`):

```
pytest -q tests/test_hyperliquid_ws_resubscribe.py
```

---

## 6. Verification — confirm the fix is live

**Offline (free):** `pytest -q tests/test_hyperliquid_ws_resubscribe.py` → 10 passed.

**In production logs:** the fix is working when, after a server-side close, you see the
pair:

```
ERROR    [hyperliquid] fin=1 opcode=8 data=b'\x03\xe8Expired' - goodbye
WARNING  [hyperliquid] orderUpdates websocket closed server-side (e.g. 'Expired'); resubscribing
INFO     [hyperliquid] subscribed to orderUpdates websocket
```

and the next `[health]` line shows **`ws_reconnects` incremented** (was permanently `0`
before). The bug is gone when an "Expired" close is followed within ~5 s by a fresh
subscription instead of indefinite silence.

---

## 7. Quick checklist for re-applying to a clone

- [ ] Add `self._ws_resub_check_s = 5.0` in `__init__` (3a).
- [ ] Replace `watch_orders` so it calls `_subscribe_orders_ws` then loops a liveness probe
      that resubscribes on death and retries failed subscribes with backoff (3b).
- [ ] Extract the old subscribe block into `_subscribe_orders_ws(loop, force=False) -> bool`,
      **keeping** the `_cb` "do NOT stamp `_ws_last_message_ms`" comment (3c).
- [ ] Add `_ws_connection_dead()` checking `ws_manager.is_alive()` and `ws.keep_running`
      (never message recency) (3d).
- [ ] Leave the base-loop recency watchdog untouched (still gated on
      `_ws_last_message_ms > 0`, still never stamped).
- [ ] Copy `tests/test_hyperliquid_ws_resubscribe.py`; `pytest -q` → green.
