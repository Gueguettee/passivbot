# passivbot_sp500 — S&P 500 perp on Hyperliquid

A focused passivbot fork for **one asset: the S&P 500-USDC perpetual on Hyperliquid** —
the HIP-3 builder-deployed market **`xyz:SP500`** (Trade[XYZ]) — traded long-only with a
grid strategy on **isolated margin**.

**This version is Hyperliquid-first.** Lighter support is kept (`configs/config_sp500_lighter.json`)
but Hyperliquid is the default. The bot **refuses to run with a config that has more than one coin**.

## What's here
- **Backtest + optimize** the SP500 perp (default config: `configs/config_sp500.json`).
  Backtest output includes fee-stressed results, projected CAGR, and the same minimum-capital
  thresholds used by live enforcement.
- **Data download**: by default uses only the **free public `candleSnapshot` API** (recent ~3.4d).
  Full 1-minute history via **Hydromancer Reservoir** (1s → 1m) is **requester-pays S3 — it costs
  money, so it is opt-in only** (`HL_USE_RESERVOIR_ARCHIVE=1`). When older candles are needed that the
  free API can't reach, the backtest **warns** and prints the exact command to backfill just those days.
  Loaded candles are always **deduplicated + quality-checked** (drops dup/invalid rows, fills gaps).
  A separate collector compose file can keep SP500 + NVDA current with daily polling and 30-minute
  retry cycles on failures.
- **Live trading** (native `hyperliquid-python-sdk`, isolated margin, subaccount/vault support), **verified
  working** against a funded subaccount on real money:
  - order **primitives** via `src/tools/hyperliquid_live_test.py` (balance/positions/orders, limit
    place+cancel, market open, close-via-market/limit — a first run passed all checks for < $0.01);
  - the full live **engine loop** via `src/tools/hyperliquid_engine_test.py` (grid compute → reconcile →
    submit/cancel, WS order updates, staleness watchdog/reconnect, graceful flatten). Both are **opt-in,
    real-money** tools excluded from the standard suite. `tests/` holds offline ($0) engine unit tests.
    `configs/config_sp500.json` is the **default config** for live (`python src/passivbot.py`), backtest, and
    docker. See QUICKSTART §5.
  - live safety gates are enabled by default: enforced minimum capital blocks new opening when
    the account is below the configured threshold, and a degraded order-update websocket switches
    entry-permitting modes to `tp_only` until healthy. `tp_only` cancels/blocks entries and DCA
    while keeping reduce-only take-profit/close handling for any open position.
  - live idle/status visibility: the bot writes `runs/sp500_live/engine_status.json` every
    order-planning cycle, logs a throttled `[idle] reason=...` line when flat with no orders, and
    `src/tools/live_status.py --dry-cycle` prints a read-only account + would-order snapshot.
- **Secret-free sharing/deploy bundles**: `python make_deploy_bundle.py --code-only` writes a zip
  with code, configs, docs, and credential templates while excluding real keys, local caches/results,
  recorder data, and compiled binaries. Recipients start with `DEPLOY_BUNDLE_README.md`, then copy
  `api-keys.json.example` to `api-keys.json` and add their own keys locally.

## Quick start
See **[QUICKSTART.md](QUICKSTART.md)** for full instructions. The short version:

```bash
# 1. environment (Python 3.10)
conda env create -f environment.yml && conda activate passivbot_sp500   # or: pip install -r requirements.txt
# on Linux/macOS also build the Rust ext once: bash rustbuild.sh

# 2. data: backtests auto-pull recent candles for free (public API). Full history is paid S3 and opt-in:
#    put AWS keys in aws.env (PUBLIC_KEY / SECRET_KEY) AND set HL_USE_RESERVOIR_ARCHIVE=1 (else never used)

# 3. backtest the default Hyperliquid SP500 config
PYTHONPATH=src python src/backtest.py configs/config_sp500.json --disable_plotting --skip-rust-compile
```

Runs natively (Windows dev / Ubuntu VPS conda) or in **Docker** (`docker compose run --rm passivbot`),
all off the same `configs/` + `caches/`.

## Layout
| Path | What |
|------|------|
| `configs/config_sp500.json` | default — fee-stressed GA-tuned SP500 config; latest local run was +35.0% / 0.27 Sharpe / 4.2% maxDD over 2026-03-18..2026-06-06. See QUICKSTART → Configs for tuned variants |
| `src/exchanges/hyperliquid.py` | native-SDK live bot (isolated, subaccount, HIP-3) |
| `src/tools/hyperliquid_live_test.py` | opt-in real-money **order-primitives** test (read-only by default) |
| `src/tools/live_status.py` | read-only live status probe; `--dry-cycle` shows would-cancel/would-create without submitting |
| `src/tools/hyperliquid_engine_test.py` | opt-in **live-engine** test — Mode A dry cycle ($0) + Mode B real-money soak |
| `tests/` | offline ($0, no network) engine unit tests — the standard `pytest` suite |
| `src/tools/hyperliquid_archive_downloader.py` | Reservoir 1s→1m full-history downloader (+ keeps 1s) |
| `docs/reservoir_archive.md` | Reservoir S3 reference — bucket layout, OHLCV **and L2 orderbook** (`orderbook/1m/`, 20-level @ 1-min), measured sizes, requester-pays $ model, and how to get sub-1m L2 |
| `src/tools/hyperliquid_ohlcv_collector.py` | public candleSnapshot collector (recent ~3.4d; always-on SP500+NVDA mode via `docker-compose.collector.yml`) |
| `l2_collector/` | self-contained dockerized **live `l2Book` recorder** → crash-safe hourly parquet (sub-1m L2 for `xyz:SP500`; dedup, reconnect, resume). Runs independently — see `l2_collector/README.md` |
| `src/hlcv_preparation.py` | backtest data prep (`_prepare_hlcvs_hyperliquid`) |
| `make_deploy_bundle.py` | secret-scanning deployment/share zip builder (`--code-only` for code + configs only) |
| `DEPLOY_BUNDLE_README.md` | first-read instructions for people receiving a zip bundle |
| `api-keys.json.example` / `aws.env.example` | credential templates safe to share |
| `aws.env` / `api-keys.json` | local credentials (gitignored - never commit or zip manually) |
