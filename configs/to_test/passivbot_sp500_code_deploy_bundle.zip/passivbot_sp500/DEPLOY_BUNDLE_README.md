# Deploy Bundle Setup

This zip intentionally does not contain private credentials. The files `api-keys.json`,
`aws.env`, `.env`, private keys, and local outputs are excluded by the bundle script.

This code-only bundle also excludes candle caches, backtest/run outputs, recorder output
from `l2_collector/data/`, and compiled native extensions (`*.pyd`, `*.so`, `*.dll`, etc.).
Docker is the easiest deployment path because the image builds the Rust extension during
`docker compose build`.

## 1. Add your own Hyperliquid keys

After extracting the zip:

```bash
cd passivbot_sp500
cp api-keys.json.example api-keys.json
```

Edit `api-keys.json` and fill the `hyperliquid_01` block. The default live config
`configs/config_sp500.json` already uses `"live": { "user": "hyperliquid_01" }`.

Required fields for the default Hyperliquid SP500 deployment:

```json
{
  "hyperliquid_01": {
    "exchange": "hyperliquid",
    "wallet_address": "0x_your_wallet_or_owner_address",
    "private_key": "0x_your_api_or_agent_wallet_private_key",
    "subaccount_address": "0x_optional_subaccount_address",
    "is_vault": false,
    "dex": "xyz"
  }
}
```

If you are using the main account, remove `subaccount_address` or leave it blank.
If you change the user name, change `live.user` in the config to match.

## 2. Optional AWS keys for paid history

AWS keys are only needed for Hydromancer Reservoir requester-pays S3 backfill.
They are not needed for live trading or the public candle collector.

```bash
cp aws.env.example aws.env
```

Edit `aws.env` with your own AWS access key and secret key. The archive is only used
when you explicitly opt in with `HL_USE_RESERVOIR_ARCHIVE=1` or the matching config option.

The first ordinary backtest/live run can use Hyperliquid's free public recent-candle API.
Paid Reservoir history is only touched after that explicit opt-in.

## 3. Docker deploy

Build the image:

```bash
docker compose build
```

Run a backtest:

```bash
docker compose run --rm passivbot
```

Run live trading:

```bash
docker compose up -d passivbot-live
docker compose logs -f passivbot-live
```

Stop live trading:

```bash
docker compose down
```

Keep `api-keys.json` and `aws.env` local to the deploy host. Do not send them back,
commit them, or include them in another zip.

## 4. Native setup

For native conda/venv use:

```bash
conda env create -f environment.yml
conda activate passivbot_sp500
pip install -r requirements.txt
bash rustbuild.sh
```

Windows users receiving this code-only zip do not get the repo's prebuilt `.pyd`; use Docker
or build the Rust extension locally.
