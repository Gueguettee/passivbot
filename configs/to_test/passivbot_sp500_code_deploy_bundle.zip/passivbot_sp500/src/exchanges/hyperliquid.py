"""
Hyperliquid live bot built on the native hyperliquid-python-sdk.

This is the main live exchange for this build: a single asset on a HIP-3
builder-deployed perp dex (default xyz:SP500, the Trade[XYZ] S&P 500-USDC perp),
traded with ISOLATED margin (never cross). Subaccounts and vaults are supported
via the SDK's vault/account address routing.

It extends Passivbot directly (like LighterBot), not CCXTBot — the native SDK is
more reliable than CCXT for HIP-3 dexes + isolated margin + subaccounts. The base
class drives the main loop and calls the primitives implemented here.

The hyperliquid-python-sdk is synchronous, so blocking calls are run in a thread
via asyncio.to_thread to keep the event loop responsive.

NOTE: the data-download/backtest path does NOT use this module (it uses the public
candleSnapshot collector). This live path is implemented in full but must be
validated against a real account before trading real money.
"""

import asyncio
import math
import time
import traceback
from math import floor, log10

try:
    from eth_account import Account
except ImportError:  # pragma: no cover - exercised only when eth_account is absent
    Account = None

# The hyperliquid-python-sdk is required for live trading but optional for offline unit tests
# (which build the bot via object.__new__ and stub the SDK objects). Guard the import so the
# module can be imported without the SDK installed; create_ccxt_sessions() fails fast if a live
# run actually needs it.
try:
    from hyperliquid.info import Info
    from hyperliquid.exchange import Exchange
    from hyperliquid.utils import constants
except ImportError:  # pragma: no cover - exercised only when the SDK is absent
    Info = Exchange = constants = None

from passivbot import Passivbot, logging
from procedures import load_user_info
from config_utils import require_live_value


class HyperliquidBot(Passivbot):
    def __init__(self, config: dict):
        if Info is None:
            raise ImportError(
                "hyperliquid-python-sdk is not installed; it is required for live Hyperliquid "
                "trading. Install it (pip install hyperliquid-python-sdk) to run the live bot."
            )
        if Account is None:
            raise ImportError(
                "eth_account is not installed; it is required for live Hyperliquid signing. "
                "Install eth-account or hyperliquid-python-sdk extras to run the live bot."
            )
        # Credentials must be set before super().__init__() (it calls create_ccxt_sessions()).
        _user_info = load_user_info(require_live_value(config, "user"))
        self.wallet_address = _user_info.get("wallet_address", "")
        self.private_key = _user_info.get("private_key", "")
        self.subaccount_address = (_user_info.get("subaccount_address", "") or "").strip()
        is_vault = _user_info.get("is_vault", False)
        if isinstance(is_vault, str):
            is_vault = is_vault.strip().lower() in ("1", "true", "yes", "y", "on")
        self.is_vault = bool(is_vault)
        self.base_url = _user_info.get("base_url", "") or constants.MAINNET_API_URL
        # HIP-3 perp dex namespace ("" = main perp dex). Default xyz (Trade[XYZ]).
        self.dex = (_user_info.get("dex", "") or config.get("live", {}).get("hyperliquid_dex", "") or "xyz").strip()

        # query_address = the account whose state we read (subaccount/vault if set).
        # vault_action_address = passed as vaultAddress on order/cancel/leverage actions.
        if self.subaccount_address:
            self.query_address = self.subaccount_address
            self.vault_action_address = self.subaccount_address
        elif self.is_vault:
            self.query_address = self.wallet_address
            self.vault_action_address = self.wallet_address
        else:
            self.query_address = self.wallet_address
            self.vault_action_address = None

        self.info = None        # REST Info (skip_ws)
        self.info_ws = None     # WS Info for order subscriptions
        self.hl_exchange = None # signing SDK Exchange (NOT self.exchange — that's the name str)
        self._wallet = None

        super().__init__(config)

        if hasattr(self, "cm") and self.cm is not None:
            self.cm.exchange = self
        self.id = "hyperliquid"  # CandlestickManager reads exchange.id for cache paths
        self.quote = "USDC"
        self.hedge_mode = False  # Hyperliquid is one-way only
        self.custom_id_max_length = 0  # cloid handled separately

        # Per-symbol native state
        self.symbol_to_hlname = {}   # "SP500/USDC:USDC" -> "xyz:SP500"
        self.hlname_to_symbol = {}   # "xyz:SP500" -> "SP500/USDC:USDC"
        self.coin_to_symbol_map = {}
        self.symbol_to_coin_map = {}
        self.sz_decimals = {}        # symbol -> int
        self._oid_by_id = {}         # str(id) -> int oid (for cancellation)

        self._ws_subscribed = False
        self._ws_task = None
        self._ws_resub_check_s = 5.0   # how often watch_orders probes WS liveness
        self._ws_unhealthy_since_ms = 0.0  # 0 = healthy; stamped by the base WS-health gate
        self._last_fetched_balance = None
        self._last_account_state = None
        self.max_n_concurrent_ohlcvs_1m_updates = 2

    # ------------------------------------------------------------------ #
    # Sessions
    # ------------------------------------------------------------------ #
    def create_ccxt_sessions(self):
        """Initialize the native SDK clients instead of CCXT."""
        self.cca = None
        self.ccp = None
        perp_dexs = [self.dex] if self.dex else None
        self._wallet = Account.from_key(self.private_key) if self.private_key else None

        self.info = Info(base_url=self.base_url, skip_ws=True, perp_dexs=perp_dexs)
        if self._wallet is not None:
            self.hl_exchange = Exchange(
                wallet=self._wallet,
                base_url=self.base_url,
                account_address=self.query_address or None,
                vault_address=self.vault_action_address,
                perp_dexs=perp_dexs,
            )

    @staticmethod
    def _parse_account_state(state: dict) -> dict:
        margin = state.get("marginSummary", {}) or {}
        asset_positions = state.get("assetPositions", []) or []

        def _safe_float(value, default=0.0):
            try:
                out = float(value)
                return out if math.isfinite(out) else default
            except (TypeError, ValueError):
                return default

        # A missing/garbage accountValue must FAIL, not coerce to 0.0: a phantom zero balance
        # feeds the risk calcs an infinite wallet exposure (see _fetch_positions_and_balance).
        account_equity = _safe_float(margin.get("accountValue"), None)
        if account_equity is None:
            raise ValueError(f"marginSummary.accountValue missing or invalid: {margin!r}")
        upnl = 0.0
        for ap in asset_positions:
            pos = ap.get("position", {}) or {}
            upnl += _safe_float(pos.get("unrealizedPnl", 0))
        wallet_balance = account_equity - upnl
        available_margin = None
        for key in ("withdrawable", "totalRawUsd", "accountValue"):
            try:
                value = margin.get(key)
            except AttributeError:
                value = None
            if value is not None:
                available_margin = _safe_float(value, None)
                if available_margin is not None:
                    break
        return {
            "wallet_balance_for_sizing": wallet_balance,
            "account_equity_for_risk": account_equity,
            "available_margin": available_margin,
            "unrealized_pnl": upnl,
            "raw_margin_summary": margin,
        }

    # ------------------------------------------------------------------ #
    # Markets / symbol mapping
    # ------------------------------------------------------------------ #
    async def init_markets(self, verbose=True):
        """Load markets from the SDK meta (for self.dex) instead of CCXT."""
        self.init_markets_last_update_ms = int(time.time() * 1000)
        await self.update_exchange_config()

        meta = await asyncio.to_thread(self.info.meta, self.dex)
        universe = meta.get("universe", []) if isinstance(meta, dict) else []
        markets_dict = {}
        for elm in universe:
            hlname = str(elm.get("name", ""))
            if not hlname:
                continue
            if elm.get("isDelisted"):
                continue
            # coin token: strip the "dex:" prefix if present
            coin = hlname.split(":", 1)[1] if ":" in hlname else hlname
            symbol = f"{coin.upper()}/{self.quote}:{self.quote}"
            sz_dec = int(elm.get("szDecimals", 2))
            max_dec = 6  # MAX_DECIMALS for perps
            price_tick = 10 ** -(max_dec - sz_dec) if (max_dec - sz_dec) > 0 else 1.0
            amount_tick = 10 ** -sz_dec

            self.symbol_to_hlname[symbol] = hlname
            self.hlname_to_symbol[hlname] = symbol
            self.coin_to_symbol_map[coin.upper()] = symbol
            self.symbol_to_coin_map[symbol] = coin.upper()
            self.sz_decimals[symbol] = sz_dec

            markets_dict[symbol] = {
                "symbol": symbol,
                "id": hlname,
                "base": coin.upper(),
                "quote": self.quote,
                "active": True,
                "swap": True,
                "linear": True,
                "type": "swap",
                "precision": {"amount": amount_tick, "price": price_tick},
                "limits": {"amount": {"min": amount_tick}, "cost": {"min": 10.0}},
                "maker": 0.0002,
                "taker": 0.0005,
                "contractSize": 1.0,
                "info": {
                    "name": hlname,
                    "szDecimals": sz_dec,
                    "maxLeverage": int(elm.get("maxLeverage", 50)),
                    "onlyIsolated": elm.get("onlyIsolated", False),
                },
            }

        self.markets_dict = markets_dict
        try:
            from utils import create_coin_symbol_map_cache
            create_coin_symbol_map_cache("hyperliquid", self.markets_dict, verbose=False)
        except Exception as e:
            logging.warning(f"hyperliquid: could not build coin/symbol cache: {e}")

        await self.determine_utc_offset(verbose)

        from utils import filter_markets
        eligible, _, reasons = filter_markets(self.markets_dict, self.exchange, verbose=verbose)
        self.eligible_symbols = set(eligible)
        self.ineligible_symbols = reasons

        self.set_market_specific_settings()
        self.max_len_symbol = max([len(s) for s in self.markets_dict]) if self.markets_dict else 17
        self.sym_padding = max(self.sym_padding, self.max_len_symbol + 1)
        self.init_coin_overrides()
        self.refresh_approved_ignored_coins_lists()
        self.set_wallet_exposure_limits()
        await self.update_positions()
        await self.update_open_orders()
        await self.update_effective_min_cost()
        if self.is_forager_mode():
            await self.update_first_timestamps()

    def set_market_specific_settings(self):
        super().set_market_specific_settings()
        for symbol in self.markets_dict:
            elm = self.markets_dict[symbol]
            self.symbol_ids[symbol] = elm["id"]
            self.min_costs[symbol] = (
                10.0 if elm["limits"]["cost"]["min"] is None else max(10.0, float(elm["limits"]["cost"]["min"]))
            )
            self.qty_steps[symbol] = elm["precision"]["amount"]
            self.min_qtys[symbol] = (
                self.qty_steps[symbol]
                if elm["limits"]["amount"]["min"] is None
                else float(elm["limits"]["amount"]["min"])
            )
            self.price_steps[symbol] = elm["precision"]["price"]
            self.c_mults[symbol] = elm["contractSize"]
            self.max_leverage[symbol] = int(elm["info"].get("maxLeverage", 50))

    def symbol_to_coin(self, symbol):
        if symbol in self.symbol_to_coin_map:
            return self.symbol_to_coin_map[symbol]
        if "/" in symbol:
            base = symbol[: symbol.find("/")]
            return base.split(":", 1)[1] if ":" in base else base
        return symbol

    def coin_to_symbol(self, coin, verbose=True):
        if coin == "":
            return ""
        cu = coin.upper()
        if cu in self.coin_to_symbol_map:
            return self.coin_to_symbol_map[cu]
        symbol = f"{cu}/{self.quote}:{self.quote}"
        if symbol in self.markets_dict:
            return symbol
        if verbose:
            logging.warning(f"coin_to_symbol: could not find symbol for coin {coin}")
        return ""

    def _hlname(self, symbol):
        return self.symbol_to_hlname.get(symbol, self.symbol_to_coin(symbol))

    def symbol_is_eligible(self, symbol):
        return symbol in self.markets_dict and self.markets_dict[symbol].get("active", True)

    async def determine_utc_offset(self, verbose=True):
        # Hyperliquid timestamps are UTC ms epoch.
        self.utc_offset = 0.0

    # ------------------------------------------------------------------ #
    # Precision helpers (Hyperliquid: <=5 sig figs and <= 6-szDecimals decimals)
    # ------------------------------------------------------------------ #
    def _round_price(self, price, symbol):
        if not price or price <= 0:
            return float(price)
        sz_dec = self.sz_decimals.get(symbol, 2)
        max_dec = max(0, 6 - sz_dec)
        p = round(float(price), max_dec)
        if p != 0:
            sig_dec = 5 - int(floor(log10(abs(p)))) - 1
            sig_dec = max(0, min(sig_dec, max_dec))
            p = round(p, sig_dec)
        return p

    def _round_size(self, sz, symbol):
        sz_dec = self.sz_decimals.get(symbol, 3)
        f = 10 ** sz_dec
        return floor(abs(float(sz)) * f) / f

    # ------------------------------------------------------------------ #
    # Data fetching
    # ------------------------------------------------------------------ #
    async def _fetch_positions_and_balance(self):
        try:
            state = await asyncio.to_thread(self.info.user_state, self.query_address, self.dex)
        except Exception as e:
            logging.error(f"hyperliquid: error fetching user_state: {e}")
            logging.debug(traceback.format_exc())
            return False
        positions = []
        for ap in state.get("assetPositions", []) or []:
            pos = ap.get("position", {})
            coin = pos.get("coin", "")
            symbol = self.hlname_to_symbol.get(coin) or self.coin_to_symbol(
                coin.split(":", 1)[1] if ":" in coin else coin, verbose=False
            )
            if not symbol:
                continue
            try:
                size = float(pos.get("szi", 0) or 0)
            except (TypeError, ValueError):
                continue
            if size == 0.0:
                continue
            positions.append({
                "symbol": symbol,
                "position_side": "long" if size > 0 else "short",
                "size": size,
                "price": float(pos.get("entryPx", 0) or 0),
            })
        try:
            account_state = self._parse_account_state(state)
            balance = account_state["wallet_balance_for_sizing"]
            self._last_account_state = account_state
        except Exception as e:
            # NEVER silently report 0.0 here: a zero balance makes wallet exposure explode and
            # can arm the loss-closing risk paths (unstuck / auto-reduce). The Jun 7 2026 churn
            # episode (851 taker fills, -$4.06) is consistent with exactly this fallback feeding
            # balance=0 into the risk calcs on a transient parse hiccup. None => the engine keeps
            # the previous balance and counts a failed read instead of trading on garbage.
            logging.error(f"hyperliquid: error parsing account state for balance: {e}")
            balance = None
            self._last_account_state = None
        return positions, balance

    async def fetch_positions(self):
        res = await self._fetch_positions_and_balance()
        if res is False:
            return None
        positions, balance = res
        self._last_fetched_balance = balance
        return positions

    async def fetch_balance(self):
        if self._last_fetched_balance is not None:
            bal = self._last_fetched_balance
            self._last_fetched_balance = None
            return bal
        res = await self._fetch_positions_and_balance()
        if res is False:
            return None
        _positions, balance = res
        return balance

    async def fetch_account_state(self):
        try:
            state = await asyncio.to_thread(self.info.user_state, self.query_address, self.dex)
            self._last_account_state = self._parse_account_state(state)
            return self._last_account_state
        except Exception as e:
            logging.error(f"hyperliquid: error fetching account state: {e}")
            return None

    async def fetch_open_orders(self, symbol: str = None):
        try:
            raw = await asyncio.to_thread(self.info.frontend_open_orders, self.query_address, self.dex)
        except Exception as e:
            logging.error(f"hyperliquid: error fetching open orders: {e}")
            return []
        orders = []
        for o in raw or []:
            coin = o.get("coin", "")
            sym = self.hlname_to_symbol.get(coin) or self.coin_to_symbol(
                coin.split(":", 1)[1] if ":" in coin else coin, verbose=False
            )
            if not sym:
                continue
            side = "buy" if o.get("side") == "B" else "sell"
            try:
                oid = int(o.get("oid"))
            except (TypeError, ValueError):
                continue
            qty = float(o.get("sz", 0) or 0)
            price = float(o.get("limitPx", 0) or 0)
            reduce_only = bool(o.get("reduceOnly", False))
            order = {
                "id": oid,
                "symbol": sym,
                "side": side,
                "qty": qty,
                "amount": qty,
                "price": price,
                "reduceOnly": reduce_only,
                "reduce_only": reduce_only,
                "position_side": self.determine_pos_side({"symbol": sym, "side": side, "reduceOnly": reduce_only}),
                "timestamp": o.get("timestamp", 0),
            }
            self._oid_by_id[str(oid)] = oid
            orders.append(order)
        return sorted(orders, key=lambda x: x.get("timestamp", 0))

    async def fetch_tickers(self):
        try:
            mids = await asyncio.to_thread(self.info.all_mids, self.dex)
        except Exception as e:
            logging.error(f"hyperliquid: error fetching tickers: {e}")
            return False
        tickers = {}
        for name, px in (mids or {}).items():
            sym = self.hlname_to_symbol.get(name) or self.coin_to_symbol(
                name.split(":", 1)[1] if ":" in name else name, verbose=False
            )
            if not sym or sym not in self.markets_dict:
                continue
            try:
                p = float(px)
            except (TypeError, ValueError):
                continue
            tickers[sym] = {"bid": p, "ask": p, "last": p}
        return tickers

    async def update_tickers(self):
        if not hasattr(self, "tickers"):
            self.tickers = {}
        tickers = await self.fetch_tickers()
        if tickers:
            self.tickers = tickers

    async def fetch_ticker(self, symbol):
        tickers = await self.fetch_tickers()
        if tickers and symbol in tickers:
            return tickers[symbol]
        return {}

    _INTERVAL_MINUTES = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240}

    async def _fetch_candles(self, symbol, timeframe, n_candles, since=None):
        hlname = self._hlname(symbol)
        minutes = self._INTERVAL_MINUTES.get(timeframe, 1)
        now_ms = int(time.time() * 1000)
        start = int(since) if since else now_ms - minutes * 60_000 * n_candles
        end = now_ms
        try:
            raw = await asyncio.to_thread(self.info.candles_snapshot, hlname, timeframe, start, end)
            self._candle_fetch_fails = 0  # a successful call (even zero rows) clears the staleness gate
        except Exception as e:
            self._candle_fetch_fails = getattr(self, "_candle_fetch_fails", 0) + 1
            logging.warning(f"hyperliquid: candle fetch failed for {symbol}: {e}")
            return []
        out = []
        for c in raw or []:
            try:
                out.append([int(c["t"]), float(c["o"]), float(c["h"]), float(c["l"]),
                            float(c["c"]), float(c.get("v", 0) or 0)])
            except (KeyError, TypeError, ValueError):
                continue
        return out

    async def fetch_ohlcv(self, symbol, timeframe="1m", since=None, limit=None, **kwargs):
        if symbol not in self.markets_dict:
            return []
        return await self._fetch_candles(symbol, timeframe, limit or 480, since)

    async def fetch_ohlcvs_1m(self, symbol, since=None, limit=None, **kwargs):
        if symbol not in self.markets_dict:
            return []
        return await self._fetch_candles(symbol, "1m", 5000 if limit is None else limit, since)

    async def fetch_pnls(self, start_time=None, end_time=None, limit=None):
        try:
            if start_time is None:
                raw = await asyncio.to_thread(self.info.user_fills, self.query_address)
            else:
                raw = await asyncio.to_thread(
                    self.info.user_fills_by_time, self.query_address, int(start_time), end_time
                )
        except Exception as e:
            logging.error(f"hyperliquid: error fetching pnls: {e}")
            return []
        fills = []
        for f in raw or []:
            coin = f.get("coin", "")
            sym = self.hlname_to_symbol.get(coin) or self.coin_to_symbol(
                coin.split(":", 1)[1] if ":" in coin else coin, verbose=False
            )
            direction = str(f.get("dir", "")).lower()
            fills.append({
                "id": str(f.get("tid", f.get("hash", ""))),
                "symbol": sym,
                "timestamp": int(f.get("time", 0) or 0),
                "pnl": float(f.get("closedPnl", 0) or 0),
                "position_side": "long" if "long" in direction else "short",
                "side": "buy" if f.get("side") == "B" else "sell",
                "qty": float(f.get("sz", 0) or 0),
                "price": float(f.get("px", 0) or 0),
                "fee": float(f.get("fee", 0) or 0),
                "info": f,
            })
        return sorted(fills, key=lambda x: x["timestamp"])

    # ------------------------------------------------------------------ #
    # Order execution
    # ------------------------------------------------------------------ #
    def _order_type_for(self, order):
        """Return (order_type_dict, is_market) for the SDK."""
        if order.get("type") == "market":
            return {"limit": {"tif": "Ioc"}}, True
        tif = require_live_value(self.config, "time_in_force")
        if tif == "post_only":
            return {"limit": {"tif": "Alo"}}, False
        return {"limit": {"tif": "Gtc"}}, False

    async def execute_order(self, order: dict) -> dict:
        if self.hl_exchange is None:
            logging.error("hyperliquid: no signing Exchange (missing private_key)")
            return {}
        try:
            symbol = order["symbol"]
            hlname = self._hlname(symbol)
            is_buy = order["side"] == "buy"
            order_type, is_market = self._order_type_for(order)
            price = float(order["price"])
            if is_market:
                # aggressive crossing price for IOC market orders
                price = price * (1.03 if is_buy else 0.97)
            px = self._round_price(price, symbol)
            sz = self._round_size(order["qty"], symbol)
            if sz <= 0:
                return {}
            reduce_only = bool(order.get("reduce_only", False))
            resp = await asyncio.to_thread(
                self.hl_exchange.order, hlname, is_buy, sz, px, order_type, reduce_only
            )
            return self._parse_order_response(resp, order, sz, px)
        except Exception as e:
            logging.error(f"hyperliquid: error executing order {order}: {e}")
            logging.debug(traceback.format_exc())
            return {}

    def _parse_order_response(self, resp, order, sz, px):
        try:
            if not isinstance(resp, dict) or resp.get("status") != "ok":
                logging.error(f"hyperliquid: order rejected: {resp}")
                return {}
            statuses = resp["response"]["data"]["statuses"]
            st = statuses[0] if statuses else {}
            if "error" in st:
                logging.error(f"hyperliquid: order error: {st['error']}")
                return {}
            info = st.get("resting") or st.get("filled") or {}
            oid = info.get("oid")
            oid_int = int(oid) if oid is not None else None
            if oid_int is not None:
                self._oid_by_id[str(oid_int)] = oid_int
            return {
                "id": oid_int if oid_int is not None else str(order.get("custom_id", "")),
                "symbol": order["symbol"],
                "side": order["side"],
                "amount": sz,
                "price": px,
                "status": "open" if "resting" in st else "closed",
                "info": st,
            }
        except Exception as e:
            logging.error(f"hyperliquid: error parsing order response {resp}: {e}")
            return {}

    async def execute_orders(self, orders):
        if not orders:
            return []
        if len(orders) == 1:
            return [await self.execute_order(orders[0])]
        # Serialize submissions: the SDK nonce is timestamp-ms, so two orders signed in the same
        # millisecond collide ("Invalid nonce: duplicate nonce" rejections observed live Jun 9
        # 2026 during fast grid repricing -- a rejected CANCEL would leave a stale order resting).
        sem = asyncio.Semaphore(1)

        async def _with_sem(o):
            async with sem:
                return await self.execute_order(o)

        return list(await asyncio.gather(*[_with_sem(o) for o in orders]))

    async def execute_cancellation(self, order: dict) -> dict:
        if self.hl_exchange is None:
            return {}
        try:
            symbol = order["symbol"]
            hlname = self._hlname(symbol)
            oid = order.get("id")
            try:
                oid = int(oid)
            except (TypeError, ValueError):
                oid = self._oid_by_id.get(str(order.get("id")))
            if oid is None:
                logging.error(f"hyperliquid: cannot resolve oid for cancel {order}")
                return {}
            resp = await asyncio.to_thread(self.hl_exchange.cancel, hlname, oid)
            if isinstance(resp, dict) and resp.get("status") == "ok":
                return {"id": order.get("id"), "symbol": symbol, "status": "success"}
            logging.error(f"hyperliquid: cancel failed: {resp}")
            return {}
        except Exception as e:
            logging.error(f"hyperliquid: error cancelling order {order}: {e}")
            logging.debug(traceback.format_exc())
            return {}

    async def execute_cancellations(self, orders):
        if not orders:
            return []
        if len(orders) == 1:
            return [await self.execute_cancellation(orders[0])]
        # Serialize like execute_orders: cancels sign with the same timestamp-ms nonce scheme.
        sem = asyncio.Semaphore(1)

        async def _with_sem(o):
            async with sem:
                return await self.execute_cancellation(o)

        return list(await asyncio.gather(*[_with_sem(o) for o in orders]))

    def did_create_order(self, executed) -> bool:
        try:
            return bool(executed) and "id" in executed and executed.get("status") in ("open", "closed")
        except (TypeError, KeyError):
            return False

    def did_cancel_order(self, executed, order=None) -> bool:
        if isinstance(executed, list) and len(executed) == 1:
            return self.did_cancel_order(executed[0], order)
        try:
            return isinstance(executed, dict) and executed.get("status") == "success"
        except (TypeError, KeyError):
            return False

    def get_order_execution_params(self, order: dict) -> dict:
        params = {"reduceOnly": order.get("reduce_only", False)}
        tif = require_live_value(self.config, "time_in_force")
        params["timeInForce"] = "post_only" if tif == "post_only" else "good_till_cancelled"
        return params

    def determine_pos_side(self, order):
        """One-way mode position side derivation (Hyperliquid is not hedge mode)."""
        symbol = order.get("symbol")
        if symbol in getattr(self, "positions", {}):
            if self.positions[symbol]["long"]["size"] != 0.0:
                return "long"
            if self.positions[symbol]["short"]["size"] != 0.0:
                return "short"
        side = order.get("side")
        if order.get("reduceOnly") or order.get("reduce_only"):
            return "short" if side == "buy" else "long"
        return "long" if side == "buy" else "short"

    def format_custom_id_single(self, order_type_id: int) -> str:
        # Hyperliquid uses 16-byte cloids; we track orders by oid instead, so no custom id.
        return ""

    # ------------------------------------------------------------------ #
    # Exchange config (isolated margin + leverage)
    # ------------------------------------------------------------------ #
    async def update_exchange_config(self):
        """No account-level config to set (Hyperliquid is one-way; isolated set per symbol)."""
        pass

    async def update_exchange_config_by_symbols(self, symbols):
        """Set ISOLATED margin + leverage per symbol (is_cross=False)."""
        if self.hl_exchange is None:
            return
        for symbol in symbols:
            try:
                hlname = self._hlname(symbol)
                leverage = int(min(
                    self.max_leverage.get(symbol, 50),
                    self.config_get(["live", "leverage"], symbol=symbol),
                ))
                resp = await asyncio.to_thread(
                    self.hl_exchange.update_leverage, leverage, hlname, False  # is_cross=False -> ISOLATED
                )
                if isinstance(resp, dict) and resp.get("status") == "ok":
                    logging.info(f"{symbol}: set leverage {leverage}x isolated")
                else:
                    logging.error(f"{symbol}: update_leverage response: {resp}")
            except Exception as e:
                logging.error(f"{symbol}: error setting isolated leverage: {e}")
                logging.debug(traceback.format_exc())

    # ------------------------------------------------------------------ #
    # WebSocket order updates
    # ------------------------------------------------------------------ #
    async def watch_orders(self):
        """Subscribe to native SDK order updates and bridge them to the base handler,
        resubscribing if the server closes the socket (HL periodically sends an 'Expired'
        goodbye on an idle orderUpdates stream; the SDK does not auto-recover).

        The probe is deliberately silence-INDEPENDENT (socket/thread state, never message
        recency) so a healthy-but-quiet stream is never mistaken for dead -- that false signal
        is what caused an earlier reconnect storm (fixed in 482e055). If WS setup fails we
        degrade to polling (the base loop still polls open orders/positions/fills each cycle).
        """
        loop = asyncio.get_event_loop()
        await self._subscribe_orders_ws(loop)

        backoff_s = self._ws_resub_check_s
        while not getattr(self, "stop_websocket", False):
            await asyncio.sleep(self._ws_resub_check_s)
            if getattr(self, "stop_websocket", False) or not self.query_address:
                continue
            if not self._ws_subscribed:
                # A prior subscribe failed; retry with backoff. REST polling covers the gap.
                if await self._subscribe_orders_ws(loop):
                    backoff_s = self._ws_resub_check_s
                else:
                    backoff_s = min(backoff_s * 2.0, 60.0)
                    await asyncio.sleep(backoff_s)
                continue
            try:
                dead = self._ws_connection_dead()
            except Exception:
                dead = False
            if dead:
                logging.warning(
                    "hyperliquid: orderUpdates websocket closed server-side "
                    "(e.g. 'Expired'); resubscribing"
                )
                self._health_ws_reconnects = getattr(self, "_health_ws_reconnects", 0) + 1
                await self._subscribe_orders_ws(loop, force=True)

    async def _subscribe_orders_ws(self, loop, force: bool = False) -> bool:
        """(Re)subscribe to the native orderUpdates websocket. Returns True if subscribed.
        Tears down any prior WS Info first (each Info(skip_ws=False) spawns a non-daemon
        websocket thread; leaking them blocks clean process exit / Ctrl-C / restart)."""
        # Never start a new subscribe once shutdown has begun: watch_orders' initial subscribe
        # does not check stop_websocket, so without this a teardown-time call could spawn a fresh
        # native client. close() also cancels+awaits this task before disconnecting, which covers
        # the residual window between this check and the synchronous Info(...) assignment below.
        if getattr(self, "stop_websocket", False):
            return False
        if force:
            self._ws_subscribed = False
        if self._ws_subscribed or not self.query_address:
            return self._ws_subscribed
        try:
            if self.info_ws is not None and hasattr(self.info_ws, "disconnect_websocket"):
                try:
                    await asyncio.to_thread(self.info_ws.disconnect_websocket)
                except Exception:
                    pass
            self.info_ws = Info(
                base_url=self.base_url, skip_ws=False,
                perp_dexs=[self.dex] if self.dex else None,
            )

            def _cb(msg):
                # Deliberately do NOT stamp _ws_last_message_ms here. Hyperliquid's
                # orderUpdates stream is event-driven -- it is silent for minutes when there
                # is no order activity -- so feeding its recency to the base loop's 120s
                # staleness watchdog makes a healthy-but-quiet socket look "stale" and
                # triggers constant false reconnects. WS death is instead detected by
                # _ws_connection_dead() (socket/thread state), and the loop polls
                # positions/orders/balance via REST every cycle, so the message-recency
                # watchdog is intentionally left inert for HL.
                try:
                    updates = self._parse_ws_order_updates(msg)
                    if updates:
                        loop.call_soon_threadsafe(self._safe_handle_order_update, updates)
                except Exception as e:
                    logging.debug(f"hyperliquid ws cb error: {e}")

            await asyncio.to_thread(
                self.info_ws.subscribe,
                {"type": "orderUpdates", "user": self.query_address},
                _cb,
            )
            self._ws_subscribed = True
            logging.info("hyperliquid: subscribed to orderUpdates websocket")
        except Exception as e:
            self._ws_subscribed = False
            logging.warning(f"hyperliquid: ws subscribe failed, falling back to polling: {e}")
        return self._ws_subscribed

    def _ws_connection_dead(self) -> bool:
        """True only when the SDK orderUpdates websocket is *definitively closed* -- not merely
        quiet. Silence-INDEPENDENT: inspects the SDK websocket thread/socket state, never message
        recency, so a healthy-but-idle stream is never mistaken for dead (that false signal is
        what caused the earlier reconnect storm). Catches HL server-initiated closes (the periodic
        'Expired' goodbye) that the SDK does not auto-recover."""
        if not self._ws_subscribed or self.info_ws is None:
            return False
        wsm = getattr(self.info_ws, "ws_manager", None)
        if wsm is None:
            return False  # nothing to introspect -> never risk a false reconnect
        try:
            if hasattr(wsm, "is_alive") and not wsm.is_alive():
                return True   # run_forever() returned -> manager thread died
        except Exception:
            pass
        ws = getattr(wsm, "ws", None)
        if ws is not None and getattr(ws, "keep_running", True) is False:
            return True       # websocket-client flips keep_running False on close
        return False

    def _safe_handle_order_update(self, updates):
        try:
            self.handle_order_update(updates)
        except Exception as e:
            logging.debug(f"hyperliquid: handle_order_update error: {e}")

    def _parse_ws_order_updates(self, msg):
        data = msg.get("data") if isinstance(msg, dict) else None
        if not data:
            return []
        out = []
        for item in data:
            o = item.get("order", item) if isinstance(item, dict) else {}
            coin = o.get("coin", "")
            sym = self.hlname_to_symbol.get(coin) or self.coin_to_symbol(
                coin.split(":", 1)[1] if ":" in coin else coin, verbose=False
            )
            if not sym:
                continue
            side = "buy" if o.get("side") == "B" else "sell"
            try:
                oid = int(o.get("oid"))
            except (TypeError, ValueError):
                oid = None
            qty = float(o.get("sz", 0) or 0)
            price = float(o.get("limitPx", 0) or 0)
            reduce_only = bool(o.get("reduceOnly", False))
            out.append({
                "id": oid,
                "symbol": sym,
                "side": side,
                "qty": qty,
                "amount": qty,
                "price": price,
                "reduceOnly": reduce_only,
                "reduce_only": reduce_only,
                "position_side": self.determine_pos_side({"symbol": sym, "side": side, "reduceOnly": reduce_only}),
                "status": item.get("status") if isinstance(item, dict) else None,
            })
        return out

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #
    async def restart_bot(self):
        logging.info("hyperliquid: initiating bot restart...")
        self.stop_signal_received = True
        self.stop_data_maintainers()
        await self.close()
        raise Exception("Bot will restart.")

    async def close(self):
        # Full teardown, called on every shutdown path via main()'s finally. Stop the watch_orders
        # maintainer FIRST (cancel + await its unwind) so no concurrent initial/resubscribe call can
        # assign a fresh Info AFTER we capture info_ws below -- otherwise a startup/shutdown race
        # leaks the new non-daemon SDK websocket thread (close() captures the (info_ws, info) tuple
        # once, and disconnecting the REST `info` yields, giving a racing subscribe a window to
        # reassign self.info_ws). Awaiting the task to completion makes info_ws final: the SDK
        # Info(...) assignment is synchronous, so a task that reached it has its client on info_ws,
        # and one cancelled earlier never created one. Then disconnect and delegate to base close().
        self.stop_websocket = True
        self._ws_subscribed = False
        ws_task = (getattr(self, "maintainers", {}) or {}).get("watch_orders")
        if ws_task is not None and not ws_task.done():
            ws_task.cancel()
            try:
                await ws_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._ws_task is not None and not self._ws_task.done():
            self._ws_task.cancel()
        for client in (getattr(self, "info_ws", None), getattr(self, "info", None)):
            try:
                if client is not None and hasattr(client, "disconnect_websocket"):
                    await asyncio.to_thread(client.disconnect_websocket)
            except Exception:
                pass
        await super().close()
