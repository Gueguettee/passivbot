"""
Hyperliquid 1-minute OHLCV collector (incl. HIP-3 builder-deployed perps).

Fetches 1m candle history from Hyperliquid's public ``candleSnapshot`` info
endpoint and stores daily .npy files compatible with passivbot backtesting:
  caches/ohlcv/hyperliquid/1m/{COIN}/YYYY-MM-DD.npy
  dtype [('ts', int64), ('o', float32), ('h', float32), ('l', float32), ('c', float32), ('bv', float32)]

The default target is the S&P 500-USDC perp ``xyz:SP500`` (the Trade[XYZ] HIP-3
perp dex). A bare config coin like ``SP500`` is mapped to the Hyperliquid asset
name ``{HL_DEX}:{COIN}`` (default dex ``xyz``); set ``HL_DEX=""`` for main-dex
coins (e.g. BTC) or pass a coin that already contains ``:`` to use it verbatim.

This mirrors src/tools/lighter_ohlcv_collector.py — the storage / gap-fill /
healing / cursor logic is identical (same on-disk format); only the HTTP layer
(POST candleSnapshot), market discovery (meta endpoint) and candle parsing differ.

No credentials required — candleSnapshot and meta are public.
"""

import asyncio
import json
import logging
import os
import random
import signal
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import aiohttp
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)
log = logging.getLogger("hyperliquid-collector")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
HL_API_URL = os.environ.get("HL_API_URL", "https://api.hyperliquid.xyz/info")
HYPERLIQUID_DATA_DIR = Path(os.environ.get("HYPERLIQUID_DATA_DIR", "caches/ohlcv/hyperliquid/1m"))
META_PATH = Path(os.environ.get("HYPERLIQUID_META_PATH", "caches/hyperliquid/market_metadata.json"))
SYMBOLS = os.environ.get("SYMBOLS", "SP500")  # comma-separated config coin tokens
HL_DEX = os.environ.get("HL_DEX", "xyz")  # HIP-3 perp dex namespace ("" = main perp dex)
INTERVAL = os.environ.get("HL_INTERVAL", "1m")
EARLIEST_DATE = os.environ.get("EARLIEST_DATE", "2026-03-18")  # Trade[XYZ] SP500 listing ~2026-03-18
POLL_INTERVAL = int(os.environ.get("POLL_INTERVAL", "60"))
# On a failed poll cycle, retry after this (shorter) interval instead of waiting a full
# POLL_INTERVAL. Defaults to 30 min, but never longer than POLL_INTERVAL itself.
RETRY_INTERVAL = min(int(os.environ.get("RETRY_INTERVAL", "1800")), POLL_INTERVAL)
MAX_CONCURRENT = int(os.environ.get("MAX_CONCURRENT", "2"))
REQUEST_INTERVAL = float(os.environ.get("REQUEST_INTERVAL", "0.25"))  # seconds between requests
RUN_ONCE = os.environ.get("RUN_ONCE", "").strip().lower() in ("1", "true", "yes", "y")

MS_PER_MIN = 60_000
MS_PER_HOUR = 3_600_000
MS_PER_DAY = 86_400_000
# candleSnapshot returns at most 5000 candles per request; stay safely under that.
WINDOW_MIN = int(os.environ.get("HL_WINDOW_MIN", "4000"))
WINDOW_MS = WINDOW_MIN * MS_PER_MIN
SKIP_WINDOW_MS = 3 * MS_PER_DAY  # jump forward when no data found (skip pre-listing fast)
CANDLES_PER_DAY = 1440
# A day whose final minutes are forward-filled (padding) was only partially fetched.
PARTIAL_DAY_TAIL_TOLERANCE_MIN = 10
MAX_HEAL_DAYS = 5
MAX_RETRIES = 8
BACKOFF_BASE = 2.0
BACKOFF_CAP = 120.0
CANDLE_DTYPE = np.dtype(
    [
        ("ts", "<i8"),
        ("o", "<f4"),
        ("h", "<f4"),
        ("l", "<f4"),
        ("c", "<f4"),
        ("bv", "<f4"),
    ]
)

class FetchError(Exception):
    """A candleSnapshot request failed after all HTTP retries (hard failure).

    Distinct from a successful-but-empty response (market closed / no candles in the
    window), which returns ``[]``. Surfacing this lets the poll loop retry sooner.
    """


shutdown_event = asyncio.Event()
_save_locks: dict[str, threading.Lock] = {}


def _get_save_lock(coin: str) -> threading.Lock:
    if coin not in _save_locks:
        _save_locks[coin] = threading.Lock()
    return _save_locks[coin]


def _handle_signal(*_):
    log.info("Shutdown signal received")
    shutdown_event.set()


def coins_from_env() -> list[str]:
    return [s.strip().upper() for s in SYMBOLS.split(",") if s.strip()]


def hl_asset(coin: str) -> str:
    """Map a config coin token to the Hyperliquid asset name.

    ``SP500`` -> ``xyz:SP500`` (with HL_DEX=xyz). A coin already containing ``:``
    is returned verbatim; an empty HL_DEX yields the bare coin (main perp dex).
    """
    if ":" in coin:
        return coin
    return f"{HL_DEX}:{coin}" if HL_DEX else coin


# ---------------------------------------------------------------------------
# Global rate limiter: semaphore + minimum interval between requests
# ---------------------------------------------------------------------------
class RateLimiter:
    def __init__(self, max_concurrent: int, min_interval: float):
        self._sem = asyncio.Semaphore(max_concurrent)
        self._interval = min_interval
        self._lock = asyncio.Lock()
        self._last_request = 0.0

    async def acquire(self):
        await self._sem.acquire()
        async with self._lock:
            now = time.monotonic()
            wait = self._last_request + self._interval - now
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_request = time.monotonic()

    def release(self):
        self._sem.release()


_rate_limiter: RateLimiter = None  # initialized in run()


# ---------------------------------------------------------------------------
# HTTP (POST) with rate limiting, exponential backoff, jitter
# ---------------------------------------------------------------------------
async def post_json(session: aiohttp.ClientSession, url: str, body: dict):
    """POST a JSON body to the Hyperliquid info endpoint; return parsed JSON (list or dict) or None."""
    backoff = BACKOFF_BASE
    for attempt in range(1, MAX_RETRIES + 1):
        await _rate_limiter.acquire()
        try:
            async with session.post(
                url, json=body, timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status == 429 or resp.status >= 500:
                    jitter = backoff * random.uniform(0, 0.25)
                    wait = min(backoff + jitter, BACKOFF_CAP)
                    log.warning(
                        f"HTTP {resp.status} (attempt {attempt}/{MAX_RETRIES}), retrying in {wait:.1f}s"
                    )
                    _rate_limiter.release()
                    await asyncio.sleep(wait)
                    backoff = min(backoff * 2, BACKOFF_CAP)
                    continue

                if resp.status != 200:
                    text = await resp.text()
                    log.error(f"HTTP {resp.status}: {text[:200]}")
                    _rate_limiter.release()
                    return None

                data = await resp.json()
                _rate_limiter.release()
                return data

        except (aiohttp.ClientError, asyncio.TimeoutError) as e:
            _rate_limiter.release()
            jitter = backoff * random.uniform(0, 0.25)
            wait = min(backoff + jitter, BACKOFF_CAP)
            log.warning(
                f"Request error (attempt {attempt}/{MAX_RETRIES}): {e}, retrying in {wait:.1f}s"
            )
            await asyncio.sleep(wait)
            backoff = min(backoff * 2, BACKOFF_CAP)

    log.error(f"All {MAX_RETRIES} retries exhausted for POST {url} {body.get('type')}")
    return None


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
async def fetch_and_cache_meta(session: aiohttp.ClientSession, coins: list[str]) -> dict:
    """Fetch the perp-dex meta and cache per-coin specs (szDecimals, maxLeverage).

    Written to META_PATH as {COIN: {"name", "sz_decimals", "max_leverage"}}, which
    the backtest prep layer uses to refine qty/price steps for each market.
    """
    body = {"type": "meta", "dex": HL_DEX} if HL_DEX else {"type": "meta"}
    data = await post_json(session, HL_API_URL, body)
    out: dict[str, dict] = {}
    if not isinstance(data, dict):
        log.warning(f"meta fetch failed for dex={HL_DEX!r}; backtest will use default market specs")
        return out
    universe = data.get("universe") or []
    by_name = {str(e.get("name", "")): e for e in universe if isinstance(e, dict)}
    for coin in coins:
        asset = hl_asset(coin)
        entry = by_name.get(asset) or by_name.get(coin)
        if not entry:
            log.warning(
                f"[{coin}] asset {asset!r} not found in meta(dex={HL_DEX!r}); "
                f"available: {', '.join(sorted(by_name)[:20])}"
            )
            continue
        out[coin] = {
            "name": entry.get("name"),
            "sz_decimals": entry.get("szDecimals"),
            "max_leverage": entry.get("maxLeverage"),
            "only_isolated": entry.get("onlyIsolated"),
        }
        log.info(
            f"[{coin}] meta: name={entry.get('name')} szDecimals={entry.get('szDecimals')} "
            f"maxLeverage={entry.get('maxLeverage')}"
        )
    if out:
        try:
            META_PATH.parent.mkdir(parents=True, exist_ok=True)
            existing = {}
            if META_PATH.exists():
                try:
                    existing = json.load(open(META_PATH))
                except Exception:
                    existing = {}
            existing.update(out)
            tmp = META_PATH.parent / f"{META_PATH.stem}.tmp.json"
            json.dump(existing, open(tmp, "w"), indent=2)
            if META_PATH.exists():
                META_PATH.unlink()
            tmp.rename(META_PATH)
            log.info(f"Wrote market metadata for {', '.join(out)} -> {META_PATH}")
        except Exception as e:
            log.warning(f"Could not write market metadata: {e}")
    return out


async def fetch_candles(
    session: aiohttp.ClientSession, asset: str, start_ms: int, end_ms: int
) -> list[list]:
    """Fetch 1m candles in [start_ms, end_ms] for a Hyperliquid asset. Returns [[t,o,h,l,c,v], ...]."""
    body = {
        "type": "candleSnapshot",
        "req": {
            "coin": asset,
            "interval": INTERVAL,
            "startTime": int(start_ms),
            "endTime": int(end_ms),
        },
    }
    data = await post_json(session, HL_API_URL, body)
    if data is None:
        # post_json exhausted its retries or hit a non-retryable error -> hard failure.
        raise FetchError(f"candleSnapshot failed for {asset} [{start_ms}..{end_ms}]")
    if not isinstance(data, list):
        return []
    out: list[list] = []
    for c in data:
        try:
            out.append(
                [
                    int(c["t"]),
                    float(c["o"]),
                    float(c["h"]),
                    float(c["l"]),
                    float(c["c"]),
                    float(c.get("v", 0) or 0),
                ]
            )
        except (KeyError, TypeError, ValueError):
            continue
    return out


# ---------------------------------------------------------------------------
# Storage  (identical on-disk format to the Lighter collector)
# ---------------------------------------------------------------------------
def coin_dir(coin: str) -> Path:
    d = HYPERLIQUID_DATA_DIR / coin
    d.mkdir(parents=True, exist_ok=True)
    return d


def day_file(coin: str, date_str: str) -> Path:
    return coin_dir(coin) / f"{date_str}.npy"


def ts_to_date_str(ts_ms: int) -> str:
    return datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


def date_str_to_start_ms(date_str: str) -> int:
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def get_fetched_until(coin: str) -> int | None:
    cursor = coin_dir(coin) / ".fetched_until"
    if cursor.exists():
        try:
            return int(cursor.read_text().strip())
        except (ValueError, OSError):
            return None
    return None


def set_fetched_until(coin: str, ts_ms: int):
    cursor = coin_dir(coin) / ".fetched_until"
    cursor.write_text(str(ts_ms))


def find_resume_ts(coin: str) -> int | None:
    cursor_ts = get_fetched_until(coin)
    if cursor_ts is not None:
        return cursor_ts
    d = coin_dir(coin)
    files = sorted(f for f in d.glob("*.npy") if ".tmp" not in f.name)
    if not files:
        return None
    return date_str_to_start_ms(files[-1].stem)


def cleanup_tmp_files(coin: str):
    for tmp in coin_dir(coin).glob("*.tmp.npy"):
        try:
            tmp.unlink()
            log.info(f"[{coin}] Cleaned stale temp: {tmp.name}")
        except OSError:
            pass


def _trailing_padded_run(arr: np.ndarray) -> int:
    """Count trailing minutes that look forward-filled (padding: bv==0 and o==h==l==c)."""
    if arr.dtype.fields is None or "bv" not in arr.dtype.fields:
        return 0
    o, h, low, c, bv = arr["o"], arr["h"], arr["l"], arr["c"], arr["bv"]
    run = 0
    for i in range(len(arr) - 1, -1, -1):
        if bv[i] == 0.0 and o[i] == h[i] == low[i] == c[i]:
            run += 1
        else:
            break
    return run


def heal_partial_days(coin: str) -> int:
    """Drop + re-queue any trailing partially-fetched (padded) day files. Returns count dropped."""
    d = coin_dir(coin)
    dropped = 0
    earliest_start: int | None = None
    for _ in range(MAX_HEAL_DAYS):
        files = sorted(f for f in d.glob("*.npy") if ".tmp" not in f.name)
        if not files:
            break
        last = files[-1]
        try:
            arr = np.load(str(last))
        except Exception:
            break
        run = _trailing_padded_run(arr)
        if run <= PARTIAL_DAY_TAIL_TOLERANCE_MIN:
            break
        try:
            last.unlink()
        except OSError:
            break
        earliest_start = date_str_to_start_ms(last.stem)
        dropped += 1
        log.info(
            f"[{coin}] Healing partial day {last.stem}: {run} trailing padded minutes -> dropped, will re-fetch"
        )
    if earliest_start is not None:
        set_fetched_until(coin, earliest_start)
    return dropped


def build_daily_array(
    candles: list[list], date_str: str, existing: np.ndarray | None = None
) -> np.ndarray:
    """Build a complete 1440-row daily array, forward/backward filling gaps."""
    day_start_ms = date_str_to_start_ms(date_str)
    values = np.full((CANDLES_PER_DAY, 6), np.nan, dtype=np.float64)
    values[:, 0] = np.arange(CANDLES_PER_DAY, dtype=np.float64) * MS_PER_MIN + day_start_ms

    if existing is not None and existing.shape == (CANDLES_PER_DAY, 6):
        mask = ~np.isnan(existing[:, 1])
        values[mask, 1:] = existing[mask, 1:]
    elif existing is not None and existing.shape == (CANDLES_PER_DAY,):
        if existing.dtype.fields:
            mask = np.isfinite(existing["c"])
            values[mask, 1] = existing["o"][mask]
            values[mask, 2] = existing["h"][mask]
            values[mask, 3] = existing["l"][mask]
            values[mask, 4] = existing["c"][mask]
            values[mask, 5] = existing["bv"][mask]

    for c in candles:
        idx = (int(c[0]) - day_start_ms) // MS_PER_MIN
        if 0 <= idx < CANDLES_PER_DAY:
            values[idx, 1:] = c[1:]

    last_close = np.nan
    for i in range(CANDLES_PER_DAY):
        if np.isnan(values[i, 1]):
            if not np.isnan(last_close):
                values[i, 1:5] = last_close
                values[i, 5] = 0.0
        else:
            last_close = values[i, 4]

    for i in range(CANDLES_PER_DAY):
        if not np.isnan(values[i, 1]):
            if i > 0:
                price = values[i, 1]
                values[:i, 1:5] = price
                values[:i, 5] = 0.0
            break

    arr = np.empty((CANDLES_PER_DAY,), dtype=CANDLE_DTYPE)
    arr["ts"] = values[:, 0].astype(np.int64)
    arr["o"] = values[:, 1].astype(np.float32)
    arr["h"] = values[:, 2].astype(np.float32)
    arr["l"] = values[:, 3].astype(np.float32)
    arr["c"] = values[:, 4].astype(np.float32)
    arr["bv"] = values[:, 5].astype(np.float32)
    return arr


def save_day(coin: str, date_str: str, candles: list[list]):
    """Atomically save/update a daily .npy file."""
    fpath = day_file(coin, date_str)
    lock = _get_save_lock(coin)

    with lock:
        existing = None
        if fpath.exists():
            try:
                existing = np.load(str(fpath))
            except Exception:
                existing = None

        arr = build_daily_array(candles, date_str, existing)

        if np.isnan(arr["c"]).all():
            return

        tmp = fpath.parent / f"{fpath.stem}.tmp.npy"
        np.save(str(tmp), arr)
        if fpath.exists():
            fpath.unlink()
        tmp.rename(fpath)


def group_candles_by_day(candles: list[list]) -> dict[str, list[list]]:
    by_day: dict[str, list[list]] = {}
    for c in candles:
        by_day.setdefault(ts_to_date_str(int(c[0])), []).append(c)
    return by_day


# ---------------------------------------------------------------------------
# Collection
# ---------------------------------------------------------------------------
async def backfill_market(session: aiohttp.ClientSession, coin: str) -> bool:
    """Fetch all available history for one coin via forward windowed paging.

    Returns True if it ran to completion, False if a hard fetch failure aborted it
    (the resume cursor is left intact so the next cycle picks up where it stopped).
    """
    asset = hl_asset(coin)
    cleanup_tmp_files(coin)
    heal_partial_days(coin)
    ok = True

    resume_ts = find_resume_ts(coin)
    if resume_ts:
        start_ms = resume_ts
        log.info(f"[{coin}] ({asset}) Resuming from {ts_to_date_str(resume_ts)}")
    else:
        start_ms = date_str_to_start_ms(EARLIEST_DATE)
        log.info(f"[{coin}] ({asset}) Starting backfill from {EARLIEST_DATE}")

    now_ms = int(time.time() * 1000)
    total_candles = 0
    earliest_seen: int | None = None
    latest_seen: int | None = None
    empty_streak = 0
    window_start = start_ms
    last_log = time.time()

    while window_start < now_ms and not shutdown_event.is_set():
        step = SKIP_WINDOW_MS if empty_streak >= 4 else WINDOW_MS
        window_end = min(window_start + step, now_ms)

        try:
            candles = await fetch_candles(session, asset, window_start, window_end)
        except Exception as e:
            # Hard failure (retries exhausted). Stop and keep the cursor; don't skip the
            # window or we'd leave a permanent gap. Next cycle resumes from here.
            log.error(f"[{coin}] Fetch error at {ts_to_date_str(window_start)}: {e}")
            ok = False
            break

        if candles:
            empty_streak = 0
            total_candles += len(candles)
            cts = [int(c[0]) for c in candles]
            earliest_seen = min(cts) if earliest_seen is None else min(earliest_seen, min(cts))
            latest_seen = max(cts) if latest_seen is None else max(latest_seen, max(cts))
            for date_str, day_candles in group_candles_by_day(candles).items():
                save_day(coin, date_str, day_candles)
            if step == SKIP_WINDOW_MS:
                empty_streak = 0  # found data while skipping -> rescan finely
                continue
        else:
            empty_streak += 1

        if time.time() - last_log > 10:
            pct = (window_start - start_ms) / max(now_ms - start_ms, 1) * 100
            mode = "skip" if empty_streak >= 4 else "scan"
            log.info(
                f"[{coin}] Backfill {pct:.0f}% ({ts_to_date_str(window_start)}) "
                f"— {total_candles} candles [{mode}]"
            )
            last_log = time.time()

        window_start = window_end + 1
        set_fetched_until(coin, window_start)

    if total_candles and earliest_seen is not None:
        span_days = (latest_seen - earliest_seen) / MS_PER_DAY
        log.info(
            f"[{coin}] Backfill done: {total_candles} candles, "
            f"{ts_to_date_str(earliest_seen)} -> {ts_to_date_str(latest_seen)} ({span_days:.1f} days)"
        )
        requested_days = (now_ms - date_str_to_start_ms(EARLIEST_DATE)) / MS_PER_DAY
        if span_days + 2 < requested_days and find_resume_ts(coin) is None:
            log.warning(
                f"[{coin}] Got {span_days:.1f} days but requested ~{requested_days:.0f} days from "
                f"{EARLIEST_DATE}. The candleSnapshot API may retain limited 1m history; "
                f"earliest available is {ts_to_date_str(earliest_seen)}. Set backtest start_date "
                f"accordingly, or source older history from a third-party archive."
            )
    else:
        log.warning(f"[{coin}] Backfill done but no candles were returned for {asset}.")
    return ok


async def update_market(session: aiohttp.ClientSession, coin: str) -> bool:
    """Fetch candles since last cursor using windowed paging (handles large gaps).

    Returns True on a clean cycle, False if a hard fetch failure interrupted it (so the
    caller can retry sooner instead of waiting a full poll interval).
    """
    asset = hl_asset(coin)
    heal_partial_days(coin)
    resume_ts = find_resume_ts(coin)
    if not resume_ts:
        return await backfill_market(session, coin)

    now_ms = int(time.time() * 1000)
    total = 0
    window_start = resume_ts
    ok = True

    while window_start < now_ms and not shutdown_event.is_set():
        window_end = min(window_start + WINDOW_MS, now_ms)
        try:
            candles = await fetch_candles(session, asset, window_start, window_end)
        except Exception as e:
            log.error(f"[{coin}] Update fetch error: {e}")
            ok = False
            break

        if candles:
            total += len(candles)
            for date_str, day_candles in group_candles_by_day(candles).items():
                save_day(coin, date_str, day_candles)

        window_start = window_end + 1
        set_fetched_until(coin, window_start)

    if total > 0:
        log.info(f"[{coin}] Updated: +{total} candles")
    return ok


async def _safe_task(coro, coin: str):
    """Run a collection coro, returning its bool result, or False on an unhandled error."""
    try:
        return await coro
    except Exception as e:
        log.error(f"[{coin}] Unhandled error: {e}", exc_info=True)
        return False


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
async def run():
    global _rate_limiter
    _rate_limiter = RateLimiter(MAX_CONCURRENT, REQUEST_INTERVAL)

    signal.signal(signal.SIGINT, _handle_signal)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _handle_signal)

    coins = coins_from_env()
    log.info("Hyperliquid OHLCV Collector starting")
    log.info(f"  Data dir:        {HYPERLIQUID_DATA_DIR.resolve()}")
    log.info(f"  API URL:         {HL_API_URL}")
    log.info(f"  Perp dex:        {HL_DEX or '(main)'}")
    log.info(f"  Coins:           {', '.join(coins)} -> {', '.join(hl_asset(c) for c in coins)}")
    log.info(f"  Earliest date:   {EARLIEST_DATE}")
    log.info(f"  Window:          {WINDOW_MIN} min/request")
    log.info(f"  Poll interval:   {POLL_INTERVAL}s (retry after {RETRY_INTERVAL}s on failure)")
    log.info(f"  Run once:        {RUN_ONCE}")

    if not coins:
        log.error("No SYMBOLS configured, exiting")
        return

    connector = aiohttp.TCPConnector(resolver=aiohttp.resolver.ThreadedResolver())
    async with aiohttp.ClientSession(connector=connector) as session:
        await fetch_and_cache_meta(session, coins)

        log.info("=== Phase 1: Backfill ===")
        tasks = [_safe_task(backfill_market(session, coin), coin) for coin in coins]
        await asyncio.gather(*tasks)

        if shutdown_event.is_set() or RUN_ONCE:
            reason = "shutdown during backfill" if shutdown_event.is_set() else "run once complete"
            log.info(f"Collector stopped ({reason})")
            return

        log.info("=== Phase 2: Continuous collection ===")
        while not shutdown_event.is_set():
            update_tasks = [_safe_task(update_market(session, coin), coin) for coin in coins]
            results = await asyncio.gather(*update_tasks)
            all_ok = all(r is not False for r in results)
            sleep_s = POLL_INTERVAL if all_ok else RETRY_INTERVAL
            if not all_ok:
                log.warning(
                    f"Poll cycle had failures; retrying in {sleep_s}s "
                    f"(normal interval {POLL_INTERVAL}s)"
                )
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=sleep_s)
            except asyncio.TimeoutError:
                pass

    log.info("Collector stopped")


if __name__ == "__main__":
    asyncio.run(run())
