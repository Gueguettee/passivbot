#!/usr/bin/env python3
"""
Read-only live bot status probe.

This builds the configured bot in debug mode, refreshes exchange/account state, and prints a
sanitized JSON summary. With --dry-cycle it also runs one execution-planning cycle; debug mode
returns the would-cancel/would-create plan without submitting or cancelling anything.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import traceback
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from config_utils import load_config  # noqa: E402
from passivbot import setup_bot  # noqa: E402
from pure_funcs import denumpyize  # noqa: E402


def _summarize_positions(positions: dict) -> dict:
    out = {}
    for symbol, sides in (positions or {}).items():
        entry = {}
        for pside in ("long", "short"):
            pos = (sides or {}).get(pside, {}) or {}
            try:
                size = float(pos.get("size", 0.0) or 0.0)
            except (TypeError, ValueError):
                size = 0.0
            if size != 0.0:
                entry[pside] = {
                    "size": size,
                    "price": pos.get("price", 0.0),
                }
        if entry:
            out[symbol] = entry
    return out


def _summarize_open_orders(open_orders: dict) -> dict:
    out = {}
    for symbol, orders in (open_orders or {}).items():
        rows = []
        for order in orders or []:
            rows.append(
                {
                    "id": order.get("id"),
                    "side": order.get("side"),
                    "position_side": order.get("position_side"),
                    "qty": order.get("qty", order.get("amount")),
                    "price": order.get("price"),
                    "reduce_only": bool(order.get("reduce_only") or order.get("reduceOnly")),
                }
            )
        if rows:
            out[symbol] = rows
    return out


async def _dry_cycle_with_retry(bot, retries: int, delay: float):
    last_exc = None
    for _ in range(max(1, retries)):
        try:
            await bot.update_pos_oos_pnls_ohlcvs()
            return await bot.execute_to_exchange()
        except Exception as exc:
            last_exc = exc
            if "Ema" in str(exc):
                await asyncio.sleep(delay)
                continue
            raise
    raise last_exc


async def collect_status(args) -> dict:
    config = load_config(args.config, live_only=True, verbose=False)
    if args.user:
        config.setdefault("live", {})["user"] = args.user
    config.setdefault("live", {})["warmup_jitter_seconds"] = 0

    bot = setup_bot(config)
    bot.debug_mode = True
    try:
        await bot.start_bot()
        await bot.update_positions_and_balance()
        await bot.update_open_orders()
        account_state = None
        if hasattr(bot, "fetch_account_state"):
            account_state = await bot.fetch_account_state()
            if account_state:
                bot._last_account_state = account_state
                bot._apply_cached_account_state()

        status = {
            "exchange": getattr(bot, "exchange", ""),
            "user": getattr(bot, "user", ""),
            "debug_mode": bool(getattr(bot, "debug_mode", False)),
            "active_symbols": list(getattr(bot, "active_symbols", []) or []),
            "balance": getattr(bot, "balance", None),
            "account_equity": getattr(bot, "account_equity", None),
            "available_margin": getattr(bot, "available_margin", None),
            "unrealized_pnl": getattr(bot, "unrealized_pnl", None),
            "capital_status": bot._capital_status(),
            "positions": _summarize_positions(getattr(bot, "positions", {})),
            "open_orders": _summarize_open_orders(getattr(bot, "open_orders", {})),
            "ws_state": {
                "enabled": bool(getattr(bot, "ws_enabled", False)),
                "subscribed": bool(getattr(bot, "_ws_subscribed", False)),
                "blocked": bool(getattr(bot, "_ws_health_blocked", False)),
                "reconnects": int(getattr(bot, "_health_ws_reconnects", 0) or 0),
            },
            "data_staleness_state": {
                "blocked": bool(getattr(bot, "_data_stale_blocked", False)),
                "consecutive_failures": int(getattr(bot, "_candle_fetch_fails", 0) or 0),
            },
            "engine_status_path": str(getattr(bot, "_engine_status_path", "")),
        }
        if args.dry_cycle:
            to_cancel, to_create = await _dry_cycle_with_retry(
                bot, retries=args.retries, delay=args.retry_delay
            )
            status["dry_cycle"] = {
                "to_cancel_count": len(to_cancel or []),
                "to_create_count": len(to_create or []),
                "to_cancel": to_cancel or [],
                "to_create": to_create or [],
                "engine_diagnostics": getattr(bot, "_last_engine_diagnostics", {}),
            }
        return denumpyize(status)
    finally:
        try:
            await bot.close()
        except Exception:
            pass


def main() -> int:
    parser = argparse.ArgumentParser(description="Print read-only live bot status as JSON.")
    parser.add_argument(
        "--config",
        default="configs/config_sp500.json",
        help="Live config path.",
    )
    parser.add_argument("--user", default=None, help="Override live.user for this probe.")
    parser.add_argument(
        "--dry-cycle",
        action="store_true",
        help="Run one debug planning cycle and include would-cancel/would-create orders.",
    )
    parser.add_argument("--retries", type=int, default=8, help="Dry-cycle EMA retry count.")
    parser.add_argument("--retry-delay", type=float, default=4.0, help="Dry-cycle retry delay.")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print JSON.")
    parser.add_argument(
        "--log-level",
        default="WARNING",
        help="Python logging level for the probe itself.",
    )
    args = parser.parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper(), logging.WARNING))
    try:
        status = asyncio.run(collect_status(args))
    except Exception as exc:
        print(json.dumps({"error": str(exc), "traceback": traceback.format_exc()}, indent=2))
        return 1
    print(json.dumps(status, indent=2 if args.pretty else None, sort_keys=True, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
