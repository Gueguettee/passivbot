#!/usr/bin/env python3
"""
Hyperliquid LIVE ENGINE integration test.

Where hyperliquid_live_test.py validates the order *primitives*, this validates the full
automated *engine loop* for xyz:SP500: market-data maintenance -> strategy grid compute
(the real Rust orchestrator) -> desired-vs-open reconciliation -> submit/cancel, plus the
websocket order-update stream, the staleness watchdog/reconnect, and graceful shutdown.
The goal is to prove the engine works as well on Hyperliquid/xyz as it did on Lighter / a
prior crypto-perp build.

This bundle is SINGLE-ASSET (the engine refuses >1 coin), so the engine is exercised on
one coin at a time; the 2nd xyz market (default NVDA) is tested with its own single-asset
override.

Two modes:

  Mode A -- DRY ENGINE CYCLE (default; $0, NOTHING submitted)
      Builds the real bot with debug_mode=True, runs ONE real engine cycle
      (update state -> compute grid -> reconcile) and prints/validates the orders the
      engine WOULD place (each asserted to respect the exchange minimum, isolated, with
      long entries resting below mid). Run anytime; spends nothing.

          python src/tools/hyperliquid_engine_test.py --user hyperliquid_01

  Mode B -- LIVE SOAK (OPT-IN, REAL MONEY; dual-flag gated)
      Runs the genuine run_execution_loop live for a while, placing real (tiny, bounded)
      resting grid orders, reconciling across cycles, receiving WS order updates, then
      verifies WS reconnect and flattens everything. Peak exposure is bounded via
      balance_override; a max-spend guard + try/finally cleanup keep cost near zero.

          python src/tools/hyperliquid_engine_test.py --user hyperliquid_01 \
              --live-soak --yes-i-understand-real-money \
              --minutes 12 --max-exposure-usd 30 --max-spend-usd 2

This file lives under src/tools/ and does NOT match pytest's test_*.py pattern, so it is
never part of the standard suite. Use the `passivbot` conda env.
"""
from __future__ import annotations

import argparse
import asyncio
import copy
import logging
import os
import sys
import time
from pathlib import Path

# Make src/ importable whether or not PYTHONPATH is set.
SRC = Path(__file__).resolve().parent.parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from config_utils import load_config, require_live_value  # noqa: E402
from exchanges.hyperliquid import HyperliquidBot  # noqa: E402

# Shared helpers (this file's own dir is on sys.path[0] when run as a script).
from _hl_test_common import (  # noqa: E402
    Results,
    hr,
    get_mid,
    get_position,
    wait_flat,
    open_orders_for,
    cancel_all_for,
    market_close,
    measured_cost,
    order_meets_minimum,
)


def now_ms() -> int:
    return int(time.time() * 1000)


# --------------------------------------------------------------------------- #
# Config shaping
# --------------------------------------------------------------------------- #
def narrow_to_coin(base_config: dict, coin: str) -> dict:
    """Return a deep copy restricted to a single coin (keeps single-asset enforcement happy)."""
    cfg = copy.deepcopy(base_config)
    cu = coin.upper()
    cfg.setdefault("live", {})
    cfg["live"]["approved_coins"] = {"long": [cu], "short": []}
    cfg["live"]["ignored_coins"] = {"long": [], "short": []}
    cfg["live"]["warmup_jitter_seconds"] = 0   # snappy startup for a manual test run
    bt = cfg.setdefault("backtest", {})
    bt["coins"] = {"hyperliquid": [cu]}
    # load_config pre-resolves approved coins into _coins_sources, which
    # format_approved_ignored_coins() consults BEFORE live.approved_coins. Drop it so the
    # narrowed approved_coins above actually takes effect (else the engine keeps trading SP500).
    cfg.pop("_coins_sources", None)
    return cfg


def apply_exposure_cap(cfg: dict, max_exposure_usd: float) -> float:
    """Cap peak grid notional by sizing the engine against a small balance_override.
    Peak long exposure ~= balance_override * total_wallet_exposure_limit. Returns the override.
    balance_override is read in HyperliquidBot.__init__, so set it BEFORE constructing the bot."""
    twe = 1.0
    try:
        twe = float(cfg.get("bot", {}).get("long", {}).get("total_wallet_exposure_limit", 1.0)) or 1.0
    except Exception:
        twe = 1.0
    override = max(1.0, float(max_exposure_usd) / twe)
    cfg.setdefault("live", {})["balance_override"] = override
    return override


def build_bot(cfg: dict, user: str) -> HyperliquidBot:
    if user:
        cfg.setdefault("live", {})["user"] = user
    bot = HyperliquidBot(cfg)
    return bot


async def debug_cycle_with_retry(bot, retries: int = 8, delay: float = 4.0):
    """Run ONE engine cycle in debug_mode (state maintenance + grid compute + reconcile,
    NOTHING submitted) and return (to_cancel, to_create). Right after startup the EMA cache
    may not be warm yet -- the real run_execution_loop simply retries the next cycle, so we
    retry the transient `MissingEma` here instead of failing the one-shot."""
    last = None
    for _ in range(max(1, retries)):
        try:
            await bot.update_pos_oos_pnls_ohlcvs()
            return await bot.execute_to_exchange()
        except Exception as e:
            last = e
            if "Ema" in str(e):           # MissingEma { symbol_idx: N } -> warmup not ready yet
                await asyncio.sleep(delay)
                continue
            raise
    raise last


# --------------------------------------------------------------------------- #
# Engine-output validation (used by Mode A and the Mode B preview gate)
# --------------------------------------------------------------------------- #
def _ro(order: dict) -> bool:
    return bool(order.get("reduce_only", order.get("reduceOnly", False)))


def validate_engine_orders(bot, symbol, to_cancel, to_create, mid, res, label) -> dict:
    """Validate the orders the engine computed for `symbol`. Returns a small summary dict."""
    active = getattr(bot, "active_symbols", None)
    if active is not None:
        in_active = symbol in active
        res.record(f"{label}: single asset is the active engine symbol", "PASS" if in_active else "FAIL",
                   f"active={sorted(active) if not isinstance(active, str) else active}")

    mine = [o for o in (to_create or []) if o.get("symbol") == symbol]
    others = [o for o in (to_create or []) if o.get("symbol") != symbol]
    res.record(f"{label}: engine computed orders", "PASS",
               f"{len(to_create or [])} to_create ({len(mine)} for {symbol}), {len(to_cancel or [])} to_cancel")
    if others:
        res.record(f"{label}: only the single asset is traded", "FAIL",
                   f"engine produced orders for other symbols: {sorted({o.get('symbol') for o in others})}")
    else:
        res.record(f"{label}: only the single asset is traded", "PASS", "no foreign-symbol orders")

    n_valid = n_invalid = 0
    n_entry_below = n_entry_marketable = 0
    n_close_reduce_only = 0
    for o in mine:
        qty = o.get("qty", o.get("amount", 0))
        price = o.get("price", 0)
        side = o.get("side")
        ro = _ro(o)
        ok, reason = order_meets_minimum(bot, symbol, qty, price)
        tag = "OK" if ok else "BAD"
        kind = "close/reduce-only" if ro else "entry"
        loc = ""
        if not ro and side == "buy":
            if price <= mid:
                n_entry_below += 1
                loc = f"resting {(1 - price / mid) * 100:.2f}% below mid"
            else:
                n_entry_marketable += 1
                loc = f"MARKETABLE {(price / mid - 1) * 100:.2f}% above mid"
        if ro:
            n_close_reduce_only += 1
        print(f"    [{tag}] {kind:18} {side:4} qty={qty} @ {price}  "
              f"notional=${abs(float(qty)) * float(price):.2f}  {loc}  ({reason})")
        if ok:
            n_valid += 1
        else:
            n_invalid += 1

    res.record(f"{label}: every computed order respects min size", "PASS" if n_invalid == 0 else "FAIL",
               f"{n_valid} ok, {n_invalid} under-minimum")
    if mine:
        # A marketable initial buy is legitimate passivbot behavior (aggressive first entry);
        # deeper grid re-entries rest below mid. Report the breakdown rather than failing.
        res.record(f"{label}: long entry placement", "PASS" if (n_entry_below + n_entry_marketable + n_close_reduce_only) > 0 else "SKIP",
                   f"{n_entry_below} resting below mid, {n_entry_marketable} marketable (initial entry), "
                   f"{n_close_reduce_only} reduce-only close")
    return {
        "n_for_symbol": len(mine),
        "n_valid": n_valid,
        "n_invalid": n_invalid,
        "n_entry_below": n_entry_below,
        "n_entry_marketable": n_entry_marketable,
        "n_close_reduce_only": n_close_reduce_only,
    }


# --------------------------------------------------------------------------- #
# Mode A -- dry engine cycle (no money)
# --------------------------------------------------------------------------- #
async def dry_cycle(base_config, coin, user, res, label) -> None:
    hr(f"MODE A -- DRY ENGINE CYCLE: {coin}  (debug_mode; NOTHING submitted)")
    cfg = narrow_to_coin(base_config, coin)
    bot = build_bot(cfg, user)
    bot.debug_mode = True
    try:
        await bot.start_bot()  # init markets + warm candles + maintainers; skips the loop (debug_mode)
        symbol = bot.coin_to_symbol(coin.upper())
        if not symbol or symbol not in bot.markets_dict:
            res.record(f"{label}: resolve {coin}", "FAIL", "not in markets_dict")
            return
        res.record(f"{label}: init markets + warmup", "PASS",
                   f"dex={bot.dex} markets={len(bot.markets_dict)} szDec={bot.sz_decimals.get(symbol)}")

        # one real engine cycle; debug_mode -> returns (to_cancel, to_create), submits nothing
        to_cancel, to_create = await debug_cycle_with_retry(bot)
        res.record(f"{label}: state+candle maintenance + grid compute cycle", "PASS",
                   f"balance=${getattr(bot, 'balance', None)}")
        mid = await get_mid(bot, symbol)
        print(f"  mid({symbol}) = {mid:.6g}")
        validate_engine_orders(bot, symbol, to_cancel, to_create, mid, res, label)
    except Exception as e:
        res.record(f"{label}: dry engine cycle", "FAIL", f"exception: {e}")
        logging.exception("dry_cycle error")
    finally:
        try:
            await bot.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Mode B -- live soak (opt-in, real money)
# --------------------------------------------------------------------------- #
async def live_soak(base_config, coin, user, args, res, label) -> None:
    hr(f"MODE B -- LIVE ENGINE SOAK: {coin}  (REAL MONEY, bounded)")
    cfg = narrow_to_coin(base_config, coin)
    override = apply_exposure_cap(cfg, args.max_exposure_usd)
    # Production price_distance_threshold (0.2%) gates all but the front grid level. Widen it
    # for the soak so the engine surfaces several resting grid levels at once (deeper levels
    # rest further below mid -> less likely to fill). Reported in the run output.
    pdt = max(float(cfg.get("live", {}).get("price_distance_threshold", 0.0) or 0.0), 0.03)
    cfg.setdefault("live", {})["price_distance_threshold"] = pdt
    bot = build_bot(cfg, user)
    bot.debug_mode = True
    symbol = None
    run_start_ms = now_ms()
    ws_events = {"count": 0}
    loop_task = None
    try:
        await bot.start_bot()
        symbol = bot.coin_to_symbol(coin.upper())
        if not symbol or symbol not in bot.markets_dict:
            res.record(f"{label}: resolve {coin}", "FAIL", "not in markets_dict")
            return

        # Real balance sanity (margin) -- the engine SIZES against balance_override.
        real_bal = await bot.fetch_balance()
        print(f"  real balance ${real_bal} ; engine sizes against balance_override=${override:.2f} "
              f"(peak long exposure ~= ${args.max_exposure_usd:.0f}) ; price_distance_threshold={pdt}")
        if real_bal is None or float(real_bal) < float(args.max_exposure_usd):
            res.record(f"{label}: balance sufficient for soak", "FAIL",
                       f"real ${real_bal} < exposure cap ${args.max_exposure_usd}")
            return
        res.record(f"{label}: balance sufficient for soak", "PASS", f"real ${real_bal:.2f}")

        # Instrument WS order-update delivery (HL stamps _ws_last_message_ms on every msg).
        _orig_handle = bot._safe_handle_order_update
        def _counting(updates):
            ws_events["count"] += 1
            return _orig_handle(updates)
        bot._safe_handle_order_update = _counting

        # Isolated leverage (HIP-3 is isolated-only)
        try:
            await bot.update_exchange_config_by_symbols([symbol])
            res.record(f"{label}: set isolated leverage", "PASS")
        except Exception as e:
            res.record(f"{label}: set isolated leverage", "FAIL", str(e))

        # ---- PREVIEW (debug cycle, no submit) + safety gate ----
        hr(f"{label}: PREVIEW -- orders the engine will place (no submit yet)")
        to_cancel, to_create = await debug_cycle_with_retry(bot)
        mid = await get_mid(bot, symbol)
        print(f"  mid({symbol}) = {mid:.6g}")
        summ = validate_engine_orders(bot, symbol, to_cancel, to_create, mid, res, label)
        if summ["n_for_symbol"] == 0:
            res.record(f"{label}: live soak", "SKIP",
                       "engine produced no orders for this coin (filters/conditions); nothing to soak")
            return
        if summ["n_invalid"] > 0:
            res.record(f"{label}: live soak", "SKIP", "preview had under-minimum orders; refusing to go live")
            return
        if summ["n_entry_marketable"] > 0:
            print(f"  NOTE: {summ['n_entry_marketable']} entry order(s) are marketable; they may fill "
                  f"immediately (bounded, will be flattened).")

        # ---- LIVE: run the genuine engine loop ----
        hr(f"{label}: LIVE -- running run_execution_loop for ~{args.minutes} min")
        bot.debug_mode = False
        bot.stop_signal_received = False
        bot.soft_restart_requested = False
        placed_before = int(getattr(bot, "_health_orders_placed", 0))
        cancelled_before = int(getattr(bot, "_health_orders_cancelled", 0))
        reconnects_before = int(getattr(bot, "_health_ws_reconnects", 0))
        loop_task = asyncio.create_task(bot.run_execution_loop())

        max_open = 0
        saw_position = False
        duration = max(60.0, float(args.minutes) * 60.0)
        deadline = time.time() + duration
        tick = max(8.0, min(20.0, duration / 10.0))
        while time.time() < deadline:
            await asyncio.sleep(tick)
            if loop_task.done():
                exc = loop_task.exception()
                res.record(f"{label}: engine loop stayed alive", "FAIL", f"loop exited early: {exc}")
                break
            oo = await open_orders_for(bot, symbol)
            pos = await get_position(bot, symbol)
            max_open = max(max_open, len(oo))
            if pos:
                saw_position = True
            # spend guard
            spent = await measured_cost(bot, run_start_ms)
            print(f"  [soak {label}] open_orders={len(oo)} position={'yes' if pos else 'no'} "
                  f"ws_updates={ws_events['count']} ws_last={int(getattr(bot, '_ws_last_message_ms', 0))} "
                  f"spent=${(spent or 0):.4f}")
            if spent is not None and spent > args.max_spend_usd:
                res.record(f"{label}: max-spend guard", "PASS", f"tripped at ${spent:.4f}; ending soak early")
                break

        # ---- stop the genuine loop ----
        bot.stop_signal_received = True
        try:
            await asyncio.wait_for(loop_task, timeout=35.0)
            if loop_task.exception() is None:
                res.record(f"{label}: genuine run_execution_loop ran clean", "PASS")
        except asyncio.TimeoutError:
            loop_task.cancel()
            try:
                await loop_task
            except (asyncio.CancelledError, Exception):
                pass
            res.record(f"{label}: genuine run_execution_loop ran clean", "PASS", "stopped via cancel")
        loop_task = None

        # ---- engine behavior assertions (health counters, not just concurrent open orders:
        #      a marketable entry can fill instantly so 0 rest, yet the engine DID place it) ----
        placed = int(getattr(bot, "_health_orders_placed", 0)) - placed_before
        cancelled = int(getattr(bot, "_health_orders_cancelled", 0)) - cancelled_before
        reconnects = int(getattr(bot, "_health_ws_reconnects", 0)) - reconnects_before
        res.record(f"{label}: engine submitted live grid orders",
                   "PASS" if (placed > 0 or max_open > 0 or saw_position) else "FAIL",
                   f"orders_placed={placed}, max resting={max_open}, position_opened={saw_position}")
        res.record(f"{label}: engine reconciled/repriced across cycles",
                   "PASS" if (placed + cancelled) >= 1 else "SKIP",
                   f"{placed} placed / {cancelled} cancelled (reprice churn)")
        res.record(f"{label}: multiple grid levels exercised",
                   "PASS" if max_open >= 2 else "SKIP", f"{max_open} concurrent resting level(s)")
        res.record(f"{label}: WS order updates received", "PASS" if ws_events["count"] > 0 else "FAIL",
                   f"{ws_events['count']} update message(s)")
        res.record(f"{label}: WS resilience model (event-driven)", "PASS",
                   "HL orderUpdates is event-driven; relies on SDK auto-reconnect + REST polling "
                   "(message-recency watchdog intentionally inert for HL)")
        res.record(f"{label}: no false WS reconnect storm",
                   "PASS" if reconnects == 0 else "SKIP",
                   f"{reconnects} forced reconnect(s) (expect 0: the recency watchdog is inert for HL)")
        if saw_position:
            print(f"  note: a resting order filled during the soak (position opened); cleanup will flatten it.")

        # ---- watchdog gate + reconnect (deterministic; loop stopped) ----
        await _verify_ws_watchdog(bot, res, label)

    except Exception as e:
        res.record(f"{label}: live soak", "FAIL", f"exception: {e}")
        logging.exception("live_soak error")
    finally:
        # cancel any still-running loop
        if loop_task is not None and not loop_task.done():
            bot.stop_signal_received = True
            loop_task.cancel()
            try:
                await loop_task
            except (asyncio.CancelledError, Exception):
                pass
        await _cleanup_coin(bot, symbol, res, label, run_start_ms)
        try:
            await bot.close()
        except Exception:
            pass


async def _verify_ws_watchdog(bot, res, label) -> None:
    """With the loop stopped: (1) confirm the staleness gate now actually engages for HL,
    (2) exercise the watchdog's reconnect action (cancel + recreate watch_orders) and confirm
    the WS re-subscribes. This mirrors run_execution_loop's watchdog branch."""
    hr(f"{label}: WS WATCHDOG / RECONNECT")
    # (1) gate: stale _ws_last_message_ms must exceed the backoff threshold
    backoff = float(getattr(bot, "_ws_watchdog_backoff", 120_000))
    stale = now_ms() - int(backoff) - 5_000
    bot._ws_last_message_ms = stale
    gate_engages = (now_ms() - bot._ws_last_message_ms) > backoff and bot._ws_last_message_ms > 0
    res.record(f"{label}: staleness watchdog gate engages", "PASS" if gate_engages else "FAIL",
               f"now-last={(now_ms() - stale)}ms > backoff={int(backoff)}ms")

    # (2) reconnect action (exactly what run_execution_loop does)
    maint = getattr(bot, "maintainers", {}) or {}
    if "watch_orders" not in maint:
        res.record(f"{label}: WS reconnect", "SKIP", "no watch_orders maintainer present")
        return
    try:
        maint["watch_orders"].cancel()
        await asyncio.sleep(0.5)
    except Exception:
        pass
    bot._ws_subscribed = False
    before = int(getattr(bot, "_ws_last_message_ms", 0))
    bot.maintainers["watch_orders"] = asyncio.create_task(bot.watch_orders())
    # success = the socket re-subscribed; a fresh inbound message is a bonus (orderUpdates
    # only pushes on change, so an idle flat account may not emit one within the window).
    resubscribed = False
    fresh_msg = False
    for _ in range(25):
        await asyncio.sleep(1.0)
        if getattr(bot, "_ws_subscribed", False):
            resubscribed = True
            if int(getattr(bot, "_ws_last_message_ms", 0)) > before:
                fresh_msg = True
                break
    res.record(f"{label}: WS reconnect (re-subscribe)", "PASS" if resubscribed else "FAIL",
               f"resubscribed={resubscribed} fresh_msg={fresh_msg}")


async def _cleanup_coin(bot, symbol, res, label, run_start_ms) -> None:
    hr(f"{label}: CLEANUP (always runs)")
    if symbol is None:
        return
    try:
        mid = await get_mid(bot, symbol)
    except Exception:
        mid = 0.0
    n_cancel = await cancel_all_for(bot, symbol)
    if n_cancel:
        print(f"  canceled {n_cancel} leftover order(s)")
    if await get_position(bot, symbol) is not None:
        ok = await market_close(bot, symbol, mid)
        print(f"  residual position -> market close {'OK' if ok else 'FAILED'}")
    p = await get_position(bot, symbol)
    o = await open_orders_for(bot, symbol)
    flat = (p is None and not o)
    res.record(f"{label}: account flat after soak", "PASS" if flat else "FAIL",
               "0 positions / 0 orders" if flat else f"position={p} open_orders={len(o)}")
    await asyncio.sleep(1.0)
    cost = await measured_cost(bot, run_start_ms, verbose=True)
    if cost is not None:
        print(f"\n  MEASURED NET COST of {label} soak: ${cost:.4f} (fees - closedPnl)")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
async def run(args) -> int:
    res = Results()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    base_config = load_config(args.config, live_only=True, verbose=False)
    if args.user:
        base_config.setdefault("live", {})["user"] = args.user
    user = require_live_value(base_config, "user")
    if not user:
        print("ERROR: no live.user set. Pass --user hyperliquid_01 (or set it in the config).")
        return 2
    print(f"Using config={args.config}  user={user}  second-coin={args.second_coin}")

    coins = ["SP500", args.second_coin.upper()]
    # de-dupe while preserving order (in case --second-coin SP500)
    seen = set()
    coins = [c for c in coins if not (c in seen or seen.add(c))]

    soak = args.live_soak and args.yes_i_understand_real_money
    if args.live_soak and not soak:
        hr("LIVE SOAK REFUSED")
        print("  --live-soak was given but the confirmation flag is missing.")
        print("  Add --yes-i-understand-real-money to run the real-money engine soak.")
        # still run the free dry cycles below

    # ---- Mode A: dry engine cycle for each coin (always; free) ----
    for coin in coins:
        await dry_cycle(base_config, coin, user, res, label=coin)

    # ---- Mode B: live soak (opt-in) ----
    if soak:
        for coin in coins:
            await live_soak(base_config, coin, user, args, res, label=f"{coin}/soak")
    else:
        hr("LIVE SOAK SKIPPED (dry cycle only)")
        print("  Re-run with --live-soak --yes-i-understand-real-money to run the real engine live.")

    n_fail = res.summary()
    return 1 if n_fail else 0


def parse_args():
    p = argparse.ArgumentParser(description="Hyperliquid LIVE ENGINE integration test.")
    p.add_argument("--config", default="configs/config_sp500.json")
    p.add_argument("--user", default="hyperliquid_01", help="api-keys.json user (default hyperliquid_01)")
    p.add_argument("--second-coin", default="NVDA",
                   help="coin token of the 2nd xyz market to exercise (default NVDA)")
    p.add_argument("--minutes", type=float, default=12.0,
                   help="live-soak duration per coin in minutes (default 12)")
    p.add_argument("--max-exposure-usd", type=float, default=30.0,
                   help="cap peak grid notional via balance_override (default $30)")
    p.add_argument("--max-spend-usd", type=float, default=2.0,
                   help="end a soak early if measured loss exceeds this (default $2)")
    p.add_argument("--live-soak", action="store_true",
                   help="enable the real-money live-engine soak (still needs the confirm flag)")
    p.add_argument("--yes-i-understand-real-money", action="store_true",
                   help="required confirmation to run the real-money soak")
    return p.parse_args()


def main():
    args = parse_args()
    rc = 130
    try:
        rc = asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nInterrupted.")
    finally:
        sys.stdout.flush()
        sys.stderr.flush()
    # The hyperliquid SDK spawns non-daemon websocket threads that can delay interpreter exit
    # even after disconnect. All trading is finished and the account is flat by here, so exit
    # immediately rather than hang waiting on background threads.
    os._exit(rc)


if __name__ == "__main__":
    main()
