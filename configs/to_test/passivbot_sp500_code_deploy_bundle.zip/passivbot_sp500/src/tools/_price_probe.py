"""Read-only probe: compare the live Hyperliquid xyz SP500 mark/oracle/mid price
against the bot's resting orders. No SDK, no signing -- public info endpoint only.
Prints prices and open orders; never prints the private key."""
import json, urllib.request, os

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
with open(os.path.join(ROOT, "api-keys.json")) as f:
    keys = json.load(f)
# api-keys.json maps account name -> {wallet_address, private_key, ...}
acct = keys.get("hyperliquid_01") or next(iter(keys.values()))
DEX = (acct.get("dex") or "xyz").strip()
# Replicate the bot's query_address logic (hyperliquid.py:66-73): subaccount wins.
addr = (acct.get("subaccount_address") or "").strip() or acct.get("wallet_address")
COIN = f"{DEX}:SP500"   # full hlname, e.g. "xyz:SP500"
print(f"query_address = {addr[:6]}...{addr[-4:]} | dex = {DEX} | coin = {COIN}\n")

URL = "https://api.hyperliquid.xyz/info"

def post(body):
    req = urllib.request.Request(URL, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())

# 1) mark/oracle/mid for SP500 on the xyz dex
meta = post({"type": "metaAndAssetCtxs", "dex": "xyz"})
universe = meta[0]["universe"]
ctxs = meta[1]
idx = next((i for i, u in enumerate(universe)
            if u["name"] == COIN or u["name"].split(":", 1)[-1] == "SP500"), None)
print("== xyz dex SP500 market ==")
if idx is None:
    print("  SP500 not found in xyz universe! names:", [u["name"] for u in universe])
else:
    c = ctxs[idx]
    print(f"  markPx   = {c.get('markPx')}")
    print(f"  oraclePx = {c.get('oraclePx')}")
    print(f"  midPx    = {c.get('midPx')}")
    print(f"  prevDayPx= {c.get('prevDayPx')}")
    print(f"  funding  = {c.get('funding')}")
    print(f"  openInterest = {c.get('openInterest')}  dayNtlVlm = {c.get('dayNtlVlm')}")

# 2) bot's resting orders right now
oo = post({"type": "frontendOpenOrders", "user": addr, "dex": "xyz"})
print(f"\n== open orders ({len(oo)}) ==")
for o in oo:
    print(f"  {o.get('side')} {o.get('sz')} @ {o.get('limitPx')}  coin={o.get('coin')} oid={o.get('oid')}")

# 2b) allMids (REST) -- second independent price cross-check
try:
    mids = post({"type": "allMids", "dex": DEX})
    print(f"\n== allMids REST: {COIN} = {mids.get(COIN)}  (bare SP500 = {mids.get('SP500')}) ==")
except Exception as e:
    print(f"\n== allMids REST failed: {e} ==")

# 2c) candleSnapshot (REST) -- the exact source the bot builds candles from.
# Pull the last few 1m candles; compare the newest close to mark/mid above.
try:
    # interval/startTime: last ~10 minutes of 1m candles. Use a fixed recent window
    # via the info endpoint; HL expects ms epoch. We derive 'now' from the mark ctx
    # response time indirectly -- instead ask for a wide window using a large count.
    snap = post({"type": "candleSnapshot",
                 "req": {"coin": COIN, "interval": "1m",
                         "startTime": 0, "endTime": 99999999999999},
                 "dex": DEX})
    print(f"\n== candleSnapshot 1m REST (last 6 of {len(snap)}) ==")
    for c in snap[-6:]:
        print(f"  t={c.get('t')} o={c.get('o')} h={c.get('h')} l={c.get('l')} c={c.get('c')} v={c.get('v')} n={c.get('n')}")
except Exception as e:
    print(f"\n== candleSnapshot REST failed: {e} ==")

# 3) position + account value
ch = post({"type": "clearinghouseState", "user": addr, "dex": DEX})
ms = ch.get("marginSummary", {})
print(f"\n== account ==")
print(f"  accountValue = {ms.get('accountValue')}")
print(f"  totalRawUsd  = {ms.get('totalRawUsd')}")
aps = ch.get("assetPositions", [])
print(f"  positions: {len(aps)}")
for p in aps:
    pos = p.get("position", {})
    print(f"    {pos.get('coin')} szi={pos.get('szi')} entryPx={pos.get('entryPx')} uPnl={pos.get('unrealizedPnl')}")
