#!/usr/bin/env python3
"""
Hyperliquid LIVE integration test for the native HyperliquidBot.

Exercises the real live-trading primitives of src/exchanges/hyperliquid.py against a
real account/subaccount, to prove the live path works before relying on it:

    - checking balance / positions / open orders        (read-only)
    - placing a LIMIT order and CANCELING it            (no fill -> free)
    - OPENING a position via a MARKET order             (small real-money cost)
    - CLOSING a position via MARKET (SP500) or LIMIT (2nd market)

It is run on xyz:SP500 plus one other xyz market (default NVDA).

For the full LIVE ENGINE (the automated run loop: strategy grid compute -> reconcile ->
submit/cancel, WS order updates, watchdog) see the companion tool
src/tools/hyperliquid_engine_test.py.

================================  REAL MONEY  ================================
The trading phase spends REAL money (tiny taker fees + spread on ~$10-15 orders).
It is OPT-IN and is NOT part of the standard test suite (this file is under
src/tools/, not tests/, and does not match pytest's test_*.py pattern, so pytest
never collects it). By default this script runs ONLY the read-only checks.

To run the trading phase you must pass BOTH flags explicitly:
    --live-trade --yes-i-understand-real-money
=============================================================================

Minimum order sizes are always computed from the bot's OWN specs
(min_costs / min_qtys / qty_steps) and every order is asserted to satisfy the
exchange minimum BEFORE it is submitted -- an under-minimum order is never sent.

Usage (use the `passivbot` conda env; PYTHONPATH is handled automatically):
    python src/tools/hyperliquid_live_test.py                  # read-only
    python src/tools/hyperliquid_live_test.py --live-trade --yes-i-understand-real-money
    python src/tools/hyperliquid_live_test.py --live-trade --yes-i-understand-real-money \
        --second-market AAPL --max-spend-usd 1.0
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
import time
from pathlib import Path

# Make src/ importable whether or not PYTHONPATH is set.
SRC = Path(__file__).resolve().parent.parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from config_utils import load_config, require_live_value  # noqa: E402
from exchanges.hyperliquid import HyperliquidBot  # noqa: E402

# Shared test helpers (this file's own dir is on sys.path[0] when run as a script).
from _hl_test_common import (  # noqa: E402
    Results,
    hr,
    min_valid_size,
    get_mid,
    get_position,
    wait_position,
    wait_flat,
    open_orders_for,
    cancel_all_for,
    market_close,
    measured_cost,
)


# --------------------------------------------------------------------------- #
# Phase A -- read-only
# --------------------------------------------------------------------------- #
async def phase_a(bot, symbols: list[str], res: Results) -> dict:
    hr("PHASE A -- READ-ONLY CHECKS (no money spent)")
    info = {}

    balance = await bot.fetch_balance()
    if balance is None or not isinstance(balance, (int, float)):
        res.record("check balance", "FAIL", f"got {balance!r}")
    else:
        res.record("check balance", "PASS", f"${balance:.2f} on dex '{bot.dex}'")
    info["balance"] = balance

    positions = await bot.fetch_positions()
    res.record("fetch positions", "PASS" if positions is not None else "FAIL",
               f"{len(positions or [])} open")
    for p in positions or []:
        print(f"      position: {p['symbol']} {p['position_side']} size={p['size']} @ {p['price']}")

    orders = await bot.fetch_open_orders()
    res.record("fetch open orders", "PASS" if orders is not None else "FAIL",
               f"{len(orders or [])} open")
    for o in orders or []:
        print(f"      order: {o['symbol']} {o['side']} qty={o['qty']} @ {o['price']} id={o['id']}")

    hr("MARKET SPECS + MINIMUM VALID ORDER SIZE (from the bot's own specs)")
    for sym in symbols:
        if sym not in bot.markets_dict:
            res.record(f"resolve market {sym}", "FAIL", "not in markets_dict")
            continue
        mid = await get_mid(bot, sym)
        mn = min_valid_size(bot, sym, mid, buffer=1.0)        # bare minimum (no buffer)
        print(f"  {sym}: mid={mid:.6g}  szDec={bot.sz_decimals.get(sym)}  "
              f"qty_step={bot.qty_steps[sym]}  min_qty={bot.min_qtys[sym]}  "
              f"min_cost=${bot.min_costs[sym]:.2f}  price_step={bot.price_steps[sym]}  "
              f"maxLev={bot.max_leverage.get(sym)}")
        print(f"      -> min valid qty (no buffer) = {mn} (notional ${mn*mid:.2f})")
        info[sym] = {"mid": mid}
    return info


# --------------------------------------------------------------------------- #
# Phase B -- trading (one market)
# --------------------------------------------------------------------------- #
async def trade_one_market(bot, symbol: str, close_via: str, args, res: Results) -> None:
    """close_via: 'market' or 'limit'."""
    hr(f"PHASE B -- TRADING {symbol}  (close via {close_via})")
    mid = await get_mid(bot, symbol)
    qty = min_valid_size(bot, symbol, mid, buffer=args.notional_buffer)
    print(f"  mid={mid:.6g}  test qty={qty}  notional=${qty*mid:.2f}  "
          f"(min_cost=${bot.min_costs[symbol]:.2f})")

    # B0 -- isolated leverage
    try:
        await bot.update_exchange_config_by_symbols([symbol])
        res.record(f"{symbol}: set isolated leverage", "PASS")
    except Exception as e:
        res.record(f"{symbol}: set isolated leverage", "FAIL", str(e))

    # B1 -- place non-marketable limit + cancel (no fill, free)
    limit_px = bot._round_price(mid * (1 - args.limit_offset), symbol)
    placed = await bot.execute_order({
        "symbol": symbol, "side": "buy", "qty": qty,
        "price": limit_px, "reduce_only": False,
    })
    oid = placed.get("id") if isinstance(placed, dict) else None
    if bot.did_create_order(placed) and oid is not None:
        res.record(f"{symbol}: place limit order", "PASS",
                   f"id={oid} @ {limit_px} (5% below mid, resting)")
        # verify it shows up
        found = [o for o in await open_orders_for(bot, symbol) if str(o["id"]) == str(oid)]
        res.record(f"{symbol}: limit visible in open orders",
                   "PASS" if found else "FAIL", f"{len(found)} match")
        # cancel it
        cres = await bot.execute_cancellation({"symbol": symbol, "id": oid})
        if bot.did_cancel_order(cres):
            gone = not [o for o in await open_orders_for(bot, symbol) if str(o["id"]) == str(oid)]
            res.record(f"{symbol}: cancel order", "PASS" if gone else "FAIL",
                       "removed from book" if gone else "still present")
        else:
            res.record(f"{symbol}: cancel order", "FAIL", f"cancel resp {cres}")
    else:
        res.record(f"{symbol}: place limit order", "FAIL", f"resp {placed}")

    # B2 -- open via market (IOC)
    opened = await bot.execute_order({
        "symbol": symbol, "side": "buy", "qty": qty,
        "price": mid, "type": "market", "reduce_only": False,
    })
    pos = await wait_position(bot, symbol, timeout=12.0)
    if pos is not None and float(pos["size"]) > 0:
        res.record(f"{symbol}: open position (market order)", "PASS",
                   f"size={pos['size']} entry={pos['price']}")
    else:
        res.record(f"{symbol}: open position (market order)", "FAIL",
                   f"no position after open resp={opened}")
        return  # nothing to close

    actual = abs(float(pos["size"]))

    # B3 -- close
    if close_via == "market":
        ok = await market_close(bot, symbol, mid)
        res.record(f"{symbol}: close via MARKET", "PASS" if ok else "FAIL",
                   "flat" if ok else "still open -> cleanup will retry")
    else:
        cross_px = bot._round_price(mid * (1 - args.close_cross), symbol)
        await bot.execute_order({
            "symbol": symbol, "side": "sell", "qty": actual,
            "price": cross_px, "reduce_only": True,
        })
        ok = await wait_flat(bot, symbol, timeout=15.0)
        if not ok:
            print(f"  limit close did not fill in time; falling back to market close")
            ok = await market_close(bot, symbol, mid)
            res.record(f"{symbol}: close via LIMIT", "FAIL",
                       "limit did not fill; market fallback " + ("flat" if ok else "FAILED"))
        else:
            res.record(f"{symbol}: close via LIMIT", "PASS", f"reduce-only limit @ {cross_px} filled")


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
async def run(args) -> int:
    res = Results()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    config = load_config(args.config, live_only=True, verbose=False)
    if args.user:
        config["live"]["user"] = args.user
    user = require_live_value(config, "user")
    if not user:
        print("ERROR: no live.user set. Pass --user hyperliquid_01 (or set it in the config).")
        return 2
    print(f"Using config={args.config}  user={user}")

    bot = HyperliquidBot(config)
    if bot.exchange != "hyperliquid":
        print(f"ERROR: user '{user}' is exchange '{bot.exchange}', not hyperliquid.")
        return 2
    await bot.init_markets()
    print(f"Connected. dex={bot.dex} query_address={bot.query_address} "
          f"vaultAddress={bot.vault_action_address} markets={len(bot.markets_dict)}")

    sp500 = bot.coin_to_symbol("SP500")
    second = bot.coin_to_symbol(args.second_market.upper())
    if not sp500 or sp500 not in bot.markets_dict:
        print("ERROR: xyz:SP500 not found in markets.")
        return 2
    if not second or second not in bot.markets_dict:
        print(f"ERROR: second market '{args.second_market}' not found in xyz markets.")
        return 2
    symbols = [sp500, second]

    info = await phase_a(bot, symbols, res)

    trade_enabled = args.live_trade and args.yes_i_understand_real_money
    if not args.live_trade:
        hr("TRADING PHASE SKIPPED (read-only)")
        print("  Re-run with:  --live-trade --yes-i-understand-real-money   to test order flow.")
        res.summary()
        await bot.close()
        return 0
    if not trade_enabled:
        hr("TRADING REFUSED")
        print("  --live-trade was given but the confirmation flag is missing.")
        print("  Add --yes-i-understand-real-money to actually place real-money orders.")
        res.summary()
        await bot.close()
        return 2

    # balance floor check before spending
    bal = info.get("balance")
    floor = 25.0
    if not isinstance(bal, (int, float)) or bal < floor:
        hr("TRADING ABORTED -- insufficient balance")
        print(f"  balance ${bal} < required floor ${floor} on dex '{bot.dex}'.")
        res.summary()
        await bot.close()
        return 2

    run_start_ms = int(time.time() * 1000)
    try:
        await trade_one_market(bot, sp500, "market", args, res)
        # cheap guard: stop if we've already spent more than the cap
        spent = await measured_cost(bot, run_start_ms)
        if spent is not None and spent > args.max_spend_usd:
            print(f"\n  measured loss ${spent:.4f} exceeds --max-spend-usd "
                  f"${args.max_spend_usd}; skipping the second market.")
            res.record(f"{second}: trading", "SKIP", "max-spend guard tripped")
        else:
            await trade_one_market(bot, second, "limit", args, res)
    finally:
        hr("PHASE C -- CLEANUP (always runs)")
        mids = {}
        for sym in symbols:
            try:
                mids[sym] = await get_mid(bot, sym)
            except Exception:
                mids[sym] = info.get(sym, {}).get("mid", 0.0)
        for sym in symbols:
            n_cancel = await cancel_all_for(bot, sym)
            if n_cancel:
                print(f"  {sym}: canceled {n_cancel} leftover order(s)")
            if await get_position(bot, sym) is not None:
                ok = await market_close(bot, sym, mids[sym])
                print(f"  {sym}: residual position -> market close {'OK' if ok else 'FAILED'}")
        # final flat assertion
        all_flat = True
        for sym in symbols:
            p = await get_position(bot, sym)
            o = await open_orders_for(bot, sym)
            if p is not None or o:
                all_flat = False
                print(f"  WARNING: {sym} not clean -- position={p} open_orders={len(o)}")
        res.record("cleanup: account flat", "PASS" if all_flat else "FAIL",
                   "0 positions / 0 orders on test symbols" if all_flat else "see warnings above")

        # cost report
        await asyncio.sleep(1.0)
        cost = await measured_cost(bot, run_start_ms, verbose=True)
        if cost is not None:
            print(f"\n  MEASURED NET COST of trading run: ${cost:.4f} "
                  f"(taker fees + spread; closed PnL netted)")

    res.summary()
    final_bal = await bot.fetch_balance()
    print(f"\n  final balance: ${final_bal:.4f} on dex '{bot.dex}'")
    await bot.close()
    return 0


def parse_args():
    p = argparse.ArgumentParser(description="Hyperliquid live integration test (opt-in real money).")
    p.add_argument("--config", default="configs/config_sp500.json")
    p.add_argument("--user", default="hyperliquid_01",
                   help="api-keys.json user (default hyperliquid_01)")
    p.add_argument("--second-market", default="NVDA",
                   help="coin token of the 2nd xyz market to test (default NVDA)")
    p.add_argument("--live-trade", action="store_true",
                   help="enable the real-money trading phase (still needs the confirm flag)")
    p.add_argument("--yes-i-understand-real-money", action="store_true",
                   help="required confirmation to actually place real-money orders")
    p.add_argument("--max-spend-usd", type=float, default=2.0,
                   help="abort remaining trades if measured loss exceeds this (default $2)")
    p.add_argument("--notional-buffer", type=float, default=1.15,
                   help="multiply the $ min-notional by this when sizing (default 1.15)")
    p.add_argument("--limit-offset", type=float, default=0.05,
                   help="resting test limit is placed this fraction below mid (default 0.05)")
    p.add_argument("--close-cross", type=float, default=0.003,
                   help="limit-close price is this fraction through mid to fill (default 0.003)")
    return p.parse_args()


def main():
    args = parse_args()
    try:
        rc = asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nInterrupted.")
        rc = 130
    sys.exit(rc)


if __name__ == "__main__":
    main()
