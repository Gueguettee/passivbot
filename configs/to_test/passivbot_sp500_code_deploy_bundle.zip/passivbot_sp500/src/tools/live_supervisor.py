#!/usr/bin/env python3
"""
Live churn watchdog + soft-stop controller for the DOCKERIZED SP500 passivbot.

Runs on the HOST (conda env). It read-only-monitors the Hyperliquid `xyz` account and,
if the churn/bleed circuit-breaker trips, performs a SOFT stop:

    1) cancels all open SP500 orders (stops churn within seconds), then
    2) recreates the dockerized bot in `tp_only` mode (no new entries / no DCA; profitable
       take-profit closes are kept) via:
         docker compose -f docker-compose.yml -f docker-compose.tponly.yml up -d passivbot-live

Docker owns the bot lifecycle (the `passivbot-live` service); this watchdog does NOT launch
the bot. It only watches and, on trip, cancels orders + flips the container to tp_only.

Why a watchdog at all: the bot has no built-in trade-rate guard, and the prior failure mode
was "many fast trades bleeding to fees/slippage". This is the autonomous safety net.

Breaker (moderate defaults) trips if:
    (fills_10m >= fill_rate_max  AND  bleed_10m% > bleed_pct_max)
    OR  equity < (1 - equity_dd_max%) * start_equity

State is written to runs/sp500_live/status.json every poll (so a separate process / the
operator can read it) and appended to runs/sp500_live/monitor.log. run_start / start_equity /
trip state persist across watchdog restarts by reloading status.json on startup.

Usage (passivbot conda env):
    python src/tools/live_supervisor.py                 # monitor + enforce (live)
    python src/tools/live_supervisor.py --once          # single poll, print + exit
    python src/tools/live_supervisor.py --dry-run       # on trip, LOG the action but do nothing
    python src/tools/live_supervisor.py --selftest      # offline predicate unit tests, no network
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import subprocess
import sys
import time
from pathlib import Path

# Make src/ importable whether or not PYTHONPATH is set (mirrors hyperliquid_live_test.py).
SRC = Path(__file__).resolve().parent.parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

# _hl_test_common lives in this same dir (src/tools), which is sys.path[0] when run as a script.
from _hl_test_common import cancel_all_for, get_position, open_orders_for  # noqa: E402


# --------------------------------------------------------------------------- #
# Circuit-breaker predicate (PURE — unit-testable, no I/O)
# --------------------------------------------------------------------------- #
def evaluate_breaker(
    *,
    fills_10m: int,
    bleed_pct: float,
    equity: float,
    start_equity: float,
    fill_rate_max: int,
    bleed_pct_max: float,
    equity_dd_max: float,
) -> tuple[bool, list[str]]:
    """Return (tripped, reasons).

    bleed_pct / bleed_pct_max / equity_dd_max are all in PERCENT (e.g. 0.5 == 0.5%).
    churn   = high fill-rate AND net bleed over the window (the prior failure mode).
    drawdown = equity fell more than equity_dd_max% below the run's start (slow-bleed backstop).
    """
    reasons: list[str] = []
    churn = (fills_10m >= fill_rate_max) and (bleed_pct > bleed_pct_max)
    if churn:
        reasons.append(
            f"churn: {fills_10m} fills/10m >= {fill_rate_max} AND bleed {bleed_pct:.3f}% > {bleed_pct_max}%"
        )
    drawdown = start_equity > 0 and equity < (1.0 - equity_dd_max / 100.0) * start_equity
    if drawdown:
        dd_pct = (equity / start_equity - 1.0) * 100.0
        reasons.append(
            f"drawdown: equity ${equity:.2f} is {dd_pct:+.2f}% vs start ${start_equity:.2f} "
            f"(limit -{equity_dd_max:.2f}%)"
        )
    return (churn or drawdown), reasons


def _selftest() -> int:
    """Offline unit tests for the trip predicate. Exit 0 == all pass."""
    cases = [
        # (fills, bleed%, equity, start, expect_trip, label)
        (15, 0.6, 300, 300, True, "high fills + bleed -> trip"),
        (8, 0.6, 300, 300, False, "low fills, high bleed -> no trip"),
        (15, 0.3, 300, 300, False, "high fills, low bleed -> no trip"),
        (12, 0.51, 300, 300, True, "exactly at fill threshold + bleed -> trip"),
        (0, 0.0, 282.0, 300, True, "equity -6% -> trip (drawdown backstop)"),
        (0, 0.0, 286.0, 300, False, "equity -4.7% -> no trip"),
        (0, 0.0, 305.0, 300, False, "equity up, no fills -> no trip"),
    ]
    fails = 0
    for fills, bleed, eq, st, expect, label in cases:
        got, reasons = evaluate_breaker(
            fills_10m=fills, bleed_pct=bleed, equity=eq, start_equity=st,
            fill_rate_max=12, bleed_pct_max=0.5, equity_dd_max=5.0,
        )
        ok = got == expect
        fails += not ok
        print(f"  [{'PASS' if ok else 'FAIL'}] {label} -> tripped={got} {reasons if got else ''}")
    print(f"\n  {len(cases) - fails}/{len(cases)} passed")
    return 1 if fails else 0


# --------------------------------------------------------------------------- #
# Docker control (soft stop)
# --------------------------------------------------------------------------- #
def docker_soft_stop(compose_file: str, tponly_file: str, service: str, cwd: Path) -> tuple[bool, str]:
    """Recreate the bot container in tp_only mode. Returns (ok, combined_output)."""
    cmd = ["docker", "compose", "-f", compose_file, "-f", tponly_file, "up", "-d", service]
    try:
        p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=180)
        out = (p.stdout or "") + (p.stderr or "")
        return p.returncode == 0, out.strip()
    except Exception as e:  # pragma: no cover
        return False, f"docker compose failed: {e}"


def docker_config_shows_tponly(compose_file: str, tponly_file: str, service: str, cwd: Path) -> tuple[bool, str]:
    """Sanity-check (no side effects): resolved compose command for `service` contains tp_only."""
    cmd = ["docker", "compose", "-f", compose_file, "-f", tponly_file, "config"]
    try:
        p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=60)
        merged = (p.stdout or "")
        return ("tp_only" in merged), merged
    except Exception as e:  # pragma: no cover
        return False, f"docker compose config failed: {e}"


# --------------------------------------------------------------------------- #
# Monitoring
# --------------------------------------------------------------------------- #
def _now_ms() -> int:
    return int(time.time() * 1000)


def _load_prev_state(status_path: Path) -> dict | None:
    try:
        return json.loads(status_path.read_text(encoding="utf-8"))
    except Exception:
        return None


async def _account_equity(bot) -> float | None:
    """True account equity = marginSummary.accountValue (cash + unrealized PnL).

    The live adapter exposes the same value as account_equity_for_risk; the drawdown backstop
    needs accountValue rather than the wallet-style sizing balance.
    """
    try:
        if hasattr(bot, "fetch_account_state"):
            parsed = await bot.fetch_account_state()
            if isinstance(parsed, dict):
                equity = parsed.get("account_equity_for_risk")
                return float(equity) if equity is not None else None
    except Exception:
        pass
    try:
        state = await asyncio.to_thread(bot.info.user_state, bot.query_address, bot.dex)
    except Exception:
        return None
    ms = state.get("marginSummary", {}) or {}
    try:
        return float(ms.get("accountValue", 0) or 0)
    except (TypeError, ValueError):
        return None


async def _gather_metrics(bot, symbol: str, run_start_ms: int, window_ms: int) -> dict:
    """One poll: equity, fills since start, and rolling-window fill-rate + bleed."""
    equity = await _account_equity(bot)
    fills = await bot.fetch_pnls(start_time=run_start_ms) or []
    win_start = _now_ms() - window_ms
    # only this symbol's fills count toward the SP500 churn breaker
    sym_fills = [f for f in fills if f.get("symbol") == symbol]
    win_fills = [f for f in sym_fills if int(f.get("timestamp", 0)) >= win_start]

    def _sum(items, key):
        return sum(float(x.get(key, 0) or 0) for x in items)

    bleed_win = _sum(win_fills, "fee") - _sum(win_fills, "pnl")  # net cost over window
    eq = float(equity) if isinstance(equity, (int, float)) else None
    bleed_pct = (bleed_win / eq * 100.0) if (eq and eq > 0) else 0.0
    return {
        "equity": eq,
        "fills_total": len(sym_fills),
        "pnl_since_start": _sum(sym_fills, "pnl"),
        "fees_since_start": _sum(sym_fills, "fee"),
        "fills_10m": len(win_fills),
        "bleed_10m": bleed_win,
        "bleed_10m_pct": bleed_pct,
    }


async def run(args) -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    from config_utils import load_config  # local import so --selftest needs no config/SDK
    from exchanges.hyperliquid import HyperliquidBot

    status_dir = Path(args.status_dir)
    status_dir.mkdir(parents=True, exist_ok=True)
    status_path = status_dir / "status.json"
    monitor_log = status_dir / "monitor.log"
    engine_status_path = status_dir / "engine_status.json"
    repo_root = SRC.parent

    def effective_bot_mode(fallback: str) -> str:
        """Authoritative bot mode from the engine's own engine_status.json (which reflects the
        tp_only compose overlay and every in-bot safety gate), NOT the base config file. Falls
        back to the watchdog's tracked mode when the engine status is missing or stale (>5 min):
        a stopped/hung engine should not masquerade as 'normal'."""
        try:
            payload = json.loads(engine_status_path.read_text(encoding="utf-8"))
            if _now_ms() - int(payload.get("timestamp_ms", 0)) > 5 * 60_000:
                return fallback
            forced = payload.get("forced_modes", {}) or {}
            if forced.get("long"):
                return str(forced["long"])
            pb_long = (payload.get("pb_modes", {}) or {}).get("long", {}) or {}
            modes = sorted(set(str(v) for v in pb_long.values()))
            if modes:
                return modes[0] if len(modes) == 1 else ",".join(modes)
        except Exception:
            pass
        return fallback

    def mlog(msg: str) -> None:
        line = f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {msg}"
        print(line, flush=True)
        try:
            with monitor_log.open("a", encoding="utf-8") as fh:
                fh.write(line + "\n")
        except Exception:
            pass

    config = load_config(args.config, live_only=True, verbose=False)
    if args.user:
        config["live"]["user"] = args.user
    bot = HyperliquidBot(config)
    if bot.exchange != "hyperliquid":
        mlog(f"ERROR: user is exchange '{bot.exchange}', not hyperliquid")
        return 2
    await bot.init_markets()
    symbol = bot.coin_to_symbol("SP500")
    if not symbol or symbol not in bot.markets_dict:
        mlog("ERROR: xyz:SP500 not found in markets")
        return 2

    window_ms = args.window_min * 60_000

    # Persist run identity / baseline / trip-state across watchdog restarts.
    prev = _load_prev_state(status_path)
    if prev and prev.get("run_start_ms"):
        run_start_ms = int(prev["run_start_ms"])
        start_equity = prev.get("start_equity")
        tripped = prev.get("breaker_state") == "TRIPPED"
        trip_ts_ms = prev.get("trip_ts_ms")
        bot_mode = prev.get("bot_mode", "normal")
        mlog(f"resumed: run_start preserved, tripped={tripped}, start_equity={start_equity}")
    else:
        run_start_ms = _now_ms()
        start_equity = None  # set on first successful equity read
        tripped = False
        trip_ts_ms = None
        bot_mode = "normal"
        mlog(f"new run: monitoring {symbol} | poll {args.poll_seconds}s | window {args.window_min}m "
             f"| breaker fills>={args.fill_rate_max} & bleed>{args.bleed_pct_max}% OR dd>{args.equity_dd_max}%")

    thresholds = {
        "fill_rate_max": args.fill_rate_max,
        "bleed_pct_max": args.bleed_pct_max,
        "equity_dd_max": args.equity_dd_max,
        "window_min": args.window_min,
    }

    async def poll_once() -> dict | None:
        nonlocal start_equity, tripped, trip_ts_ms, bot_mode
        try:
            m = await _gather_metrics(bot, symbol, run_start_ms, window_ms)
        except Exception as e:
            mlog(f"WARN poll failed: {e}")
            return None
        eq = m["equity"]
        if eq is None:
            mlog("WARN equity unavailable this poll; skipping evaluation")
            return None
        if start_equity is None:
            start_equity = eq

        should, reasons = evaluate_breaker(
            fills_10m=m["fills_10m"], bleed_pct=m["bleed_10m_pct"], equity=eq,
            start_equity=start_equity, fill_rate_max=args.fill_rate_max,
            bleed_pct_max=args.bleed_pct_max, equity_dd_max=args.equity_dd_max,
        )

        # Act on a FRESH trip only (idempotent: don't re-cancel / re-restart once tripped).
        if should and not tripped:
            mlog("!!! BREAKER TRIPPED !!! " + " ; ".join(reasons))
            if args.dry_run:
                mlog("[dry-run] would cancel SP500 orders + recreate bot in tp_only (skipped)")
            else:
                try:
                    n = await cancel_all_for(bot, symbol)
                    mlog(f"cancelled {n} open {symbol} order(s)")
                except Exception as e:
                    mlog(f"WARN order cancel failed: {e}")
                ok, out = docker_soft_stop(args.compose_file, args.tponly_file, args.service, repo_root)
                mlog(f"docker soft-stop {'OK' if ok else 'FAILED'}: {out.splitlines()[-1] if out else ''}")
                bot_mode = "tp_only" if ok else bot_mode
            tripped = True
            trip_ts_ms = _now_ms()

        state = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "ts_ms": _now_ms(),
            "run_start_ms": run_start_ms,
            "uptime_min": round((_now_ms() - run_start_ms) / 60000.0, 1),
            "symbol": symbol,
            "equity": round(eq, 4),
            "start_equity": round(float(start_equity), 4),
            "equity_change_pct": round((eq / start_equity - 1.0) * 100.0, 3) if start_equity else 0.0,
            "fills_total": m["fills_total"],
            "pnl_since_start": round(m["pnl_since_start"], 4),
            "fees_since_start": round(m["fees_since_start"], 4),
            "net_pnl_since_start": round(m["pnl_since_start"] - m["fees_since_start"], 4),
            "fills_10m": m["fills_10m"],
            "bleed_10m": round(m["bleed_10m"], 4),
            "bleed_10m_pct": round(m["bleed_10m_pct"], 4),
            "breaker_state": "TRIPPED" if tripped else "OK",
            "trip_reasons": reasons if tripped else [],
            "trip_ts_ms": trip_ts_ms,
            "bot_mode": effective_bot_mode(bot_mode),
            "thresholds": thresholds,
        }
        try:
            status_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
        except Exception as e:
            mlog(f"WARN could not write status.json: {e}")
        return state

    # First poll always logged in full.
    state = await poll_once()
    if state:
        mlog(f"equity=${state['equity']:.2f} ({state['equity_change_pct']:+.2f}%) "
             f"fills_total={state['fills_total']} fills_10m={state['fills_10m']} "
             f"bleed_10m={state['bleed_10m_pct']:.3f}% net_pnl={state['net_pnl_since_start']:+.2f} "
             f"breaker={state['breaker_state']} mode={state['bot_mode']}")
    if args.once:
        await bot.close()
        return 0

    last_heartbeat = 0
    try:
        while True:
            await asyncio.sleep(args.poll_seconds)
            state = await poll_once()
            # Heartbeat to monitor.log every ~10 min (don't spam every poll).
            if state and (_now_ms() - last_heartbeat) >= 600_000:
                last_heartbeat = _now_ms()
                mlog(f"equity=${state['equity']:.2f} ({state['equity_change_pct']:+.2f}%) "
                     f"fills_total={state['fills_total']} fills_10m={state['fills_10m']} "
                     f"bleed_10m={state['bleed_10m_pct']:.3f}% net_pnl={state['net_pnl_since_start']:+.2f} "
                     f"breaker={state['breaker_state']} mode={state['bot_mode']}")
    except (KeyboardInterrupt, asyncio.CancelledError):
        mlog("watchdog stopped (signal)")
    finally:
        await bot.close()
    return 0


def parse_args():
    p = argparse.ArgumentParser(description="Live churn watchdog + soft-stop for the dockerized SP500 bot.")
    p.add_argument("--config", default="configs/config_sp500.json")
    p.add_argument("--user", default="hyperliquid_01")
    p.add_argument("--status-dir", default="runs/sp500_live")
    p.add_argument("--poll-seconds", type=float, default=25.0)
    p.add_argument("--window-min", type=int, default=10, help="rolling window for fill-rate + bleed")
    p.add_argument("--fill-rate-max", type=int, default=12, help="fills in window to qualify as churn")
    p.add_argument("--bleed-pct-max", type=float, default=0.5, help="window net cost %% of equity to qualify as churn")
    p.add_argument("--equity-dd-max", type=float, default=5.0, help="equity drawdown %% backstop trigger")
    p.add_argument("--compose-file", default="docker-compose.yml")
    p.add_argument("--tponly-file", default="docker-compose.tponly.yml")
    p.add_argument("--service", default="passivbot-live")
    p.add_argument("--once", action="store_true", help="single poll then exit")
    p.add_argument("--dry-run", action="store_true", help="on trip, log the action but take none")
    p.add_argument("--selftest", action="store_true", help="offline predicate unit tests, then exit")
    return p.parse_args()


def main():
    args = parse_args()
    if args.selftest:
        sys.exit(_selftest())
    try:
        rc = asyncio.run(run(args))
    except KeyboardInterrupt:
        print("\nInterrupted.")
        rc = 130
    sys.exit(rc)


if __name__ == "__main__":
    main()
