"""
Hyperliquid full-history OHLCV downloader via Hydromancer Reservoir (S3).

The public candleSnapshot API only retains ~5000 recent 1m candles (~3.6 days).
For full history we pull 1-second candles from Hydromancer Reservoir's
requester-pays S3 bucket. For each day we:
  1. stream the coin's 1s rows to a LOCAL parquet (full granularity, kept on disk):
       caches/ohlcv/hyperliquid/1s/{COIN}/YYYY-MM-DD.parquet
  2. aggregate that local 1s parquet to 1m and write the daily .npy passivbot uses:
       caches/ohlcv/hyperliquid/1m/{COIN}/YYYY-MM-DD.npy
       dtype [('ts', int64), ('o', f4), ('h', f4), ('l', f4), ('c', f4), ('bv', f4)]
One S3 read per day produces BOTH. Passivbot only uses the 1m, but we keep the 1s
around for any future higher-resolution analysis. Set KEEP_1S=0 to skip the 1s store.

Source (1s candles, all markets per day):
  s3://hydromancer-reservoir/by_dex/{S3_DEX}/candles/1s/date=YYYY-MM-DD/candles.parquet
  - S3_DEX is the perp dex name ("xyz" for Trade[XYZ]; "hyperliquid" for the main dex)
  - the archive 'coin' column is the full asset name (e.g. "xyz:SP500"); main-dex is bare ("BTC")

Requester-pays => needs AWS credentials, provided as env vars
(AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY, or PUBLIC_KEY/SECRET_KEY) or in an aws.env
file (keys PUBLIC_KEY/SECRET_KEY). Bucket region is ap-northeast-1. The key only
needs s3:GetObject (no ListBucket) — we read explicit per-date files and skip
dates whose file is absent.

Cost is modest: the whole-dex 1s daily parquet is ~11 MB; reading one coin transfers
far less, so a ~5-month single-coin backfill is well under 1 GB (~$0.10-0.20). Disk:
~40 KB/day for the 1m .npy and ~0.3-0.5 MB/day for the kept 1s parquet.

This bucket ALSO carries L2 orderbook (this tool doesn't fetch it): per-coin daily files
at by_dex/{dex}/orderbook/1m/perps/date=YYYY-MM-DD/{COIN}.parquet — 20-level snapshots at
1-MINUTE cadence (the floor here; sub-1m needs the official hyperliquid-archive bucket or a
live l2Book WS feed). NB: requester-pays applies to LIST too (pass RequestPayer/--request-payer
on list calls, not just GET). See docs/reservoir_archive.md for the full layout, measured
sizes (SP500+NVDA L2 full history ~62 MB), and the requester-pays $ model.

Env knobs: SYMBOLS, HL_DEX, HYPERLIQUID_DATA_DIR, HYPERLIQUID_1S_DIR, KEEP_1S,
EARLIEST_DATE, END_DATE, RESERVOIR_BUCKET, AWS_REGION, AWS_ENV_FILE, FORCE.
"""

import logging
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)
log = logging.getLogger("hyperliquid-archive")

SYMBOLS = os.environ.get("SYMBOLS", "SP500")
HL_DEX = os.environ.get("HL_DEX", "xyz")
HYPERLIQUID_DATA_DIR = Path(os.environ.get("HYPERLIQUID_DATA_DIR", "caches/ohlcv/hyperliquid/1m"))
HYPERLIQUID_1S_DIR = Path(os.environ.get("HYPERLIQUID_1S_DIR", "caches/ohlcv/hyperliquid/1s"))
KEEP_1S = os.environ.get("KEEP_1S", "1").strip().lower() not in ("0", "false", "no", "n", "off")
EARLIEST_DATE = os.environ.get("EARLIEST_DATE", "2026-03-18")
END_DATE = os.environ.get("END_DATE", "")  # "" = today (UTC)
RESERVOIR_BUCKET = os.environ.get("RESERVOIR_BUCKET", "hydromancer-reservoir")
AWS_REGION = os.environ.get("AWS_REGION", "ap-northeast-1")
AWS_ENV_FILE = os.environ.get("AWS_ENV_FILE", "aws.env")
FORCE = os.environ.get("FORCE", "").strip().lower() in ("1", "true", "yes", "y")

MS_PER_MIN = 60_000
MS_PER_DAY = 86_400_000
CANDLES_PER_DAY = 1440
CANDLE_DTYPE = np.dtype(
    [("ts", "<i8"), ("o", "<f4"), ("h", "<f4"), ("l", "<f4"), ("c", "<f4"), ("bv", "<f4")]
)


def coins_from_env():
    return [s.strip().upper() for s in SYMBOLS.split(",") if s.strip()]


def s3_dex() -> str:
    """Bucket 'by_dex' segment: builder dexes use their name; main dex uses 'hyperliquid'."""
    return HL_DEX if HL_DEX else "hyperliquid"


def archive_coin(coin: str) -> str:
    """Reservoir 'coin' value: '{dex}:{coin}' for builder dexes, bare coin for main."""
    if ":" in coin:
        return coin
    return f"{HL_DEX}:{coin}" if HL_DEX else coin


def date_str_to_start_ms(date_str: str) -> int:
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def coin_dir(coin: str) -> Path:
    d = HYPERLIQUID_DATA_DIR / coin
    d.mkdir(parents=True, exist_ok=True)
    return d


def s1_coin_dir(coin: str) -> Path:
    d = HYPERLIQUID_1S_DIR / coin
    d.mkdir(parents=True, exist_ok=True)
    return d


def _posix(p: Path) -> str:
    return str(p).replace("\\", "/")


def build_daily_array(candles, date_str):
    """Build a complete 1440-row daily array from [[t_ms,o,h,l,c,v], ...], gap-filling."""
    day_start_ms = date_str_to_start_ms(date_str)
    values = np.full((CANDLES_PER_DAY, 6), np.nan, dtype=np.float64)
    values[:, 0] = np.arange(CANDLES_PER_DAY, dtype=np.float64) * MS_PER_MIN + day_start_ms
    for c in candles:
        idx = (int(c[0]) - day_start_ms) // MS_PER_MIN
        if 0 <= idx < CANDLES_PER_DAY:
            values[idx, 1:] = c[1:]
    last_close = np.nan
    for i in range(CANDLES_PER_DAY):
        if np.isnan(values[i, 1]):
            if not np.isnan(last_close):
                values[i, 1:5] = last_close
                values[i, 5] = 0.0
        else:
            last_close = values[i, 4]
    for i in range(CANDLES_PER_DAY):
        if not np.isnan(values[i, 1]):
            if i > 0:
                price = values[i, 1]
                values[:i, 1:5] = price
                values[:i, 5] = 0.0
            break
    arr = np.empty((CANDLES_PER_DAY,), dtype=CANDLE_DTYPE)
    arr["ts"] = values[:, 0].astype(np.int64)
    arr["o"] = values[:, 1].astype(np.float32)
    arr["h"] = values[:, 2].astype(np.float32)
    arr["l"] = values[:, 3].astype(np.float32)
    arr["c"] = values[:, 4].astype(np.float32)
    arr["bv"] = values[:, 5].astype(np.float32)
    return arr


def save_day_npy(coin: str, date_str: str, arr: np.ndarray):
    fpath = coin_dir(coin) / f"{date_str}.npy"
    tmp = fpath.parent / f"{fpath.stem}.tmp.npy"
    np.save(str(tmp), arr)
    if fpath.exists():
        fpath.unlink()
    tmp.rename(fpath)


def _load_aws_keys():
    """Return (key_id, secret) from env, else from AWS_ENV_FILE (PUBLIC_KEY/SECRET_KEY)."""
    key_id = os.environ.get("AWS_ACCESS_KEY_ID") or os.environ.get("PUBLIC_KEY")
    secret = os.environ.get("AWS_SECRET_ACCESS_KEY") or os.environ.get("SECRET_KEY")
    if key_id and secret:
        return key_id, secret
    env_path = Path(AWS_ENV_FILE)
    if env_path.exists():
        kv = {}
        for line in env_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            kv[k.strip()] = v.strip().strip('"').strip("'")
        key_id = kv.get("PUBLIC_KEY") or kv.get("AWS_ACCESS_KEY_ID")
        secret = kv.get("SECRET_KEY") or kv.get("AWS_SECRET_ACCESS_KEY")
        if key_id and secret:
            return key_id, secret
    return None, None


def _sql_literal(value: str) -> str:
    return str(value).replace("'", "''")


def _make_connection():
    import duckdb

    con = duckdb.connect()
    con.execute("INSTALL httpfs; LOAD httpfs;")
    key_id, secret = _load_aws_keys()
    if key_id and secret:
        key_id_sql = _sql_literal(key_id)
        secret_sql = _sql_literal(secret)
        region_sql = _sql_literal(AWS_REGION)
        bucket_sql = _sql_literal(RESERVOIR_BUCKET)
        con.execute(
            f"CREATE OR REPLACE SECRET reservoir_s3 (TYPE s3, KEY_ID '{key_id_sql}', "
            f"SECRET '{secret_sql}', REGION '{region_sql}', REQUESTER_PAYS true, "
            f"SCOPE 's3://{bucket_sql}');"
        )
        log.info("Using AWS credentials from %s / env", AWS_ENV_FILE)
    else:
        region_sql = _sql_literal(AWS_REGION)
        bucket_sql = _sql_literal(RESERVOIR_BUCKET)
        con.execute(
            f"CREATE OR REPLACE SECRET reservoir_s3 (TYPE s3, PROVIDER credential_chain, "
            f"REGION '{region_sql}', REQUESTER_PAYS true, SCOPE 's3://{bucket_sql}');"
        )
        log.info("No explicit AWS keys; using DuckDB credential_chain")
    return con


def _is_missing_file_error(e) -> bool:
    s = str(e).lower()
    return any(k in s for k in ("404", "no such key", "nosuchkey", "not found", "does not exist"))


def _s3_day_path(date_str: str) -> str:
    return f"s3://{RESERVOIR_BUCKET}/by_dex/{s3_dex()}/candles/1s/date={date_str}/candles.parquet"


def _agg_1m_query(src: str, where: str = "") -> str:
    return f"""
        SELECT
            CAST(epoch_ms(time_bucket(INTERVAL '1 minute', timestamp)) AS BIGINT) AS t,
            first(open  ORDER BY timestamp) AS o,
            max(high) AS h,
            min(low)  AS l,
            last(close ORDER BY timestamp) AS c,
            sum(volume) AS v
        FROM read_parquet('{src}') {where}
        GROUP BY 1
        ORDER BY 1
    """


def _rows_to_1m(rows):
    return [[int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5] or 0)] for r in rows]


def save_1s_local(con, coin: str, acoin: str, date_str: str):
    """Stream the coin's 1s rows from S3 into a local parquet (full granularity).

    Returns the local Path on success, None if the S3 file for that date is absent.
    """
    s1_path = s1_coin_dir(coin) / f"{date_str}.parquet"
    tmp = s1_path.parent / f"{s1_path.stem}.tmp.parquet"
    query = (
        f"COPY (SELECT * FROM read_parquet('{_s3_day_path(date_str)}') "
        f"WHERE coin = '{acoin}' ORDER BY timestamp) TO '{_posix(tmp)}' (FORMAT parquet)"
    )
    try:
        con.execute(query)
    except Exception as e:
        try:
            tmp.unlink()
        except OSError:
            pass
        if _is_missing_file_error(e):
            return None
        raise
    if s1_path.exists():
        s1_path.unlink()
    tmp.rename(s1_path)
    return s1_path


def aggregate_1m(con, src: str, where: str = ""):
    """Aggregate a parquet (S3 or local) to 1m rows. Returns None if the file is absent."""
    try:
        rows = con.execute(_agg_1m_query(src, where)).fetchall()
    except Exception as e:
        if _is_missing_file_error(e):
            return None
        raise
    return _rows_to_1m(rows)


def backfill_coin(con, coin: str, start_date: str, end_date: str):
    acoin = archive_coin(coin)
    log.info(
        "[%s] (%s) backfilling %s -> %s from Reservoir (keep_1s=%s)",
        coin, acoin, start_date, end_date, KEEP_1S,
    )
    d = datetime.strptime(start_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end = datetime.strptime(end_date, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    written = 0
    earliest = latest = None
    while d <= end:
        date_str = d.strftime("%Y-%m-%d")
        npy_path = coin_dir(coin) / f"{date_str}.npy"
        s1_path = s1_coin_dir(coin) / f"{date_str}.parquet"
        # Re-fetch the latest 2 days (may have been partial); skip complete past days.
        recent = (datetime.now(timezone.utc) - d).days <= 2
        have_all = npy_path.exists() and (s1_path.exists() or not KEEP_1S)
        if have_all and not FORCE and not recent:
            d += timedelta(days=1)
            continue
        try:
            if KEEP_1S:
                if s1_path.exists() and not FORCE and not recent:
                    candles = aggregate_1m(con, _posix(s1_path))  # local, no S3 read
                else:
                    local = save_1s_local(con, coin, acoin, date_str)  # S3 read -> local 1s parquet
                    candles = aggregate_1m(con, _posix(local)) if local is not None else None
            else:
                candles = aggregate_1m(con, _s3_day_path(date_str), where=f"WHERE coin = '{acoin}'")
        except Exception as e:
            log.error("[%s] %s: query error: %s", coin, date_str, str(e)[:200])
            d += timedelta(days=1)
            continue
        if candles is None:
            if date_str != today:
                log.debug("[%s] %s: no parquet (skipped)", coin, date_str)
            d += timedelta(days=1)
            continue
        if candles:
            save_day_npy(coin, date_str, build_daily_array(candles, date_str))
            written += 1
            ts0, ts1 = candles[0][0], candles[-1][0]
            earliest = ts0 if earliest is None else min(earliest, ts0)
            latest = ts1 if latest is None else max(latest, ts1)
        d += timedelta(days=1)
    if written:
        log.info(
            "[%s] done: wrote %d day file(s), %s -> %s%s",
            coin, written,
            datetime.fromtimestamp(earliest / 1000, tz=timezone.utc).strftime("%Y-%m-%d"),
            datetime.fromtimestamp(latest / 1000, tz=timezone.utc).strftime("%Y-%m-%d"),
            f" (1s kept under {HYPERLIQUID_1S_DIR}/{coin}/)" if KEEP_1S else "",
        )
    else:
        log.warning("[%s] no day files written (already present, or no data in range)", coin)


def main():
    end_date = END_DATE or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    log.info("Hyperliquid Reservoir archive downloader")
    log.info("  1m .npy dir:  %s", HYPERLIQUID_DATA_DIR.resolve())
    if KEEP_1S:
        log.info("  1s store:     %s", HYPERLIQUID_1S_DIR.resolve())
    log.info("  Bucket:       s3://%s/by_dex/%s/candles/1s/", RESERVOIR_BUCKET, s3_dex())
    log.info("  Coins:        %s", ", ".join(f"{c}->{archive_coin(c)}" for c in coins_from_env()))
    log.info("  Range:        %s -> %s", EARLIEST_DATE, end_date)
    try:
        con = _make_connection()
    except Exception as e:
        log.error("Failed to init DuckDB/S3: %s", e)
        sys.exit(2)
    for coin in coins_from_env():
        try:
            backfill_coin(con, coin, EARLIEST_DATE, end_date)
        except Exception as e:
            log.error("[%s] fatal: %s", coin, e)
            sys.exit(1)
    log.info("Archive download complete")


if __name__ == "__main__":
    main()
