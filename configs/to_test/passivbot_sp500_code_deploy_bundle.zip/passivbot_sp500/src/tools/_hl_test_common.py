#!/usr/bin/env python3
"""
Shared helpers for the Hyperliquid live/engine integration tools.

These are used by BOTH:
    - src/tools/hyperliquid_live_test.py     (order-primitives test)
    - src/tools/hyperliquid_engine_test.py   (live-engine test)

Everything here takes an already-constructed HyperliquidBot as an argument, so this
module has no exchange/config imports of its own and is safe to import from either
tool. None of these helpers place orders unless explicitly asked to (cancel_all_for /
market_close are reduce-only cleanup helpers).
"""
from __future__ import annotations

import asyncio
import math
import time


# --------------------------------------------------------------------------- #
# Pretty printing + PASS/FAIL bookkeeping
# --------------------------------------------------------------------------- #
def hr(title: str = "") -> None:
    line = "=" * 78
    if title:
        print(f"\n{line}\n{title}\n{line}")
    else:
        print(line)


class Results:
    """Tracks PASS/FAIL/SKIP for each checked operation."""

    def __init__(self):
        self.rows: list[tuple[str, str, str]] = []

    def record(self, op: str, status: str, detail: str = "") -> None:
        self.rows.append((op, status, detail))
        tag = {"PASS": "[PASS]", "FAIL": "[FAIL]", "SKIP": "[skip]"}.get(status, status)
        print(f"  {tag} {op}" + (f" -- {detail}" if detail else ""))

    def summary(self) -> int:
        """Print the summary table and return the number of failures."""
        hr("RESULT SUMMARY")
        for op, status, detail in self.rows:
            tag = {"PASS": "[PASS]", "FAIL": "[FAIL]", "SKIP": "[skip]"}.get(status, status)
            print(f"  {tag:6} {op:46} {detail}")
        n_fail = sum(1 for _, s, _ in self.rows if s == "FAIL")
        n_pass = sum(1 for _, s, _ in self.rows if s == "PASS")
        n_skip = sum(1 for _, s, _ in self.rows if s == "SKIP")
        print(f"\n  {n_pass} passed, {n_fail} failed, {n_skip} skipped")
        return n_fail


# --------------------------------------------------------------------------- #
# Minimum valid order size (always computed from the bot's OWN specs)
# --------------------------------------------------------------------------- #
def min_valid_size(bot, symbol: str, price: float, buffer: float) -> float:
    """Smallest qty that respects BOTH the qty step and the $ min-notional, using the
    bot's own per-symbol specs. Adds a buffer so price drift before fill can't push the
    notional under the minimum. Asserts validity; raises if it cannot build a valid size."""
    step = float(bot.qty_steps[symbol])
    min_qty = float(bot.min_qtys[symbol])
    min_cost = float(bot.min_costs[symbol])
    if price <= 0 or step <= 0:
        raise ValueError(f"{symbol}: bad price/step price={price} step={step}")
    target = min_cost * buffer
    qty = math.ceil((target / price) / step) * step
    qty = round(qty, 12)
    qty = max(qty, min_qty)
    # guarantee notional >= min_cost even after rounding
    guard = 0
    while qty * price < min_cost and guard < 1000:
        qty = round(qty + step, 12)
        guard += 1
    qty = bot._round_size(qty, symbol)  # align exactly to the exchange step
    assert qty >= min_qty, f"{symbol}: qty {qty} < min_qty {min_qty}"
    assert qty * price >= min_cost, f"{symbol}: notional {qty*price:.4f} < min_cost {min_cost}"
    return qty


def order_meets_minimum(bot, symbol: str, qty: float, price: float) -> tuple[bool, str]:
    """True iff (qty, price) satisfies the bot's own qty-step / min-qty / min-notional specs.
    Returns (ok, reason). Used to validate engine-computed orders without submitting them."""
    try:
        step = float(bot.qty_steps[symbol])
        min_qty = float(bot.min_qtys[symbol])
        min_cost = float(bot.min_costs[symbol])
    except (KeyError, TypeError) as e:
        return False, f"missing specs: {e}"
    q = abs(float(qty))
    notional = q * float(price)
    if q < min_qty - 1e-12:
        return False, f"qty {q} < min_qty {min_qty}"
    # qty must be a multiple of the step (within float tolerance)
    if step > 0:
        rem = (q / step) - round(q / step)
        if abs(rem) > 1e-6:
            return False, f"qty {q} not a multiple of step {step}"
    if notional < min_cost - 1e-9:
        return False, f"notional ${notional:.4f} < min_cost ${min_cost}"
    return True, f"qty={q} notional=${notional:.2f} (min ${min_cost:.0f})"


# --------------------------------------------------------------------------- #
# Live state queries
# --------------------------------------------------------------------------- #
async def get_mid(bot, symbol: str) -> float:
    tickers = await bot.fetch_tickers()
    if tickers and symbol in tickers and tickers[symbol].get("last"):
        return float(tickers[symbol]["last"])
    # fallback to last candle close
    ohlcv = await bot.fetch_ohlcv(symbol, "1m", limit=2)
    if ohlcv:
        return float(ohlcv[-1][4])
    raise RuntimeError(f"could not determine price for {symbol}")


async def get_position(bot, symbol: str):
    positions = await bot.fetch_positions()
    for p in positions or []:
        if p["symbol"] == symbol and float(p.get("size", 0)) != 0.0:
            return p
    return None


async def wait_position(bot, symbol: str, timeout: float = 12.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        p = await get_position(bot, symbol)
        if p is not None:
            return p
        await asyncio.sleep(0.7)
    return None


async def wait_flat(bot, symbol: str, timeout: float = 15.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if await get_position(bot, symbol) is None:
            return True
        await asyncio.sleep(0.7)
    return await get_position(bot, symbol) is None


async def open_orders_for(bot, symbol: str):
    orders = await bot.fetch_open_orders()
    return [o for o in (orders or []) if o["symbol"] == symbol]


# --------------------------------------------------------------------------- #
# Reduce-only cleanup helpers
# --------------------------------------------------------------------------- #
async def cancel_all_for(bot, symbol: str) -> int:
    n = 0
    for o in await open_orders_for(bot, symbol):
        res = await bot.execute_cancellation({"symbol": symbol, "id": o["id"]})
        if bot.did_cancel_order(res):
            n += 1
    return n


async def market_close(bot, symbol: str, mid: float) -> bool:
    """Reduce-only market close of whatever position remains. Returns True if flat."""
    p = await get_position(bot, symbol)
    if p is None:
        return True
    size = abs(float(p["size"]))
    close_side = "sell" if p["position_side"] == "long" else "buy"
    await bot.execute_order({
        "symbol": symbol, "side": close_side, "qty": size,
        "price": mid, "type": "market", "reduce_only": True,
    })
    return await wait_flat(bot, symbol, timeout=12.0)


# --------------------------------------------------------------------------- #
# Cost accounting
# --------------------------------------------------------------------------- #
async def measured_cost(bot, start_ms: int, verbose: bool = False):
    """Net cost (loss) of fills since start_ms = sum(fees) - sum(closedPnl)."""
    try:
        fills = await bot.fetch_pnls(start_time=start_ms)
    except Exception:
        return None
    if not fills:
        return 0.0
    total_pnl = sum(float(f.get("pnl", 0) or 0) for f in fills)
    total_fee = sum(float(f.get("fee", 0) or 0) for f in fills)
    if verbose:
        hr("FILLS THIS RUN")
        for f in fills:
            print(f"  {f['symbol']:16} {f['side']:4} qty={f['qty']} @ {f['price']} "
                  f"pnl={f['pnl']:.4f} fee={f['fee']:.4f}")
        print(f"\n  sum closedPnl=${total_pnl:.4f}  sum fees=${total_fee:.4f}")
    return total_fee - total_pnl
