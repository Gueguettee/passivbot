import asyncio
import json
import logging
import os
import pprint
import subprocess
import sys
import time
import traceback
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from uuid import uuid4

import numpy as np
import pandas as pd

from candlestick_manager import CandlestickManager


def _pct_log(level: str, pct: int, msg: str, *args, **kwargs) -> None:
    """Log with percentage prefix: '12% | message here'."""
    pct_str = f"{pct:3d}%" if pct < 100 else "100%"
    full_msg = f"{pct_str} | {msg}"
    getattr(logging, level)(full_msg, *args, **kwargs)


class ProgressTracker:
    """Track progress and emit percentage-prefixed logs periodically."""

    def __init__(self, total: int, context: str, log_interval_seconds: float = 10.0):
        self.total = max(1, total)
        self.context = context
        self.log_interval = log_interval_seconds
        self.processed = 0
        self.started = time.monotonic()
        self.last_logged = self.started

    def update(self, n: int = 1) -> None:
        self.processed += n

    def pct(self) -> int:
        return min(100, int(100 * self.processed / self.total))

    def maybe_log(self, current_item: str = "", force: bool = False) -> None:
        now = time.monotonic()
        if not force and (now - self.last_logged) < self.log_interval:
            return
        self.last_logged = now
        elapsed = max(0.1, now - self.started)
        rate = self.processed / elapsed
        remaining = max(0, self.total - self.processed)
        eta_s = int(remaining / rate) if rate > 0 else 0
        eta_str = f"ETA {eta_s}s" if eta_s > 0 else ""
        item_str = f"current={current_item}" if current_item else ""
        parts = [f"{self.context} {self.processed}/{self.total}"]
        if item_str:
            parts.append(item_str)
        if eta_str:
            parts.append(eta_str)
        _pct_log("info", self.pct(), " ".join(parts))

    def log_done(self) -> None:
        elapsed = round(time.monotonic() - self.started, 1)
        _pct_log("info", 100, f"{self.context} done {self.processed}/{self.total} in {elapsed}s")


from config_utils import require_config_value, require_live_value
from ohlcv_utils import dump_ohlcv_data
from procedures import get_first_timestamps_unified
from utils import (
    coin_to_symbol,
    denormalize_exchange_name,
    format_end_date,
    get_quote,
    load_ccxt_instance,
    load_markets,
    make_get_filepath,
    normalize_exchange_name,
    symbol_to_coin,
    ts_to_date,
    utc_ms,
    date_to_ts,
)
from warmup_utils import compute_backtest_warmup_minutes, compute_per_coin_warmup_minutes


MS_PER_MINUTE = 60_000
MS_PER_DAY = 86_400_000

# Hyperliquid's public candleSnapshot API only retains ~5000 recent 1m candles (~3.6 days).
# Anything older than this, if not already cached, can only come from the (paid, requester-pays)
# Reservoir S3 archive. Used to (a) keep the archive opt-in and (b) warn about unfillable holes.
HL_PUBLIC_API_REACH_MINUTES = 5000


class HLCVManager:
    """Backtest-oriented OHLCV manager using CandlestickManager for fetching/caching."""

    def __init__(
        self,
        exchange: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        cc=None,
        gap_tolerance_ohlcvs_minutes: float = 120.0,
        verbose: bool = True,
        cm_debug_level: int = 0,
        cm_progress_log_interval_seconds: float = 10.0,  # Log progress every 10s by default
        force_refetch_gaps: bool = False,
    ):
        self.exchange = normalize_exchange_name(exchange)
        self.quote = get_quote(self.exchange)
        self.start_date = "2020-01-01" if start_date is None else format_end_date(start_date)
        self.end_date = format_end_date("now" if end_date is None else end_date)
        self.start_ts = int(date_to_ts(self.start_date))
        self.end_ts = int(date_to_ts(self.end_date))
        self.cc = cc
        # Use denormalized exchange name for cache paths (e.g., "binance" not "binanceusdm")
        cache_exchange = denormalize_exchange_name(self.exchange)
        self.cache_filepaths = {
            "markets": os.path.join("caches", cache_exchange, "markets.json"),
            "first_timestamps": os.path.join("caches", cache_exchange, "first_timestamps.json"),
        }
        self.markets = None
        self.verbose = bool(verbose)
        self.gap_tolerance_ohlcvs_minutes = float(gap_tolerance_ohlcvs_minutes)
        self.cm_debug_level = int(cm_debug_level)
        try:
            self.cm_progress_log_interval_seconds = max(0.0, float(cm_progress_log_interval_seconds))
        except Exception:
            self.cm_progress_log_interval_seconds = 0.0
        self.force_refetch_gaps = bool(force_refetch_gaps)
        self.cm: Optional[CandlestickManager] = None

    def update_date_range(self, new_start_date=None, new_end_date=None):
        if new_start_date is not None:
            if isinstance(new_start_date, (float, int)):
                self.start_date = ts_to_date(new_start_date)
            elif isinstance(new_start_date, str):
                self.start_date = new_start_date
            else:
                raise ValueError(f"invalid start date {new_start_date}")
            self.start_ts = int(date_to_ts(self.start_date))
        if new_end_date is not None:
            if isinstance(new_end_date, (float, int)):
                self.end_date = ts_to_date(new_end_date)
            elif isinstance(new_end_date, str):
                self.end_date = new_end_date
            else:
                raise ValueError(f"invalid end date {new_end_date}")
            self.end_date = format_end_date(self.end_date)
            self.end_ts = int(date_to_ts(self.end_date))

    def load_cc(self):
        if self.cc is None:
            self.cc = load_ccxt_instance(self.exchange, enable_rate_limit=True)
        if self.cm is None:
            # Limit concurrent ccxt requests per exchange to reduce timeouts under heavy parallelism.
            # Bybit tends to be more sensitive.
            max_concurrent_requests = 3 if self.exchange == "bybit" else 5
            self.cm = CandlestickManager(
                exchange=self.cc,
                exchange_name=self.exchange,
                debug=int(self.cm_debug_level),
                progress_log_interval_seconds=float(self.cm_progress_log_interval_seconds),
                max_concurrent_requests=max_concurrent_requests,
                remote_fetch_callback=self._remote_fetch_log,
                # Backtest HLCV preparation may share the same cache directory as live trading.
                # Force-disable disk retention here to avoid deleting shards created/needed by other processes.
                max_disk_candles_per_symbol_per_tf=0,
            )

    async def aclose(self) -> None:
        """Close CandlestickManager resources (not the ccxt exchange)."""
        if self.cm is None:
            return
        try:
            await self.cm.aclose()
        except Exception:
            pass
        self.cm = None

    def close(self) -> None:
        """Best-effort sync close for CandlestickManager resources."""
        if self.cm is None:
            return
        try:
            self.cm.close()
        except Exception:
            pass
        self.cm = None

    def _remote_fetch_log(self, payload: dict) -> None:
        """Log a concise view of download progress (CCXT + archive).

        CandlestickManager uses its own logger which is often set to WARNING when
        cm_debug_level=0. This callback lets hlcv_preparation surface progress at
        INFO level without changing CandlestickManager verbosity globally.
        """

        # Throttle per (kind, symbol, tf/stage) to avoid log spam.
        if not hasattr(self, "_download_log_last"):
            self._download_log_last = {}
        now = time.monotonic()

        kind = payload.get("kind")
        stage = payload.get("stage")
        symbol = payload.get("symbol")
        tf = payload.get("tf")

        if kind == "ccxt_fetch_ohlcv":
            attempt = int(payload.get("attempt", 1) or 1)
            if stage == "start":
                # Only show attempt 1, and at most once per 10 seconds per symbol/tf.
                key = ("ccxt", symbol, tf, "start")
                if (now - float(self._download_log_last.get(key, 0.0))) < 10.0:
                    return
                self._download_log_last[key] = now

                since_ms = payload.get("since_ts")
                since_iso = None
                try:
                    if since_ms is not None:
                        since_iso = datetime.fromtimestamp(int(since_ms) / 1000, tz=timezone.utc).strftime(
                            "%Y-%m-%dT%H:%M:%SZ"
                        )
                except Exception:
                    since_iso = None

                logging.info(
                    "[%s] download ccxt start symbol=%s tf=%s since=%s since_ms=%s limit=%s params=%s",
                    self.exchange,
                    symbol,
                    payload.get("tf"),
                    since_iso if since_iso is not None else since_ms,
                    since_ms,
                    payload.get("limit"),
                    payload.get("params"),
                )
                return

            if stage == "ok":
                # Throttle OK logs to once per 10 seconds per symbol/tf.
                key = ("ccxt", symbol, tf, "ok")
                if (now - float(self._download_log_last.get(key, 0.0))) < 10.0:
                    return
                self._download_log_last[key] = now
                logging.info(
                    "[%s] download ccxt ok symbol=%s tf=%s rows=%s elapsed_ms=%s",
                    self.exchange,
                    symbol,
                    payload.get("tf"),
                    payload.get("rows"),
                    payload.get("elapsed_ms"),
                )
                return

            if stage == "error":
                # Let CandlestickManager warnings show the details; keep this concise.
                if attempt == 1:
                    logging.warning(
                        "[%s] download ccxt error symbol=%s tf=%s error_type=%s error=%s",
                        self.exchange,
                        symbol,
                        tf,
                        payload.get("error_type"),
                        payload.get("error"),
                    )
                return

        if kind == "archive_prefetch":
            if stage == "start":
                logging.info(
                    "[%s] download archive start symbol=%s days=%s parallel=%s range=%s",
                    self.exchange,
                    symbol,
                    payload.get("days_to_fetch"),
                    payload.get("parallel"),
                    payload.get("date_range"),
                )
                return
            if stage == "skip":
                logging.info(
                    "[%s] download archive skip symbol=%s reasons=%s",
                    self.exchange,
                    symbol,
                    payload.get("reasons"),
                )
                return
            if stage == "progress":
                key = ("archive", symbol, "progress")
                if (now - float(self._download_log_last.get(key, 0.0))) < 10.0:
                    return
                self._download_log_last[key] = now
                logging.info(
                    "[%s] download archive progress symbol=%s %s/%s (%s%%) batch=%s",
                    self.exchange,
                    symbol,
                    payload.get("completed"),
                    payload.get("total"),
                    payload.get("pct"),
                    payload.get("batch"),
                )
                return
            if stage == "done":
                logging.info(
                    "[%s] download archive done symbol=%s fetched=%s skipped=%s total=%s elapsed_s=%s",
                    self.exchange,
                    symbol,
                    payload.get("fetched"),
                    payload.get("skipped"),
                    payload.get("total"),
                    payload.get("elapsed_s"),
                )
                return

    async def load_markets(self):
        self.load_cc()
        self.markets = await load_markets(self.exchange, verbose=False)
        try:
            if hasattr(self.cc, "set_markets"):
                self.cc.set_markets(self.markets)
        except Exception:
            pass

    def get_symbol(self, coin: str) -> str:
        assert self.markets, "needs to call load_markets() first"
        return coin_to_symbol(coin, self.exchange)

    def has_coin(self, coin: str) -> bool:
        symbol = self.get_symbol(coin)
        return bool(symbol)

    def get_market_specific_settings(self, coin: str) -> dict:
        mss = dict(self.markets[self.get_symbol(coin)])
        mss["hedge_mode"] = True
        mss["maker_fee"] = mss.get("maker")
        mss["taker_fee"] = mss.get("taker")
        mss["c_mult"] = mss.get("contractSize")
        mss["min_cost"] = (
            mc if (mc := mss.get("limits", {}).get("cost", {}).get("min")) is not None else 0.01
        )
        mss["price_step"] = mss.get("precision", {}).get("price")
        mss["min_qty"] = max(
            lm if (lm := mss.get("limits", {}).get("amount", {}).get("min")) is not None else 0.0,
            pm if (pm := mss.get("precision", {}).get("amount")) is not None else 0.0,
        )
        mss["qty_step"] = mss.get("precision", {}).get("amount")
        if self.exchange == "bybit":
            # ccxt reports incorrect fees for bybit perps
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.00055
        elif self.exchange in ("kucoin", "kucoinfutures"):
            # ccxt reports incorrect fees for kucoin futures. Assume VIP0
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.0006
        elif self.exchange == "gateio":
            # ccxt reports incorrect fees for gateio perps. Assume VIP0
            mss["maker"] = mss["maker_fee"] = 0.0002
            mss["taker"] = mss["taker_fee"] = 0.0005
        return mss

    def load_first_timestamp(self, coin: str):
        fpath = self.cache_filepaths["first_timestamps"]
        if os.path.exists(fpath):
            try:
                ftss = json.load(open(fpath))
                if coin in ftss:
                    return ftss[coin]
            except Exception as e:
                logging.error(f"Error loading {fpath} {e}")

    def dump_first_timestamp(self, coin: str, fts: float):
        fpath = self.cache_filepaths["first_timestamps"]
        try:
            if os.path.exists(fpath):
                try:
                    ftss = json.load(open(fpath))
                except Exception:
                    ftss = {}
            else:
                make_get_filepath(fpath)
                ftss = {}
            ftss[coin] = fts
            json.dump(ftss, open(fpath, "w"), indent=True, sort_keys=True)
        except Exception as e:
            logging.error(f"Error dumping {fpath}: {e}")

    async def get_first_timestamp(self, coin: str) -> float:
        if fts := self.load_first_timestamp(coin):
            return float(fts)
        if not self.markets:
            await self.load_markets()
        self.load_cc()
        try:
            ohlcvs = await self.cc.fetch_ohlcv(
                self.get_symbol(coin),
                since=int(date_to_ts("2018-01-01")),
                timeframe="1d",
            )
            if not ohlcvs:
                ohlcvs = await self.cc.fetch_ohlcv(
                    self.get_symbol(coin),
                    since=int(date_to_ts("2020-01-01")),
                    timeframe="1d",
                )
            fts = float(ohlcvs[0][0]) if ohlcvs else 0.0
        except Exception:
            fts = 0.0
        self.dump_first_timestamp(coin, fts)
        return float(fts)

    async def get_ohlcvs(self, coin: str, start_date=None, end_date=None) -> pd.DataFrame:
        empty_df = pd.DataFrame(columns=["timestamp", "open", "high", "low", "close", "volume"])
        if start_date is not None or end_date is not None:
            self.update_date_range(start_date, end_date)
        if not self.markets:
            await self.load_markets()
        if not self.has_coin(coin):
            return empty_df
        self.load_cc()
        assert self.cm is not None
        symbol = self.get_symbol(coin)
        start_ts = int(self.start_ts)
        end_ts = int(self.end_ts)
        if start_ts > end_ts:
            return empty_df

        # Fetch strict (real) candles first to detect large gaps.
        real = await self.cm.get_candles(
            symbol,
            start_ts=start_ts,
            end_ts=end_ts,
            max_age_ms=0,
            strict=True,
            timeframe="1m",
            force_refetch_gaps=self.force_refetch_gaps,
        )
        if real.size == 0:
            return empty_df

        ts = real["ts"].astype(np.int64, copy=False)
        if ts.size > 1:
            intervals = np.diff(ts)
            greatest_gap_ms = int(intervals.max(initial=60_000))
            if greatest_gap_ms > int(self.gap_tolerance_ohlcvs_minutes * 60_000):
                # Helpful diagnostics: locate the exact gap boundaries
                gap_start_ts = None
                gap_end_ts = None
                try:
                    imax = int(np.argmax(intervals))
                    if 0 <= imax < ts.size - 1:
                        gap_start_ts = int(ts[imax])
                        gap_end_ts = int(ts[imax + 1])
                except Exception:
                    gap_start_ts = None
                    gap_end_ts = None

                # Give CandlestickManager one chance to self-heal (legacy merge / refetch gaps)
                # before returning empty.
                if not self.force_refetch_gaps:
                    real = await self.cm.get_candles(
                        symbol,
                        start_ts=start_ts,
                        end_ts=end_ts,
                        max_age_ms=0,
                        strict=True,
                        timeframe="1m",
                        force_refetch_gaps=True,
                    )
                    if real.size == 0:
                        return empty_df
                    ts = real["ts"].astype(np.int64, copy=False)
                    if ts.size > 1:
                        intervals = np.diff(ts)
                        greatest_gap_ms = int(intervals.max(initial=60_000))
                    else:
                        # Single or zero timestamp implies no measurable gaps;
                        # don't reuse stale greatest_gap_ms from the initial fetch.
                        greatest_gap_ms = 0
                if greatest_gap_ms > int(self.gap_tolerance_ohlcvs_minutes * 60_000):
                    if self.verbose:
                        logging.warning(
                            "[%s] gaps detected in %s OHLCV data; greatest gap: %.1f minutes. Returning empty.",
                            self.exchange,
                            coin,
                            greatest_gap_ms / 60_000.0,
                        )
                        if gap_start_ts is not None and gap_end_ts is not None:
                            gap_start_iso = datetime.fromtimestamp(
                                int(gap_start_ts) / 1000, tz=timezone.utc
                            ).strftime("%Y-%m-%dT%H:%M:%SZ")
                            gap_end_iso = datetime.fromtimestamp(
                                int(gap_end_ts) / 1000, tz=timezone.utc
                            ).strftime("%Y-%m-%dT%H:%M:%SZ")
                            logging.warning(
                                "[%s] largest_gap_window %s -> %s (%.1f minutes)",
                                self.exchange,
                                gap_start_iso,
                                gap_end_iso,
                                (gap_end_ts - gap_start_ts) / 60_000.0,
                            )
                    return empty_df

        # Fill to the full requested window (bfill/ffill inside CM).
        # Data from get_candles is already sorted, so skip redundant sort
        filled = self.cm.standardize_gaps(
            real, start_ts=start_ts, end_ts=end_ts, strict=False, assume_sorted=True
        )
        if filled.size == 0:
            return empty_df
        df = pd.DataFrame(
            {
                "timestamp": filled["ts"].astype(np.int64),
                "open": filled["o"].astype(float),
                "high": filled["h"].astype(float),
                "low": filled["l"].astype(float),
                "close": filled["c"].astype(float),
                "volume": filled["bv"].astype(float),
            }
        )
        return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Shared daily-.npy cache helpers (exchange-neutral).
#
# Both the Hyperliquid (primary) and Lighter (legacy/secondary) loaders read the same
# on-disk format: caches/ohlcv/<exchange>/1m/{COIN}/YYYY-MM-DD.npy. These helpers were
# originally named _lighter_* but are exchange-agnostic; they're renamed _daily_npy_*
# so the Hyperliquid path no longer appears to depend on "lighter" code. Functions that
# are genuinely Lighter-specific keep the lighter name and carry a LEGACY note — this is
# a Hyperliquid-xyz-focused fork, so Lighter support is retained but secondary.
# ---------------------------------------------------------------------------
def _daily_npy_date_str(ts_ms: int) -> str:
    return datetime.fromtimestamp(int(ts_ms) / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


def _daily_npy_date_str_to_ts(date_str: str) -> int:
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _daily_npy_config_root(config) -> Path:
    base_config_path = config.get("live", {}).get("base_config_path")
    if base_config_path:
        return Path(base_config_path).resolve().parent.parent
    return _repo_root()


def _daily_npy_day_start(ts_ms: int) -> int:
    return (int(ts_ms) // MS_PER_DAY) * MS_PER_DAY


def _resolve_lighter_data_dir(config) -> Path:
    # LEGACY (Lighter-only): resolves the Lighter 1m cache dir. The primary path is
    # _resolve_hyperliquid_data_dir; this stays for the secondary Lighter loader.
    raw = Path(config.get("backtest", {}).get("lighter_data_dir", "caches/ohlcv/lighter/1m"))
    if raw.is_absolute():
        return raw
    return (_daily_npy_config_root(config) / raw).resolve()


def _daily_npy_coin_dir(data_dir: Path, coin: str) -> Path:
    return data_dir / coin


def _daily_npy_load_day(fpath: Path) -> np.ndarray:
    arr = np.load(str(fpath), allow_pickle=False)
    if getattr(arr.dtype, "fields", None):
        out = np.empty((arr.shape[0], 6), dtype=np.float64)
        out[:, 0] = arr["ts"].astype(np.float64)
        out[:, 1] = arr["o"].astype(np.float64)
        out[:, 2] = arr["h"].astype(np.float64)
        out[:, 3] = arr["l"].astype(np.float64)
        out[:, 4] = arr["c"].astype(np.float64)
        out[:, 5] = arr["bv"].astype(np.float64)
        return out
    return arr.astype(np.float64, copy=False)


def _daily_npy_coin_has_data_in_range(data_dir: Path, coin: str, start_ts: int, end_ts: int) -> bool:
    coin_dir = data_dir / coin
    if not coin_dir.exists():
        return False

    current_ms = _daily_npy_day_start(start_ts)
    while current_ms <= end_ts:
        fpath = coin_dir / f"{_daily_npy_date_str(current_ms)}.npy"
        if fpath.exists():
            try:
                arr = _daily_npy_load_day(fpath)
                mask = (arr[:, 0] >= start_ts) & (arr[:, 0] <= end_ts) & np.isfinite(arr[:, 4])
                if mask.any():
                    return True
            except Exception as exc:
                logging.warning(f"lighter: failed reading {fpath}: {exc}")
        current_ms += MS_PER_DAY
    return False


def _daily_npy_fetched_until(coin_dir: Path) -> Optional[int]:
    cursor = coin_dir / ".fetched_until"
    if not cursor.exists():
        return None
    try:
        return int(cursor.read_text().strip())
    except (OSError, ValueError):
        return None


def _daily_npy_latest_file_ts(coin_dir: Path) -> Optional[int]:
    files = sorted(f for f in coin_dir.glob("*.npy") if ".tmp" not in f.name)
    if not files:
        return None
    try:
        return _daily_npy_date_str_to_ts(files[-1].stem)
    except ValueError:
        return None


def _daily_npy_coin_needs_collection(
    data_dir: Path, coin: str, effective_start_ts: int, end_ts: int
) -> Tuple[bool, str]:
    coin_dir = data_dir / coin
    if not _daily_npy_coin_has_data_in_range(data_dir, coin, effective_start_ts, end_ts):
        return True, "missing local candles"

    fetched_until = _daily_npy_fetched_until(coin_dir)
    if fetched_until is not None:
        if fetched_until + MS_PER_MINUTE < end_ts:
            return True, f"stale cursor at {_daily_npy_date_str(fetched_until)}"
        return False, ""

    latest_file_ts = _daily_npy_latest_file_ts(coin_dir)
    if latest_file_ts is not None and latest_file_ts < _daily_npy_day_start(end_ts):
        return True, f"latest file is {_daily_npy_date_str(latest_file_ts)}"
    return False, ""


def _truthy_config_value(value) -> bool:
    if isinstance(value, str):
        return value.strip().lower() not in ("0", "false", "no", "n", "off")
    return bool(value)


def _maybe_run_lighter_ohlcv_collector(config, data_dir: Path, coins, effective_start_ts: int, end_ts: int) -> None:
    # LEGACY (Lighter-only): auto-runs the Lighter collector. The Hyperliquid equivalent is
    # _maybe_run_hyperliquid_ohlcv_collector. Kept for the secondary Lighter loader below.
    auto_collect = config.get("backtest", {}).get("auto_collect_lighter_ohlcvs", True)
    if not _truthy_config_value(auto_collect):
        return

    needed = []
    reasons = {}
    for coin in sorted(set(coins)):
        needs_collection, reason = _daily_npy_coin_needs_collection(
            data_dir, coin, effective_start_ts, end_ts
        )
        if needs_collection:
            needed.append(coin)
            reasons[coin] = reason

    if not needed:
        return

    src_dir = Path(__file__).resolve().parent
    collector_path = src_dir / "tools" / "lighter_ohlcv_collector.py"
    if not collector_path.exists():
        raise FileNotFoundError(f"Lighter OHLCV collector not found at {collector_path}")

    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = (
        str(src_dir) if not existing_pythonpath else str(src_dir) + os.pathsep + existing_pythonpath
    )
    env["PYTHONUTF8"] = env.get("PYTHONUTF8", "1")
    env["RUN_ONCE"] = "1"
    env["SYMBOLS"] = ",".join(needed)
    env["EARLIEST_DATE"] = _daily_npy_date_str(effective_start_ts)
    env["LIGHTER_DATA_DIR"] = str(data_dir.resolve())

    logging.info(
        "lighter: running OHLCV collector for %s from %s (%s)",
        ",".join(needed),
        env["EARLIEST_DATE"],
        ", ".join(f"{coin}: {reasons[coin]}" for coin in needed),
    )
    result = subprocess.run(  # noqa: S603
        [sys.executable, str(collector_path)],
        cwd=str(_repo_root()),
        env=env,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Lighter OHLCV collector failed with exit code {result.returncode}")


async def _prepare_hlcvs_lighter(config, coins, effective_start_ts, requested_start_ts, end_ts):
    """LEGACY / secondary exchange — load pre-downloaded Lighter daily .npy files.

    This is a Hyperliquid-xyz-focused fork; the primary loader is
    _prepare_hlcvs_hyperliquid. This Lighter path is retained for backward compatibility
    and shares the exchange-neutral _daily_npy_* cache helpers above.

    Reads from caches/ohlcv/lighter/1m/{COIN}/YYYY-MM-DD.npy.
    Returns (mss, timestamps, unified_array, btc_usd_prices).
    """
    data_dir = _resolve_lighter_data_dir(config)
    interval_ms = 60_000
    per_coin_warmups = compute_per_coin_warmup_minutes(config)
    default_warm = int(per_coin_warmups.get("__default__", 0))

    _maybe_run_lighter_ohlcv_collector(config, data_dir, coins, effective_start_ts, end_ts)

    # Lighter market defaults
    LIGHTER_MARKETS = {
        "HYPE": {"qty_step": 0.01, "price_step": 0.0001, "min_qty": 0.01, "min_cost": 1.0,
                 "c_mult": 1.0, "maker": 0.0002, "taker": 0.00055},
        "BTC": {"qty_step": 0.00001, "price_step": 0.1, "min_qty": 0.00001, "min_cost": 1.0,
                "c_mult": 1.0, "maker": 0.0002, "taker": 0.00055},
        "ETH": {"qty_step": 0.0001, "price_step": 0.01, "min_qty": 0.0001, "min_cost": 1.0,
                "c_mult": 1.0, "maker": 0.0002, "taker": 0.00055},
        # SPY (S&P 500 perp on Lighter, market_id 128): size_decimals=4, price_decimals=2,
        # min_base_amount=0.01, min_quote_amount=10. Lighter's live SPY fee is 0/0 (queried
        # 2026-06-06), but we model a deliberately pessimistic flat 0.05% maker/taker for safety.
        "SPY": {"qty_step": 0.0001, "price_step": 0.01, "min_qty": 0.01, "min_cost": 10.0,
                "c_mult": 1.0, "maker": 0.0005, "taker": 0.0005},
    }
    # Try to load precise settings from market metadata cache
    meta_path = Path("caches/lighter/market_metadata.json")
    if meta_path.exists():
        try:
            import json as _json
            meta = _json.load(open(meta_path))
            for coin, info in meta.items():
                if coin in LIGHTER_MARKETS:
                    mi = info.get("info", {})
                    if "price_decimals" in mi:
                        LIGHTER_MARKETS[coin]["price_step"] = 10 ** -int(mi["price_decimals"])
                    if "size_decimals" in mi:
                        LIGHTER_MARKETS[coin]["qty_step"] = 10 ** -int(mi["size_decimals"])
                        LIGHTER_MARKETS[coin]["min_qty"] = 10 ** -int(mi["size_decimals"])
        except Exception as e:
            logging.warning(f"Could not load lighter market metadata: {e}")

    valid_coins = {}
    global_start_time = float("inf")
    global_end_time = float("-inf")

    for coin in coins:
        coin_dir = _daily_npy_coin_dir(data_dir, coin)
        if not coin_dir.exists():
            logging.warning(f"lighter: no data directory for {coin} at {coin_dir}")
            continue

        frames = []
        current_ms = effective_start_ts
        while current_ms <= end_ts:
            dt = datetime.fromtimestamp(current_ms / 1000, tz=timezone.utc)
            date_str = dt.strftime("%Y-%m-%d")
            fpath = coin_dir / f"{date_str}.npy"
            if fpath.exists():
                arr = _daily_npy_load_day(fpath)
                # Filter to requested range
                mask = (arr[:, 0] >= effective_start_ts) & (arr[:, 0] <= end_ts)
                if mask.any():
                    frames.append(arr[mask])
            current_ms += 86_400_000

        if not frames:
            logging.warning(f"lighter: no candle data found for {coin}")
            continue

        data = np.concatenate(frames)
        # Remove duplicate timestamps and sort
        _, unique_idx = np.unique(data[:, 0], return_index=True)
        data = data[unique_idx]

        # Convert from [ts, o, h, l, c, v] to [ts, h, l, c, v] (backtest format)
        hlcv_data = data[:, [0, 2, 3, 4, 5]]

        # Check for gaps
        diffs = np.diff(hlcv_data[:, 0])
        gap_count = np.sum(diffs != interval_ms)
        if gap_count > 0:
            logging.info(f"lighter: {coin} has {gap_count} gaps in candle data, filling...")
            # Fill gaps with forward-fill
            full_ts = np.arange(hlcv_data[0, 0], hlcv_data[-1, 0] + interval_ms, interval_ms)
            full_data = np.full((len(full_ts), 5), np.nan, dtype=np.float64)
            full_data[:, 0] = full_ts
            # Map existing data
            for row in hlcv_data:
                idx = int((row[0] - full_ts[0]) / interval_ms)
                if 0 <= idx < len(full_data):
                    full_data[idx, 1:] = row[1:]
            # Forward fill
            for i in range(1, len(full_data)):
                if np.isnan(full_data[i, 1]):
                    full_data[i, 1:4] = full_data[i - 1, 3]  # h=l=c=prev_close
                    full_data[i, 4] = 0.0  # volume=0
            # Backward fill leading NaN
            for i in range(len(full_data)):
                if not np.isnan(full_data[i, 1]):
                    if i > 0:
                        full_data[:i, 1:4] = full_data[i, 1]
                        full_data[:i, 4] = 0.0
                    break
            hlcv_data = full_data

        valid_coins[coin] = hlcv_data
        global_start_time = min(global_start_time, hlcv_data[0, 0])
        global_end_time = max(global_end_time, hlcv_data[-1, 0])
        logging.info(f"lighter: loaded {coin} — {len(hlcv_data)} candles "
                     f"({ts_to_date(int(hlcv_data[0, 0]))} to {ts_to_date(int(hlcv_data[-1, 0]))})")

    if not valid_coins:
        raise ValueError("No valid coins found in lighter data")

    n_timesteps = int((global_end_time - global_start_time) / interval_ms) + 1
    n_coins = len(valid_coins)
    timestamps = np.arange(global_start_time, global_end_time + interval_ms, interval_ms)
    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)

    mss = {}
    for i, coin in enumerate(sorted(valid_coins)):
        hlcv_data = valid_coins[coin]
        start_idx = int((hlcv_data[0, 0] - global_start_time) / interval_ms)
        end_idx = start_idx + len(hlcv_data)
        unified_array[start_idx:end_idx, i, :] = hlcv_data[:, 1:]  # h, l, c, v

        first_idx = start_idx
        last_idx = end_idx - 1
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx

        defaults = LIGHTER_MARKETS.get(coin, {
            "qty_step": 0.01, "price_step": 0.0001, "min_qty": 0.01,
            "min_cost": 1.0, "c_mult": 1.0, "maker": 0.0002, "taker": 0.00055,
        })
        mss[coin] = {
            **defaults,
            "maker_fee": defaults["maker"],
            "taker_fee": defaults["taker"],
            "hedge_mode": True,
            "feeSide": "get",
            "first_valid_index": first_idx,
            "last_valid_index": last_idx,
            "warmup_minutes": warm_minutes,
            "trade_start_index": trade_start_idx,
        }

    warmup_minutes = compute_backtest_warmup_minutes(config)
    warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // interval_ms))
    mss["__meta__"] = {
        "requested_start_ts": int(requested_start_ts),
        "requested_start_date": ts_to_date(requested_start_ts),
        "effective_start_ts": int(timestamps[0]),
        "effective_start_date": ts_to_date(int(timestamps[0])),
        "warmup_minutes_requested": int(warmup_minutes),
        "warmup_minutes_provided": int(warmup_provided),
    }

    # BTC prices
    btc_collateral_cap = float(config.get("backtest", {}).get("btc_collateral_cap", 0.0))
    if btc_collateral_cap > 0.0 and "BTC" in valid_coins:
        btc_data = valid_coins["BTC"]
        btc_close = btc_data[:, 3]  # close prices
        btc_usd_prices = np.ones(len(timestamps), dtype=np.float64)
        start_idx = int((btc_data[0, 0] - global_start_time) / interval_ms)
        btc_usd_prices[start_idx:start_idx + len(btc_close)] = btc_close
        # Forward/backward fill
        for i in range(1, len(btc_usd_prices)):
            if btc_usd_prices[i] == 1.0 and btc_usd_prices[i - 1] != 1.0:
                btc_usd_prices[i] = btc_usd_prices[i - 1]
    else:
        btc_usd_prices = np.ones(len(timestamps), dtype=np.float64)

    logging.info(f"lighter: prepared {n_coins} coin(s), {n_timesteps} timesteps")
    return mss, timestamps, unified_array, btc_usd_prices


# ===========================================================================
# Hyperliquid offline OHLCV (mirrors the Lighter path; identical daily .npy format)
# ===========================================================================

# Default per-coin market specs used in backtests. Refined at runtime from
# caches/hyperliquid/market_metadata.json (szDecimals -> qty_step) when the
# collector has cached it. SP500 = xyz:SP500 (the Trade[XYZ] HIP-3 perp).
HYPERLIQUID_MARKETS = {
    # S&P 500-USDC perp (xyz:SP500): szDecimals=3 -> qty_step 0.001; price ~6-7k so the
    # 5-significant-figure tick is ~0.1; $10 min order value; isolated-only (HIP-3).
    # Fees are builder-set on Trade[XYZ]; modeled here as a conservative placeholder —
    # verify against the live meta / your fee tier before trusting absolute returns.
    "SP500": {"qty_step": 0.001, "price_step": 0.1, "min_qty": 0.001, "min_cost": 10.0,
              "c_mult": 1.0, "maker": 0.0002, "taker": 0.0005},
}


def _resolve_hyperliquid_data_dir(config) -> Path:
    raw = Path(config.get("backtest", {}).get("hyperliquid_data_dir", "caches/ohlcv/hyperliquid/1m"))
    if raw.is_absolute():
        return raw
    return (_daily_npy_config_root(config) / raw).resolve()


def _hyperliquid_meta_path(config) -> Path:
    return (_daily_npy_config_root(config) / "caches/hyperliquid/market_metadata.json").resolve()


def _hyperliquid_aws_env_path(config) -> Path:
    raw = config.get("backtest", {}).get("aws_env_file", "aws.env")
    p = Path(raw)
    if not p.is_absolute():
        p = _daily_npy_config_root(config) / raw
    return p


def _hyperliquid_archive_available(config) -> bool:
    """Reservoir archive (full 1m history via DuckDB) is usable iff AWS creds + duckdb present.

    Creds come from AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY env vars or an aws.env file
    (PUBLIC_KEY/SECRET_KEY). Without them we fall back to the candleSnapshot API (recent only).
    """
    have_creds = bool(os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY"))
    if not have_creds:
        have_creds = _hyperliquid_aws_env_path(config).exists()
    if not have_creds:
        return False
    try:
        import duckdb  # noqa: F401
    except Exception:
        logging.warning(
            "hyperliquid: AWS creds present but duckdb is not installed; using candleSnapshot API "
            "(recent ~3.6d only). Run `pip install duckdb` to download full history from the archive."
        )
        return False
    return True


def _hyperliquid_reservoir_opt_in(config) -> bool:
    """Whether the user explicitly opted into the paid Reservoir S3 archive.

    OFF by default — the archive is requester-pays (costs money). Enable per-run with env
    HL_USE_RESERVOIR_ARCHIVE=1, or per-config with backtest.use_reservoir_archive=true. When
    off, historical data pulling uses only the free public candleSnapshot API.
    """
    env_val = os.environ.get("HL_USE_RESERVOIR_ARCHIVE")
    if env_val is not None and env_val.strip() != "":
        return _truthy_config_value(env_val)
    return _truthy_config_value(config.get("backtest", {}).get("use_reservoir_archive", False))


def _hyperliquid_unfillable_gap_days(
    data_dir: Path, coins, effective_start_ts: int, end_ts: int
) -> Dict[str, List[str]]:
    """Days the backtest needs that are (a) missing locally and (b) older than the public API's
    ~5000-candle reach — i.e. only the paid Reservoir S3 archive could supply them.

    Returns {coin: [sorted "YYYY-MM-DD", ...]} for coins that have such holes.
    """
    now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
    api_reach_ts = now_ms - HL_PUBLIC_API_REACH_MINUTES * MS_PER_MINUTE
    upper = min(int(end_ts), now_ms)
    out: Dict[str, List[str]] = {}
    for coin in sorted(set(coins)):
        coin_dir = data_dir / coin
        missing: List[str] = []
        current_ms = _daily_npy_day_start(effective_start_ts)
        while current_ms <= upper:
            day_end = current_ms + MS_PER_DAY - 1
            # Only days fully older than the API reach are unfillable for free.
            if day_end < api_reach_ts:
                day_str = _daily_npy_date_str(current_ms)
                fpath = coin_dir / f"{day_str}.npy"
                has = False
                if fpath.exists():
                    try:
                        arr = _daily_npy_load_day(fpath)
                        lo = max(current_ms, int(effective_start_ts))
                        hi = min(day_end, upper)
                        mask = (arr[:, 0] >= lo) & (arr[:, 0] <= hi) & np.isfinite(arr[:, 4])
                        has = bool(mask.any())
                    except Exception:
                        has = False
                if not has:
                    missing.append(day_str)
            current_ms += MS_PER_DAY
        if missing:
            out[coin] = missing
    return out


def _warn_hyperliquid_unfillable_gaps(
    data_dir: Path, coins, effective_start_ts: int, end_ts: int
) -> None:
    """Warn (loudly, once) about pre-API-reach holes that only the paid S3 archive could fill,
    and print the exact explicit command to fill ONLY those holes."""
    gaps = _hyperliquid_unfillable_gap_days(data_dir, coins, effective_start_ts, end_ts)
    if not gaps:
        return
    total = sum(len(v) for v in gaps.values())
    details = "; ".join(f"{c}: {d[0]}..{d[-1]} ({len(d)}d)" for c, d in gaps.items())
    symbols = ",".join(sorted(gaps.keys()))
    emin = min(d[0] for d in gaps.values())
    emax = max(d[-1] for d in gaps.values())
    logging.warning(
        "hyperliquid: %d 1m day(s) this backtest needs are older than the public API's ~%d-candle "
        "(~%.1fd) reach and are NOT cached, so they cannot be filled for free: %s. The run will "
        "proceed only on the data actually available. To fill ONLY these holes from the (paid, "
        "requester-pays) Reservoir S3 archive, run this step explicitly — it skips days already on "
        "disk:\n"
        '    PowerShell:  $env:SYMBOLS="%s"; $env:EARLIEST_DATE="%s"; $env:END_DATE="%s"; python src\\tools\\hyperliquid_archive_downloader.py\n'
        "    bash:        SYMBOLS=%s EARLIEST_DATE=%s END_DATE=%s python src/tools/hyperliquid_archive_downloader.py\n"
        "(or set HL_USE_RESERVOIR_ARCHIVE=1 to let backtests auto-use the archive).",
        total, HL_PUBLIC_API_REACH_MINUTES, HL_PUBLIC_API_REACH_MINUTES / 1440.0, details,
        symbols, emin, emax, symbols, emin, emax,
    )


def _maybe_run_hyperliquid_ohlcv_collector(config, data_dir: Path, coins, effective_start_ts: int, end_ts: int) -> None:
    # Source policy: the paid S3 archive is used ONLY when the user explicitly opts in
    # (env HL_USE_RESERVOIR_ARCHIVE=1 or backtest.use_reservoir_archive=true). Otherwise we use
    # the free public candleSnapshot API and warn about any holes only the archive could fill.
    archive_available = _hyperliquid_archive_available(config)
    use_archive = archive_available and _hyperliquid_reservoir_opt_in(config)
    if not use_archive:
        _warn_hyperliquid_unfillable_gaps(data_dir, coins, effective_start_ts, end_ts)

    auto_collect = config.get("backtest", {}).get("auto_collect_hyperliquid_ohlcvs", True)
    if not _truthy_config_value(auto_collect):
        return

    needed = []
    reasons = {}
    for coin in sorted(set(coins)):
        # exchange-neutral helper (operates only on the daily-.npy cache under data_dir)
        needs_collection, reason = _daily_npy_coin_needs_collection(
            data_dir, coin, effective_start_ts, end_ts
        )
        if needs_collection:
            needed.append(coin)
            reasons[coin] = reason

    if not needed:
        return

    src_dir = Path(__file__).resolve().parent
    api_collector = src_dir / "tools" / "hyperliquid_ohlcv_collector.py"
    archive_downloader = src_dir / "tools" / "hyperliquid_archive_downloader.py"

    # `use_archive` was decided above (opt-in only). Default is the free public candleSnapshot
    # API; the Reservoir archive (full 1m history via 1s->1m aggregation) is used only when the
    # user explicitly opted in AND creds+duckdb are available.
    script = archive_downloader if use_archive else api_collector
    source = "Reservoir archive (1s->1m, full history)" if use_archive else "candleSnapshot API (~3.6d only)"
    if not script.exists():
        raise FileNotFoundError(f"Hyperliquid OHLCV downloader not found at {script}")

    def _build_env(for_archive: bool) -> dict:
        env = os.environ.copy()
        existing_pythonpath = env.get("PYTHONPATH")
        env["PYTHONPATH"] = (
            str(src_dir) if not existing_pythonpath else str(src_dir) + os.pathsep + existing_pythonpath
        )
        env["PYTHONUTF8"] = env.get("PYTHONUTF8", "1")
        env["SYMBOLS"] = ",".join(needed)
        env["EARLIEST_DATE"] = _daily_npy_date_str(effective_start_ts)
        env["HYPERLIQUID_DATA_DIR"] = str(data_dir.resolve())
        env["HL_DEX"] = str(config.get("backtest", {}).get("hyperliquid_dex", "xyz"))
        if for_archive:
            env["END_DATE"] = _daily_npy_date_str(end_ts)
            env["AWS_ENV_FILE"] = str(_hyperliquid_aws_env_path(config))
        else:
            env["RUN_ONCE"] = "1"
            env["HYPERLIQUID_META_PATH"] = str(_hyperliquid_meta_path(config))
        return env

    logging.info(
        "hyperliquid: downloading OHLCV for %s from %s via %s (%s)",
        ",".join(needed),
        _daily_npy_date_str(effective_start_ts),
        source,
        ", ".join(f"{coin}: {reasons[coin]}" for coin in needed),
    )
    # Downloading is best-effort: if creds are missing or a download fails, warn and proceed
    # with whatever 1m data is already cached (the prep only errors if there is NO data at all).
    try:
        result = subprocess.run(  # noqa: S603
            [sys.executable, str(script)], cwd=str(_repo_root()), env=_build_env(use_archive), check=False
        )
        if result.returncode != 0 and use_archive and api_collector.exists():
            logging.warning(
                "hyperliquid: archive download failed (exit %s); trying candleSnapshot API",
                result.returncode,
            )
            result = subprocess.run(  # noqa: S603
                [sys.executable, str(api_collector)], cwd=str(_repo_root()), env=_build_env(False), check=False
            )
        if result.returncode != 0:
            logging.warning(
                "hyperliquid: OHLCV download did not complete (exit %s); proceeding with the 1m data "
                "already in %s. For full history, add aws.env (Reservoir keys) + `pip install duckdb` "
                "and opt in with HL_USE_RESERVOIR_ARCHIVE=1 (or backtest.use_reservoir_archive=true).",
                result.returncode, data_dir,
            )
    except Exception as e:
        logging.warning(
            "hyperliquid: OHLCV download step failed (%s); proceeding with already-cached 1m data.", e
        )


def _load_hyperliquid_market_specs(config) -> dict:
    """Per-coin market specs, refined from cached meta (szDecimals) where available."""
    specs = {coin: dict(v) for coin, v in HYPERLIQUID_MARKETS.items()}
    meta_path = _hyperliquid_meta_path(config)
    if meta_path.exists():
        try:
            meta = json.load(open(meta_path))
            for coin, info in meta.items():
                sd = info.get("sz_decimals")
                if sd is None:
                    continue
                step = 10 ** -int(sd)
                entry = specs.setdefault(coin, {
                    "qty_step": step, "price_step": 0.1, "min_qty": step,
                    "min_cost": 10.0, "c_mult": 1.0, "maker": 0.0002, "taker": 0.0005,
                })
                entry["qty_step"] = step
                entry["min_qty"] = step
        except Exception as e:
            logging.warning(f"Could not load hyperliquid market metadata: {e}")
    return specs


def _dedup_and_quality_check(coin: str, data: np.ndarray) -> np.ndarray:
    """Always-on dedup + quality pass for assembled 1m candles [ts, o, h, l, c, v].

    - dedupes by timestamp (sorted ascending, first occurrence wins);
    - drops structurally invalid rows (non-finite OHLCV, non-positive close, or high < low)
      so the downstream gap-fill can reconstruct them from neighbours;
    - logs a concise summary whenever it removes anything.

    Returns the cleaned array (possibly empty).
    """
    n0 = len(data)
    if n0 == 0:
        return data
    # dedup by timestamp — np.unique returns sorted unique values, so ts ends up ascending too.
    _, unique_idx = np.unique(data[:, 0], return_index=True)
    data = data[unique_idx]
    n_dupes = n0 - len(data)

    # quality: drop rows we cannot trust
    finite = np.isfinite(data[:, 1:6]).all(axis=1)
    positive_close = data[:, 4] > 0
    consistent = data[:, 2] >= data[:, 3]  # high >= low
    good = finite & positive_close & consistent
    n_bad = int((~good).sum())
    data = data[good]

    if n_dupes or n_bad:
        logging.warning(
            "hyperliquid: %s data quality — removed %d duplicate timestamp(s) and %d invalid row(s) "
            "(non-finite / non-positive close / high<low); %d clean rows remain (gaps are filled next).",
            coin, n_dupes, n_bad, len(data),
        )
    return data


def _drop_incomplete_tail(coin: str, data: np.ndarray, now_ms: int) -> np.ndarray:
    """Completeness guard — never treat a not-yet-elapsed minute as a real candle.

    A daily .npy file *existing* does NOT mean that day is complete. The collector writes
    a full 1440-row file as soon as a UTC day begins and forward-fills every minute that
    hasn't traded yet — including the entire remaining future of *today* — with the last
    close and zero volume. Those padded rows look structurally valid (they survive the
    quality check), so without this guard the backtest would silently consume today's
    not-yet-existent minutes as flat real candles. A day only becomes trustworthy once it
    has fully elapsed and the collector re-fetches it (heal_partial_days drops the padded
    tail and re-pulls the real candles the day after).

    Rule: drop every candle whose minute has not closed yet (ts >= the current minute). A
    real 1m candle cannot exist before its minute is over, so this removes exactly the
    fake-future padding while keeping every genuinely-elapsed candle (real or gap-filled).
    It is a no-op for the common case (backtest end_date defaults to ~2 days ago); it only
    bites when an explicit, very recent end_date would otherwise reach into the live day.
    """
    if len(data) == 0:
        return data
    cutoff = (int(now_ms) // MS_PER_MINUTE) * MS_PER_MINUTE  # start of the current, unfinished minute
    keep = data[:, 0] < cutoff
    n_dropped = int((~keep).sum())
    if n_dropped:
        logging.info(
            "hyperliquid: %s — excluded %d not-yet-complete minute(s) at/after %s UTC "
            "(today's day file is forward-filled into the future; only elapsed minutes are trusted).",
            coin, n_dropped, ts_to_date(int(cutoff)),
        )
    return data[keep]


async def _prepare_hlcvs_hyperliquid(config, coins, effective_start_ts, requested_start_ts, end_ts):
    """Load pre-downloaded Hyperliquid daily .npy files into backtest format.

    Reads from caches/ohlcv/hyperliquid/1m/{COIN}/YYYY-MM-DD.npy (the same format the
    Lighter path uses). Hyperliquid's public candleSnapshot API only retains ~5000
    recent 1m candles (~3.6 days); to backtest a longer span, drop an archive of daily
    .npy files (same dtype) into that directory or run the collector continuously.
    Returns (mss, timestamps, unified_array, btc_usd_prices).
    """
    data_dir = _resolve_hyperliquid_data_dir(config)
    interval_ms = 60_000
    per_coin_warmups = compute_per_coin_warmup_minutes(config)
    default_warm = int(per_coin_warmups.get("__default__", 0))

    _maybe_run_hyperliquid_ohlcv_collector(config, data_dir, coins, effective_start_ts, end_ts)

    market_specs = _load_hyperliquid_market_specs(config)
    default_spec = {
        "qty_step": 0.001, "price_step": 0.1, "min_qty": 0.001,
        "min_cost": 10.0, "c_mult": 1.0, "maker": 0.0002, "taker": 0.0005,
    }

    valid_coins = {}
    global_start_time = float("inf")
    global_end_time = float("-inf")
    # Wall-clock boundary for the completeness guard below (one consistent value for all coins).
    now_ms = int(utc_ms())

    for coin in coins:
        coin_dir = _daily_npy_coin_dir(data_dir, coin)
        if not coin_dir.exists():
            logging.warning(f"hyperliquid: no data directory for {coin} at {coin_dir}")
            continue

        frames = []
        current_ms = effective_start_ts
        while current_ms <= end_ts:
            date_str = _daily_npy_date_str(current_ms)
            fpath = coin_dir / f"{date_str}.npy"
            if fpath.exists():
                arr = _daily_npy_load_day(fpath)
                mask = (arr[:, 0] >= effective_start_ts) & (arr[:, 0] <= end_ts)
                if mask.any():
                    frames.append(arr[mask])
            current_ms += MS_PER_DAY

        if not frames:
            logging.warning(f"hyperliquid: no candle data found for {coin}")
            continue

        data = np.concatenate(frames)
        data = _dedup_and_quality_check(coin, data)
        # Completeness guard: never count today's not-yet-elapsed (forward-filled) minutes as real.
        data = _drop_incomplete_tail(coin, data, now_ms)
        if len(data) == 0:
            logging.warning(f"hyperliquid: no valid candle data for {coin} after dedup/quality checks")
            continue

        # Convert [ts, o, h, l, c, v] -> [ts, h, l, c, v] (backtest format)
        hlcv_data = data[:, [0, 2, 3, 4, 5]]

        diffs = np.diff(hlcv_data[:, 0])
        gap_count = np.sum(diffs != interval_ms)
        if gap_count > 0:
            logging.info(f"hyperliquid: {coin} has {gap_count} gaps in candle data, filling...")
            full_ts = np.arange(hlcv_data[0, 0], hlcv_data[-1, 0] + interval_ms, interval_ms)
            full_data = np.full((len(full_ts), 5), np.nan, dtype=np.float64)
            full_data[:, 0] = full_ts
            for row in hlcv_data:
                idx = int((row[0] - full_ts[0]) / interval_ms)
                if 0 <= idx < len(full_data):
                    full_data[idx, 1:] = row[1:]
            for i in range(1, len(full_data)):
                if np.isnan(full_data[i, 1]):
                    full_data[i, 1:4] = full_data[i - 1, 3]  # h=l=c=prev_close
                    full_data[i, 4] = 0.0  # volume=0
            for i in range(len(full_data)):
                if not np.isnan(full_data[i, 1]):
                    if i > 0:
                        full_data[:i, 1:4] = full_data[i, 1]
                        full_data[:i, 4] = 0.0
                    break
            hlcv_data = full_data

        valid_coins[coin] = hlcv_data
        global_start_time = min(global_start_time, hlcv_data[0, 0])
        global_end_time = max(global_end_time, hlcv_data[-1, 0])
        logging.info(f"hyperliquid: loaded {coin} — {len(hlcv_data)} candles "
                     f"({ts_to_date(int(hlcv_data[0, 0]))} to {ts_to_date(int(hlcv_data[-1, 0]))})")

    if not valid_coins:
        raise ValueError(
            "No valid coins found in hyperliquid data. The public candleSnapshot API only "
            "retains ~3.6 days of 1m history; ensure the collector ran, or provide an archive "
            "of daily .npy files under caches/ohlcv/hyperliquid/1m/{COIN}/ (same dtype)."
        )

    n_timesteps = int((global_end_time - global_start_time) / interval_ms) + 1
    n_coins = len(valid_coins)
    timestamps = np.arange(global_start_time, global_end_time + interval_ms, interval_ms)
    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)

    mss = {}
    for i, coin in enumerate(sorted(valid_coins)):
        hlcv_data = valid_coins[coin]
        start_idx = int((hlcv_data[0, 0] - global_start_time) / interval_ms)
        end_idx = start_idx + len(hlcv_data)
        unified_array[start_idx:end_idx, i, :] = hlcv_data[:, 1:]  # h, l, c, v

        first_idx = start_idx
        last_idx = end_idx - 1
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx

        defaults = market_specs.get(coin, default_spec)
        mss[coin] = {
            **defaults,
            "maker_fee": defaults["maker"],
            "taker_fee": defaults["taker"],
            "hedge_mode": True,
            "feeSide": "get",
            "first_valid_index": first_idx,
            "last_valid_index": last_idx,
            "warmup_minutes": warm_minutes,
            "trade_start_index": trade_start_idx,
        }

    warmup_minutes = compute_backtest_warmup_minutes(config)
    warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // interval_ms))
    mss["__meta__"] = {
        "requested_start_ts": int(requested_start_ts),
        "requested_start_date": ts_to_date(requested_start_ts),
        "effective_start_ts": int(timestamps[0]),
        "effective_start_date": ts_to_date(int(timestamps[0])),
        "warmup_minutes_requested": int(warmup_minutes),
        "warmup_minutes_provided": int(warmup_provided),
    }

    # BTC collateral is not used for the Hyperliquid SP500 single-asset setup.
    btc_collateral_cap = float(config.get("backtest", {}).get("btc_collateral_cap", 0.0))
    btc_usd_prices = np.ones(len(timestamps), dtype=np.float64)
    if btc_collateral_cap > 0.0 and "BTC" in valid_coins:
        btc_data = valid_coins["BTC"]
        btc_close = btc_data[:, 3]
        start_idx = int((btc_data[0, 0] - global_start_time) / interval_ms)
        btc_usd_prices[start_idx:start_idx + len(btc_close)] = btc_close
        for i in range(1, len(btc_usd_prices)):
            if btc_usd_prices[i] == 1.0 and btc_usd_prices[i - 1] != 1.0:
                btc_usd_prices[i] = btc_usd_prices[i - 1]

    logging.info(f"hyperliquid: prepared {n_coins} coin(s), {n_timesteps} timesteps")
    return mss, timestamps, unified_array, btc_usd_prices


async def prepare_hlcvs(config: dict, exchange: str, *, force_refetch_gaps: bool = False):
    approved = require_live_value(config, "approved_coins")
    coins = sorted(
        set(symbol_to_coin(c) for c in approved["long"]) | set(symbol_to_coin(c) for c in approved["short"])
    )
    exchange = normalize_exchange_name(exchange)
    requested_start_date = require_config_value(config, "backtest.start_date")
    requested_start_ts = int(date_to_ts(requested_start_date))
    end_date = format_end_date(require_config_value(config, "backtest.end_date"))
    end_ts = int(date_to_ts(end_date))

    warmup_minutes = compute_backtest_warmup_minutes(config)
    minute_ms = 60_000
    warmup_ms = warmup_minutes * minute_ms
    effective_start_ts = max(0, requested_start_ts - warmup_ms)
    effective_start_ts = (effective_start_ts // minute_ms) * minute_ms

    # Lighter / Hyperliquid: load directly from pre-downloaded daily .npy files
    if exchange == "lighter":
        return await _prepare_hlcvs_lighter(config, coins, effective_start_ts, requested_start_ts, end_ts)
    if exchange == "hyperliquid":
        return await _prepare_hlcvs_hyperliquid(config, coins, effective_start_ts, requested_start_ts, end_ts)

    effective_start_date = ts_to_date(effective_start_ts)

    if warmup_minutes > 0:
        logging.info(
            f"{exchange} applying warmup: {warmup_minutes} minutes -> fetch start {effective_start_date}, "
            f"requested start {requested_start_date}"
        )

    om = HLCVManager(
        exchange,
        effective_start_date,
        end_date,
        gap_tolerance_ohlcvs_minutes=require_config_value(config, "backtest.gap_tolerance_ohlcvs_minutes"),
        cm_debug_level=int(config.get("backtest", {}).get("cm_debug_level", 0) or 0),
        cm_progress_log_interval_seconds=float(
            config.get("backtest", {}).get("cm_progress_log_interval_seconds", 10.0) or 10.0
        ),
        force_refetch_gaps=force_refetch_gaps,
    )

    try:
        mss, timestamps, hlcvs = await prepare_hlcvs_internal(
            config,
            coins,
            exchange,
            effective_start_ts,
            requested_start_ts,
            end_ts,
            om,
        )

        btc_collateral_cap = float(config.get("backtest", {}).get("btc_collateral_cap", 0.0))
        if btc_collateral_cap > 0.0:
            om.update_date_range(int(timestamps[0]), int(timestamps[-1]))
            btc_df = await om.get_ohlcvs("BTC")
            if btc_df.empty:
                raise ValueError(f"Failed to fetch BTC/USD prices from {exchange}")
            btc_df = btc_df.set_index("timestamp").reindex(timestamps, method="ffill").ffill().bfill().reset_index()
            btc_usd_prices = btc_df["close"].values
        else:
            logging.info("BTC collateral disabled (cap=0); using dummy BTC prices")
            btc_usd_prices = np.ones(len(timestamps), dtype=np.float64)

        warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // minute_ms))
        mss["__meta__"] = {
            "requested_start_ts": int(requested_start_ts),
            "requested_start_date": ts_to_date(requested_start_ts),
            "effective_start_ts": int(timestamps[0]),
            "effective_start_date": ts_to_date(int(timestamps[0])),
            "warmup_minutes_requested": int(warmup_minutes),
            "warmup_minutes_provided": int(warmup_provided),
        }

        return mss, timestamps, hlcvs, btc_usd_prices
    finally:
        await om.aclose()
        if om.cc:
            await om.cc.close()


async def prepare_hlcvs_internal(
    config,
    coins,
    exchange,
    effective_start_ts,
    requested_start_ts,
    end_ts,
    om: HLCVManager,
):
    minimum_coin_age_days = float(require_live_value(config, "minimum_coin_age_days"))
    interval_ms = 60_000

    first_timestamps_unified = await get_first_timestamps_unified(coins)
    per_coin_warmups = compute_per_coin_warmup_minutes(config)
    default_warm = int(per_coin_warmups.get("__default__", 0))

    cache_dir = Path(f"./caches/hlcvs_data/{uuid4().hex[:16]}")
    cache_dir.mkdir(parents=True, exist_ok=True)

    coin_metadata = {}
    valid_coins = {}
    global_start_time = float("inf")
    global_end_time = float("-inf")
    await om.load_markets()
    min_coin_age_ms = 1000 * 60 * 60 * 24 * minimum_coin_age_days

    progress = ProgressTracker(len(coins), f"{exchange} fetching candles")
    progress.maybe_log(force=True)

    # Async helper to fetch a single coin's data with all validation
    async def fetch_coin_data(coin: str, sem: asyncio.Semaphore):
        """Fetch and validate data for a single coin. Returns (coin, metadata, file_path, data_bounds) or None."""
        async with sem:  # Rate limiting
            try:
                adjusted_start_ts = int(effective_start_ts)

                # Validation: check if coin exists
                if not om.has_coin(coin):
                    _pct_log("info", progress.pct(), f"{exchange} coin {coin} missing, skipping")
                    return None

                if coin not in first_timestamps_unified:
                    _pct_log("info", progress.pct(), f"coin {coin} missing from first_timestamps_unified, skipping")
                    return None

                # Minimum coin age validation
                if minimum_coin_age_days > 0.0:
                    try:
                        first_ts = await om.get_first_timestamp(coin)
                    except Exception as e:
                        _pct_log("error", progress.pct(), f"error with get_first_timestamp for {coin} {e}. Skipping")
                        traceback.print_exc()
                        return None

                    if first_ts >= end_ts:
                        _pct_log(
                            "info", progress.pct(),
                            f"{exchange} Coin {coin} too young, start date {ts_to_date(first_ts)}. Skipping"
                        )
                        return None

                    coin_age_days = int(round(utc_ms() - first_timestamps_unified[coin]) / (1000 * 60 * 60 * 24))
                    if coin_age_days < minimum_coin_age_days:
                        _pct_log(
                            "info", progress.pct(),
                            f"{exchange} Coin {coin}: Not traded due to min_coin_age {int(minimum_coin_age_days)} days. "
                            f"{coin} is {coin_age_days} days old. Skipping"
                        )
                        return None

                    new_adjusted_start_ts = max(first_timestamps_unified[coin] + min_coin_age_ms, first_ts)
                    if new_adjusted_start_ts > adjusted_start_ts:
                        _pct_log(
                            "info", progress.pct(),
                            f"{exchange} Coin {coin}: Adjusting start date from {ts_to_date(adjusted_start_ts)} "
                            f"to {ts_to_date(new_adjusted_start_ts)}"
                        )
                        adjusted_start_ts = int(new_adjusted_start_ts)

                # Fetch OHLCV data
                om.update_date_range(adjusted_start_ts)
                df = await om.get_ohlcvs(coin)
                data = df[["timestamp", "high", "low", "close", "volume"]].values

                if len(data) == 0:
                    return None

                # Validate no gaps
                assert (np.diff(data[:, 0]) == interval_ms).all(), f"gaps in hlcv data {coin}"

                # Save to cache
                file_path = cache_dir / f"{coin}.npy"
                dump_ohlcv_data(data, str(file_path))

                # Prepare metadata
                metadata = {
                    "start_time": int(data[0, 0]),
                    "end_time": int(data[-1, 0]),
                    "length": len(data),
                }

                data_bounds = (data[0, 0], data[-1, 0])

                return (coin, metadata, file_path, data_bounds)

            except Exception as e:
                _pct_log("error", progress.pct(), f"error with get_ohlcvs for {coin} {e}. Skipping")
                traceback.print_exc()
                return None

    # Parallelize coin fetching with rate limiting.
    # Bybit is more sensitive to bursts; keep concurrency lower to reduce timeouts.
    COIN_CONCURRENCY = 3 if str(exchange).lower() == "bybit" else 6
    sem = asyncio.Semaphore(COIN_CONCURRENCY)

    tasks = [fetch_coin_data(coin, sem) for coin in coins]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Process results
    for result in results:
        progress.maybe_log()

        if result is None or isinstance(result, Exception):
            progress.update()
            continue

        coin, metadata, file_path, data_bounds = result
        coin_metadata[coin] = metadata
        valid_coins[coin] = file_path
        global_start_time = min(global_start_time, data_bounds[0])
        global_end_time = max(global_end_time, data_bounds[1])
        progress.update()

    progress.log_done()

    if not valid_coins:
        raise ValueError("No valid coins found with data")

    n_timesteps = int((global_end_time - global_start_time) / interval_ms) + 1
    n_coins = len(valid_coins)
    timestamps = np.arange(global_start_time, global_end_time + interval_ms, interval_ms)
    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)
    valid_index_ranges = {}

    logging.info(
        f"{exchange} Unifying data for {len(valid_coins)} coin{'s' if len(valid_coins) > 1 else ''} into single numpy array..."
    )
    for i, coin in enumerate(valid_coins):
        file_path = valid_coins[coin]
        ohlcv = np.load(file_path)
        start_idx = int((ohlcv[0, 0] - global_start_time) / interval_ms)
        end_idx = start_idx + len(ohlcv)
        coin_data = ohlcv[:, 1:]
        unified_array[start_idx:end_idx, i, :] = coin_data
        first_idx = int(start_idx)
        last_idx = int(end_idx - 1)
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx
        valid_index_ranges[coin] = (first_idx, last_idx)

        os.remove(file_path)

    try:
        os.rmdir(cache_dir)
    except OSError:
        pass
    mss = {}
    for coin in sorted(valid_coins):
        meta = om.get_market_specific_settings(coin)
        first_idx, last_idx = valid_index_ranges.get(coin, (unified_array.shape[0], unified_array.shape[0]))
        meta["first_valid_index"] = first_idx
        meta["last_valid_index"] = last_idx
        warm_minutes = int(per_coin_warmups.get(coin, default_warm))
        meta["warmup_minutes"] = warm_minutes
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx
        meta["trade_start_index"] = trade_start_idx
        mss[coin] = meta
    return mss, timestamps, unified_array


async def prepare_hlcvs_combined(config, forced_sources=None, *, force_refetch_gaps: bool = False):
    backtest_exchanges = require_config_value(config, "backtest.exchanges")
    exchanges_to_consider = [normalize_exchange_name(e) for e in backtest_exchanges]
    forced_sources = forced_sources or {}
    normalized_forced_sources = {
        str(coin): normalize_exchange_name(exchange)
        for coin, exchange in forced_sources.items()
        if exchange
    }

    requested_start_date = require_config_value(config, "backtest.start_date")
    requested_start_ts = int(date_to_ts(requested_start_date))
    end_date = format_end_date(require_config_value(config, "backtest.end_date"))
    end_ts = int(date_to_ts(end_date))

    warmup_minutes = compute_backtest_warmup_minutes(config)
    minute_ms = 60_000
    warmup_ms = warmup_minutes * minute_ms
    effective_start_ts = max(0, requested_start_ts - warmup_ms)
    effective_start_ts = (effective_start_ts // minute_ms) * minute_ms
    effective_start_date = ts_to_date(effective_start_ts)

    if warmup_minutes > 0:
        logging.info(
            f"combined applying warmup: {warmup_minutes} minutes -> fetch start {effective_start_date}, "
            f"requested start {requested_start_date}"
        )

    om_dict: Dict[str, HLCVManager] = {}
    for ex in exchanges_to_consider:
        om_dict[ex] = HLCVManager(
            ex,
            effective_start_date,
            end_date,
            gap_tolerance_ohlcvs_minutes=require_config_value(config, "backtest.gap_tolerance_ohlcvs_minutes"),
            cm_debug_level=int(config.get("backtest", {}).get("cm_debug_level", 0) or 0),
            cm_progress_log_interval_seconds=float(
                config.get("backtest", {}).get("cm_progress_log_interval_seconds", 10.0) or 10.0
            ),
            force_refetch_gaps=force_refetch_gaps,
        )
    extra_forced = set(normalized_forced_sources.values()) - set(exchanges_to_consider)
    for ex in extra_forced:
        om_dict[ex] = HLCVManager(
            ex,
            effective_start_date,
            end_date,
            gap_tolerance_ohlcvs_minutes=require_config_value(config, "backtest.gap_tolerance_ohlcvs_minutes"),
            cm_debug_level=int(config.get("backtest", {}).get("cm_debug_level", 0) or 0),
            cm_progress_log_interval_seconds=float(
                config.get("backtest", {}).get("cm_progress_log_interval_seconds", 10.0) or 10.0
            ),
            force_refetch_gaps=force_refetch_gaps,
        )
    btc_om: Optional[HLCVManager] = None

    try:
        mss, timestamps, unified_array = await _prepare_hlcvs_combined_impl(
            config,
            om_dict,
            effective_start_ts,
            requested_start_ts,
            end_ts,
            normalized_forced_sources,
        )

        btc_collateral_cap = float(config.get("backtest", {}).get("btc_collateral_cap", 0.0))
        if btc_collateral_cap > 0.0:
            btc_exchange = exchanges_to_consider[0] if len(exchanges_to_consider) == 1 else "binanceusdm"
            btc_om = HLCVManager(
                btc_exchange,
                effective_start_date,
                end_date,
                gap_tolerance_ohlcvs_minutes=require_config_value(config, "backtest.gap_tolerance_ohlcvs_minutes"),
            )
            # Align BTC date range to actual timestamps (mirrors single-exchange case)
            btc_om.update_date_range(int(timestamps[0]), int(timestamps[-1]))
            btc_df = await btc_om.get_ohlcvs("BTC")
            if btc_df.empty:
                raise ValueError(f"Failed to fetch BTC/USD prices from {btc_exchange}")
            btc_df = btc_df.set_index("timestamp").reindex(timestamps, method="ffill").ffill().bfill().reset_index()
            btc_usd_prices = btc_df["close"].values
        else:
            logging.info("BTC collateral disabled (cap=0); using dummy BTC prices")
            btc_usd_prices = np.ones(len(timestamps), dtype=np.float64)

        warmup_provided = max(0, int(max(0, requested_start_ts - int(timestamps[0])) // minute_ms))
        mss["__meta__"] = {
            "requested_start_ts": int(requested_start_ts),
            "requested_start_date": ts_to_date(requested_start_ts),
            "effective_start_ts": int(timestamps[0]),
            "effective_start_date": ts_to_date(int(timestamps[0])),
            "warmup_minutes_requested": int(warmup_minutes),
            "warmup_minutes_provided": int(warmup_provided),
        }

        return mss, timestamps, unified_array, btc_usd_prices
    finally:
        for om in om_dict.values():
            await om.aclose()
            if om.cc:
                await om.cc.close()
        if btc_om:
            await btc_om.aclose()
        if btc_om and btc_om.cc:
            await btc_om.cc.close()


async def _prepare_hlcvs_combined_impl(
    config,
    om_dict: Dict[str, HLCVManager],
    base_start_ts: int,
    _requested_start_ts: int,
    end_ts: int,
    forced_sources: Dict[str, str],
):
    approved = require_live_value(config, "approved_coins")
    coins = sorted(
        set(symbol_to_coin(c) for c in approved["long"]) | set(symbol_to_coin(c) for c in approved["short"])
    )
    exchanges_to_consider = sorted(list(om_dict.keys()))
    minimum_coin_age_days = float(require_live_value(config, "minimum_coin_age_days"))
    interval_ms = 60_000
    min_coin_age_ms = 1000 * 60 * 60 * 24 * minimum_coin_age_days

    first_timestamps_unified = await get_first_timestamps_unified(coins)

    per_coin_warmups = compute_per_coin_warmup_minutes(config)
    default_warm = int(per_coin_warmups.get("__default__", 0))

    chosen_data_per_coin = {}
    chosen_mss_per_coin = {}

    # Preload markets
    await asyncio.gather(*[om.load_markets() for om in om_dict.values()])

    progress = ProgressTracker(len(coins), "combined fetching candles")
    progress.maybe_log(force=True)

    # Async helper to process a single coin across all candidate exchanges
    async def process_coin(coin: str, sem: asyncio.Semaphore):
        """Fetch coin data from all candidate exchanges and select the best one."""
        async with sem:  # Rate limiting
            try:
                if coin not in first_timestamps_unified:
                    return None

                coin_fts = int(first_timestamps_unified[coin])
                effective_start_ts = max(int(base_start_ts), coin_fts + int(min_coin_age_ms))
                if effective_start_ts >= end_ts:
                    return None

                forced_exchange = forced_sources.get(coin)
                candidate_exchanges = [forced_exchange] if forced_exchange else exchanges_to_consider
                for ex in candidate_exchanges:
                    if ex not in om_dict:
                        raise ValueError(f"Unknown exchange '{ex}' requested for coin {coin}")

                # Fetch from all candidate exchanges in parallel
                tasks = []
                position_map = {ex0: (1 + i) for i, ex0 in enumerate(exchanges_to_consider)}
                for ex in candidate_exchanges:
                    tasks.append(
                        asyncio.create_task(
                            fetch_data_for_coin_and_exchange(
                                coin,
                                ex,
                                om_dict[ex],
                                effective_start_ts,
                                end_ts,
                                progress_position=position_map.get(ex, 1),
                            )
                        )
                    )
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # Filter successful results
                exchange_candidates = []
                for r in results:
                    if r is None or isinstance(r, Exception):
                        continue
                    ex, df, coverage_count, gap_count, total_volume = r
                    exchange_candidates.append((ex, df, coverage_count, gap_count, total_volume))

                if not exchange_candidates:
                    if forced_exchange:
                        raise ValueError(
                            f"No exchange data found for coin {coin} on forced exchange {forced_exchange}."
                        )
                    logging.info(f"No exchange data found at all for coin {coin}. Skipping.")
                    return None

                # Select best exchange
                if forced_exchange:
                    chosen = [c for c in exchange_candidates if c[0] == forced_exchange]
                    if not chosen:
                        raise ValueError(f"Forced exchange {forced_exchange} returned no usable data for coin {coin}.")
                    best_exchange, best_df, best_cov, best_gaps, best_vol = chosen[0]
                elif len(exchange_candidates) == 1:
                    best_exchange, best_df, best_cov, best_gaps, best_vol = exchange_candidates[0]
                else:
                    exchange_candidates.sort(key=lambda x: (x[2], -x[3], x[4]), reverse=True)
                    best_exchange, best_df, best_cov, best_gaps, best_vol = exchange_candidates[0]

                logging.info(f"{coin} exchange preference: {[x[0] for x in exchange_candidates]}")

                # Prepare market settings
                mss = om_dict[best_exchange].get_market_specific_settings(coin)
                mss["exchange"] = denormalize_exchange_name(best_exchange)
                warm_minutes = int(per_coin_warmups.get(coin, default_warm))
                mss["warmup_minutes"] = warm_minutes

                return (coin, best_df, mss)

            except Exception as e:
                logging.error(f"Error processing coin {coin}: {e}")
                traceback.print_exc()
                return None

    # Parallelize coin processing with rate limiting
    # Use semaphore of 6 to respect API rate limits across all exchanges
    COIN_CONCURRENCY = 6
    sem = asyncio.Semaphore(COIN_CONCURRENCY)

    tasks = [process_coin(coin, sem) for coin in coins]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    # Process results
    for result in results:
        progress.maybe_log()

        if result is None or isinstance(result, Exception):
            progress.update()
            continue

        coin, df, mss = result
        chosen_data_per_coin[coin] = df
        chosen_mss_per_coin[coin] = mss
        progress.update()

    progress.log_done()

    if not chosen_data_per_coin:
        raise ValueError("No coin data found on any exchange for the requested date range.")

    global_start_time = min(df.timestamp.iloc[0] for df in chosen_data_per_coin.values())
    global_end_time = max(df.timestamp.iloc[-1] for df in chosen_data_per_coin.values())

    timestamps = np.arange(global_start_time, global_end_time + interval_ms, interval_ms)
    n_timesteps = len(timestamps)
    valid_coins = sorted(chosen_data_per_coin.keys())
    n_coins = len(valid_coins)

    start_date_for_volume_ratios = ts_to_date(max(global_start_time, global_end_time - 1000 * 60 * 60 * 24 * 60))
    end_date_for_volume_ratios = ts_to_date(global_end_time)

    exchanges_with_data = sorted(set([chosen_mss_per_coin[coin]["exchange"] for coin in valid_coins]))
    exchange_volume_ratios = await compute_exchange_volume_ratios(
        exchanges_with_data,
        valid_coins,
        start_date_for_volume_ratios,
        end_date_for_volume_ratios,
        # om_dict keys are normalized (e.g. "binanceusdm"), but exchanges_with_data are denormalized
        {ex: om_dict[normalize_exchange_name(ex)] for ex in exchanges_with_data},
    )
    exchanges_counts = defaultdict(int)
    for coin in chosen_mss_per_coin:
        exchanges_counts[chosen_mss_per_coin[coin]["exchange"]] += 1
    reference_exchange = sorted(exchanges_counts.items(), key=lambda x: x[1])[-1][0]
    exchange_volume_ratios_mapped = defaultdict(dict)
    if len(exchanges_counts) == 1:
        exchange_volume_ratios_mapped[reference_exchange][reference_exchange] = 1.0
    else:
        for ex0, ex1 in exchange_volume_ratios:
            exchange_volume_ratios_mapped[ex0][ex1] = 1 / exchange_volume_ratios[(ex0, ex1)]
            exchange_volume_ratios_mapped[ex1][ex0] = exchange_volume_ratios[(ex0, ex1)]
            exchange_volume_ratios_mapped[ex1][ex1] = 1.0
            exchange_volume_ratios_mapped[ex0][ex0] = 1.0

    pprint.pprint(dict(exchange_volume_ratios_mapped))

    unified_array = np.full((n_timesteps, n_coins, 4), np.nan, dtype=np.float64)

    for i, coin in enumerate(valid_coins):
        df = chosen_data_per_coin[coin].copy()
        df = df.set_index("timestamp").reindex(timestamps)
        exchange_for_this_coin = chosen_mss_per_coin[coin]["exchange"]
        scaling_factor = exchange_volume_ratios_mapped[exchange_for_this_coin][reference_exchange]
        df["volume"] *= scaling_factor

        coin_data = df[["high", "low", "close", "volume"]].values
        unified_array[:, i, :] = coin_data
        start_idx = int((chosen_data_per_coin[coin].timestamp.iloc[0] - global_start_time) / interval_ms)
        end_idx = start_idx + len(chosen_data_per_coin[coin]) - 1
        chosen_mss_per_coin[coin]["first_valid_index"] = start_idx
        chosen_mss_per_coin[coin]["last_valid_index"] = end_idx
        first_idx = int(start_idx)
        last_idx = int(end_idx)
        warm_minutes = int(chosen_mss_per_coin[coin].get("warmup_minutes", 0))
        trade_start_idx = first_idx + warm_minutes
        if trade_start_idx > last_idx:
            trade_start_idx = last_idx
        chosen_mss_per_coin[coin]["trade_start_index"] = trade_start_idx

    return chosen_mss_per_coin, timestamps, unified_array


async def fetch_data_for_coin_and_exchange(
    coin: str,
    ex: str,
    om: HLCVManager,
    effective_start_ts: int,
    end_ts: int,
    *,
    progress_position: int = 1,
):
    t0 = time.monotonic()
    # Calculate approximate number of days for better visibility
    days_approx = max(1, (end_ts - effective_start_ts) // (24 * 60 * 60 * 1000))
    logging.info(
        "%s candles fetch start coin=%s range=%s..%s (~%d days)",
        ex,
        coin,
        ts_to_date(effective_start_ts),
        ts_to_date(end_ts),
        days_approx,
    )

    if not om.has_coin(coin):
        logging.info("%s candles fetch skip coin=%s reason=missing_market elapsed_s=%.1f", ex, coin, time.monotonic() - t0)
        return None
    om.update_date_range(effective_start_ts, end_ts)
    try:
        df = await om.get_ohlcvs(coin)
    except Exception as e:
        logging.warning(f"Error retrieving {coin} from {ex}: {e}")
        traceback.print_exc()
        logging.info(
            "%s candles fetch failed coin=%s elapsed_s=%.1f",
            ex,
            coin,
            time.monotonic() - t0,
        )
        return None
    if df.empty:
        logging.info(
            "%s candles fetch empty coin=%s elapsed_s=%.1f",
            ex,
            coin,
            time.monotonic() - t0,
        )
        return None
    df = df[(df.timestamp >= effective_start_ts) & (df.timestamp <= end_ts)].reset_index(drop=True)
    if df.empty:
        logging.info(
            "%s candles fetch empty_after_clip coin=%s elapsed_s=%.1f",
            ex,
            coin,
            time.monotonic() - t0,
        )
        return None
    coverage_count = len(df)
    intervals = np.diff(df["timestamp"].values)
    gap_count = sum((gap // 60_000) - 1 for gap in intervals if gap > 60_000)
    total_volume = df["volume"].sum()
    logging.info(
        "%s candles fetch ok coin=%s rows=%d gaps=%d elapsed_s=%.1f",
        ex,
        coin,
        coverage_count,
        gap_count,
        time.monotonic() - t0,
    )
    return (ex, df, coverage_count, gap_count, total_volume)


async def compute_exchange_volume_ratios(
    exchanges: List[str],
    coins: List[str],
    start_date: str,
    end_date: str,
    om_dict: Dict[str, HLCVManager] = None,
) -> Dict[Tuple[str, str], float]:
    if om_dict is None:
        om_dict = {ex: HLCVManager(ex, start_date, end_date) for ex in exchanges}
        await asyncio.gather(*[om_dict[ex].load_markets() for ex in om_dict])
    assert all([ex in om_dict for ex in exchanges])
    exchange_pairs = []
    for i, ex0 in enumerate(sorted(exchanges)):
        for ex1 in exchanges[i + 1 :]:
            exchange_pairs.append((ex0, ex1))

    all_data = {}

    for coin in coins:
        if not all(om_dict[ex].has_coin(coin) for ex in exchanges):
            continue

        tasks = []
        for ex in exchanges:
            om = om_dict[ex]
            om.update_date_range(start_date, end_date)
            tasks.append(om.get_ohlcvs(coin))

        dfs = await asyncio.gather(*tasks, return_exceptions=True)
        for i, df in enumerate(dfs):
            if isinstance(df, Exception) or df is None or df.empty:
                dfs[i] = pd.DataFrame()

        if any(df.empty for df in dfs):
            continue

        daily_volumes = []
        for df in dfs:
            df["day"] = df["timestamp"] // 86_400_000
            grouped = df.groupby("day", as_index=False)["volume"].sum()
            daily_dict = dict(zip(grouped["day"], grouped["volume"]))
            daily_volumes.append(daily_dict)

        sets_of_days = [set(dv.keys()) for dv in daily_volumes]
        common_days = set.intersection(*sets_of_days)
        if not common_days:
            continue

        coin_data = {}
        for ex0, ex1 in exchange_pairs:
            i0 = exchanges.index(ex0)
            i1 = exchanges.index(ex1)
            sum0 = sum(daily_volumes[i0][day] for day in common_days)
            sum1 = sum(daily_volumes[i1][day] for day in common_days)
            ratio = (sum0 / sum1) if sum1 > 0 else 0.0
            coin_data[(ex0, ex1)] = ratio

        if coin_data:
            all_data[coin] = coin_data

    averages = {}
    if not all_data:
        return averages

    used_pairs = set()
    for coin in all_data:
        for pair in all_data[coin]:
            used_pairs.add(pair)

    for pair in used_pairs:
        ratios_for_pair = []
        for coin in all_data:
            if pair in all_data[coin]:
                ratios_for_pair.append(all_data[coin][pair])
        averages[pair] = float(np.mean(ratios_for_pair)) if ratios_for_pair else 0.0

    return averages


__all__ = [
    "HLCVManager",
    "prepare_hlcvs",
    "prepare_hlcvs_combined",
    "compute_exchange_volume_ratios",
]
