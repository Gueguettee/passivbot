# Registers the SP500 live-run watchdog (src/tools/live_supervisor.py via watchdog_loop.ps1) as
# a Windows Scheduled Task so it starts at logon and survives terminal closes. Idempotent (/f).
#
#   powershell -ExecutionPolicy Bypass -File scripts\register_watchdog_task.ps1          # register
#   powershell -ExecutionPolicy Bypass -File scripts\register_watchdog_task.ps1 -Remove  # unregister
#
# Start it immediately after registering (or just log off/on):
#   schtasks /run /tn PassivbotSP500Watchdog
# Stop the loop + supervisor:
#   schtasks /end /tn PassivbotSP500Watchdog ; then stop the python pid in runs\sp500_live\supervisor.pid.txt

param([switch]$Remove)

$TaskName = "PassivbotSP500Watchdog"
$RepoRoot = Split-Path -Parent $PSScriptRoot
$Loop     = Join-Path $RepoRoot "scripts\watchdog_loop.ps1"

if ($Remove) {
    schtasks /delete /tn $TaskName /f
    exit $LASTEXITCODE
}

$Action = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Loop`""
schtasks /create /tn $TaskName /sc onlogon /rl LIMITED /f /tr $Action
if ($LASTEXITCODE -eq 0) {
    Write-Output "Registered '$TaskName' (runs at logon). Start now with: schtasks /run /tn $TaskName"
}
exit $LASTEXITCODE
