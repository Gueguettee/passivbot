# Watchdog runner loop for the SP500 live-run supervisor (src/tools/live_supervisor.py).
# Started by the "PassivbotSP500Watchdog" Scheduled Task (see register_watchdog_task.ps1) so it
# survives terminal closes -- the supervisor was killed twice by session events during the
# Jun 8-9 2026 run. Relaunches the supervisor if it ever exits, with a 30 s backoff.
#
# Run manually:  powershell -ExecutionPolicy Bypass -File scripts\watchdog_loop.ps1

$ErrorActionPreference = "Continue"
$RepoRoot = Split-Path -Parent $PSScriptRoot
$Python   = "C:\Users\david\miniconda3\envs\passivbot\python.exe"
$OutLog   = Join-Path $RepoRoot "runs\sp500_live\supervisor.out.log"
$ErrLog   = Join-Path $RepoRoot "runs\sp500_live\supervisor.err.log"
$PidFile  = Join-Path $RepoRoot "runs\sp500_live\supervisor.pid.txt"

New-Item -ItemType Directory -Force (Join-Path $RepoRoot "runs\sp500_live") | Out-Null

# Single-instance guard: if a previous supervisor is still alive, do nothing.
if (Test-Path $PidFile) {
    $oldPid = (Get-Content $PidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ($oldPid -and (Get-Process -Id $oldPid -ErrorAction SilentlyContinue)) {
        Write-Output "supervisor already running (pid $oldPid); exiting loop"
        exit 0
    }
}

while ($true) {
    $proc = Start-Process -FilePath $Python `
        -ArgumentList "src\tools\live_supervisor.py" `
        -WorkingDirectory $RepoRoot `
        -RedirectStandardOutput $OutLog `
        -RedirectStandardError $ErrLog `
        -WindowStyle Hidden -PassThru
    Set-Content -Path $PidFile -Value $proc.Id
    Wait-Process -Id $proc.Id -ErrorAction SilentlyContinue
    Add-Content -Path $ErrLog -Value "$(Get-Date -Format s) watchdog_loop: supervisor exited (pid $($proc.Id)); relaunching in 30s"
    Start-Sleep -Seconds 30
}
