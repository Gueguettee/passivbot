# Hydromancer Reservoir archive — data, sizes, and cost

Reference for the requester-pays S3 archive that `src/tools/hyperliquid_archive_downloader.py`
backfills from. Covers what the bucket actually contains (OHLCV **and** L2 orderbook),
measured sizes, the requester-pays $ model, and how to get **sub-1-minute** L2 (which
Reservoir does not provide).

All figures are **measured** from the `xyz` builder dex (Trade[XYZ] equity perps incl.
`xyz:SP500`, `xyz:NVDA`) unless labelled an estimate. Region is **ap-northeast-1 (Tokyo)**.

## Access — the requester-pays gotcha

Bucket `s3://hydromancer-reservoir`, region `ap-northeast-1`, **requester-pays**.
Credentials in `aws.env` (`PUBLIC_KEY` / `SECRET_KEY`) are **your own AWS account keys**
(requester-pays bills your account, not Hydromancer's). Which buckets they can reach is
governed by **your IAM policy** — initially it whitelisted only `hydromancer-reservoir`, so
the official `hyperliquid-archive` 403'd until that bucket's ARNs were added (see
"Getting sub-1-minute L2" below for the policy and access details).
If you received a deploy bundle, copy `aws.env.example` to `aws.env` and fill in your own
AWS keys locally. Never share the filled `aws.env` file.

> **Every** call must send the requester-pays flag — including `ListObjectsV2`, not just
> GET. boto3: `RequestPayer='requester'`; AWS CLI: `--request-payer requester`; DuckDB:
> `REQUESTER_PAYS true` in the secret. **Listing works** with the flag (an earlier note
> claiming "GetObject only, no ListBucket" was wrong — the list calls were just missing the
> header).

## Bucket structure (enumerated)

```
s3://hydromancer-reservoir/
├─ by_dex/
│  ├─ hyperliquid/        (main perp dex)
│  ├─ xyz/                (Trade[XYZ] HIP-3 equity perps)
│  │  ├─ candles/1s/date=YYYY-MM-DD/candles.parquet              ← OHLCV, whole-dex/day
│  │  ├─ orderbook/1m/perps/date=YYYY-MM-DD/{COIN}.parquet       ← L2 book, per-coin/day
│  │  ├─ fills/perp/{adl,all,builder_fills,liquidations}/…       ← trade/liq/ADL fills
│  │  └─ snapshots/perp/date=YYYY-MM-DD/{snap}.parquet           ← daily account snapshots (~24 KB)
│  └─ cash/ flx/ hyna/ km/ para/ vntl/   (other HIP-3 deployers)
├─ global/
└─ _pre_hip4_unification_backup/
```

Coin in the **L2 path** is bare (`SP500.parquet`, `NVDA.parquet`); in the candles `coin`
*column* it is namespaced (`xyz:SP500`).

## OHLCV candles (`candles/1s/`)

| Item | Value |
|---|---|
| Layout | `by_dex/{dex}/candles/1s/date=YYYY-MM-DD/candles.parquet` (one file/day, **all coins**) |
| Whole-`xyz`-dex 1s file (2026-03-18) | **9.3 MB/day** |
| Local per-coin 1s extract | NVDA ~0.38 MB/day, SP500 ~0.63 MB/day |
| Local per-coin 1m `.npy` | ~40 KB/day |
| Bucket coverage | **2025-10-13 → 2026-06-07** (238 days; from HIP-3 mainnet launch) |
| Per-coin start | a coin only has rows once listed: NVDA ~2025-12-15, **SP500 ~2026-03-18** |
| Local cache | from **2026-03-18** only (the downloader's default `EARLIEST_DATE`, not a bucket limit) |
| Columns | `open, high, low, close, volume, volume_quote, trade_count` (candles, **not** L2) |

## L2 orderbook (`orderbook/1m/`) — CONFIRMED

- **Layout:** `by_dex/{dex}/orderbook/1m/perps/date=YYYY-MM-DD/{COIN}.parquet` (one file
  **per coin per day**).
- **Cadence: 1 minute** (measured modal gap 60.01 s; ~1,429 rows/day). **This is the floor —
  Reservoir has no finer L2 tier.**
- **Depth:** up to **20 levels per side** (fewer when the book is thin).
- **Schema:**
  ```
  block_time_ms : int64
  block_number  : uint64
  bids          : list<struct<px:string, sz:string, n:uint32>>   # n = orders at that level
  asks          : list<struct<px:string, sz:string, n:uint32>>
  ```

Measured sizes (xyz dex):

| Coin | day-files | range | total | avg/day |
|---|---|---|---|---|
| NVDA | 175 | 2025-12-15 → 2026-06-07 | **43.3 MB** | ~242 KB |
| SP500 | 82 | (starts ~2026-03-18) | **19.2 MB** | ~228 KB |
| **SP500 + NVDA** | — | full available | **62.5 MB** | — |
| Whole xyz dex (71 coins) | 7,151 | 2025-12-15 → 2026-06-07 | **1.38 GB** | ~7.9 MB |

Per-coin L2 starts when the coin is listed (NVDA 2025-12-15; SP500 ~2026-03-18) — independent
of the local OHLCV cache start. Because L2 is 1-min while candles are 1-s, **per-coin L2 is
~0.5× the size of the 1s OHLCV**, not larger.

## Getting sub-1-minute L2 (not in Reservoir)

1. **Official Hyperliquid archive** (`s3://hyperliquid-archive`, region **us-east-1**) — raw
   snapshots, **on every block, ≥0.5 s apart**, LZ4-NDJSON, uploaded ~monthly:
   ```
   aws s3 cp s3://hyperliquid-archive/market_data/YYYYMMDD/H/l2Book/COIN.lz4 . --request-payer requester
   lz4 -d COIN.lz4 COIN          # Windows/conda: `lz4 -d`, not the docs' `unlz4`
   ```
   Path: `market_data/[YYYYMMDD]/[hour 0-23]/l2Book/[coin].lz4` (+ `asset_ctxs/[date].csv.lz4`).
   Coverage 2023-04-15 → ~1 week behind today. Add these ARNs to your IAM policy to reach it:
   ```json
   { "Effect":"Allow", "Action":["s3:ListBucket","s3:GetBucketLocation"],
     "Resource":"arn:aws:s3:::hyperliquid-archive" },
   { "Effect":"Allow", "Action":["s3:GetObject"], "Resource":"arn:aws:s3:::hyperliquid-archive/*" }
   ```
   **VERIFIED (2026-06-08): this archive does NOT cover HIP-3 builder dexes.** Its path has no
   dex dimension; `l2Book` holds only the **main perp dex** (~190 coins — BTC/ETH/SOL/HYPE/…),
   with **no `xyz:` / `SP500` / `NVDA`**. So it is **useless for `xyz:SP500`** — use option 2.
2. **Live WebSocket `l2Book`** — forward-only, full resolution, you record it:
   ```json
   {"method":"subscribe","subscription":{"type":"l2Book","coin":"xyz:SP500","nSigFigs":5,"nLevels":20}}
   ```
   `nLevels` up to 100; snapshots push per block (≥0.5 s). No backfill. **Most practical route
   for sub-1m `xyz:SP500`.**
3. **Raw node data** `s3://hl-mainnet-node-data` (region **ap-northeast-1**, requester-pays) —
   on-chain source of truth, **so it DOES contain HIP-3** (verified: `xyz:SP500`, `xyz:NVDA`,
   plus `cash:`/`flx:`/`hyna:` dexes) at **per-block resolution (~0.07 s)**, current to today.
   IAM: add `arn:aws:s3:::hl-mainnet-node-data` (+`/*`) like the archive above. Streams:
   - `node_fills_by_block/hourly/YYYYMMDD/{H}.lz4` — fills (not the book), **~1 GB/day**
     compressed, whole-chain (filter `xyz:SP500` locally). `node_trades` is a dead format
     (stopped 2025-06) — ignore it.
   - `replica_cmds/{run}/YYYYMMDD/{blockrange}.lz4` — raw order/cancel command stream; replay
     it to reconstruct a full L2 book at any cadence. But it's the **whole-chain firehose
     ~240 GB/day compressed** (TB decompressed, ≈$27/day egress) and needs a reconstruction
     engine. Only do this if 1-min (Reservoir) and forward-only (WS) are both insufficient.
4. **Third-party** (0xArchive advertises granular replayable HIP-3 history + parquet export —
   paid, unverified; Tardis.dev/Dwellir largely sync the main-dex archive so likely inherit the
   HIP-3 gap; L1ticks is on-chain-focused). None confirmed for `xyz:SP500` L2.

## Cost (requester-pays)

Requester pays per-request + data-transfer-out. Region figures **approximate, ap-northeast-1,
~2026 — verify on the AWS Pricing Calculator** (corroborated by this repo's real anchor: a
5-month single-coin OHLCV backfill ran ~$0.10–0.20):

- **GET / LIST:** ~$0.0004 per 1,000 requests.
- **Egress to internet:** ~**$0.114 / GB** (us-east-1 is $0.09); first **100 GB/month free**
  (account-wide); **$0** if you pull to compute inside `ap-northeast-1`.
- **Storage: $0 to us** (bucket owner pays).

Real costs (download to internet, upper bound — ignores the free tier):

| Dataset | data | egress $ |
|---|---|---|
| L2 — SP500 + NVDA, **full history** (62.5 MB) | 0.06 GB | **~$0.007** |
| L2 — SP500 + NVDA, **1 month** (~14 MB) | 0.014 GB | **~$0.002** |
| L2 — **whole xyz dex**, full history (1.38 GB) | 1.38 GB | **~$0.16** |
| OHLCV — both coins, 1 month | ~0.3 GB | **~$0.03** |

**Takeaway:** S3 $ cost is trivial (cents, usually $0 under the free egress tier) for both
OHLCV and Reservoir's 1-min L2. The only real constraint is **resolution**: 1-minute is the
floor in Reservoir; finer L2 means the official archive (own creds, HIP-3 unverified) or
self-capturing the live WebSocket.

---
*Generated 2026-06-08. Sizes measured via the `aws.env` keys against `s3://hydromancer-reservoir`
(`by_dex/xyz/`). Official `hyperliquid-archive` access + HIP-3 absence verified 2026-06-08
(main-dex only; no `xyz:` coins). Sub-1m L2 for HIP-3 markets = live `l2Book` WS capture only.*
