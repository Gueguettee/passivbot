#!/usr/bin/env python3
"""
Create a deployment ZIP bundle of the passivbot_sp500 project — safe by construction,
so it never leaks private credentials.

What it does
------------
1. Walks the repo from this script's directory.
2. Skips junk/output dirs (.git, caches, backtests, runs, __pycache__, ...) and — most
   importantly — SECRET files (aws.env, api-keys.json, .env, *.pem, *.key, ...).
3. As defense-in-depth, re-scans every file that WOULD be included — by name AND by
   content — for secret signatures (AWS keys, PEM private keys, 0x… 64-hex agent keys,
   SECRET_KEY= values) and ABORTS if anything suspicious is found (override with --force).
4. Writes a single .zip with everything rooted under a top-level "passivbot_sp500/" dir.

Usage
-----
    python make_deploy_bundle.py                 # code + configs + 1m candles -> dist/<...>.zip
    python make_deploy_bundle.py --code-only     # code + configs + credential templates, no data
    python make_deploy_bundle.py --dry-run       # list what would be included, write nothing
    python make_deploy_bundle.py --include-1s    # also include the raw 1s data (large)
    python make_deploy_bundle.py --no-1m         # code + configs only (no candle data)
    python make_deploy_bundle.py -o my_bundle.zip

Data policy: the 1m candles (caches/ohlcv/**/1m/**) ARE bundled by default so the target can
backtest immediately, but ONLY for SP500 (use --coins to change, --coins all for everything).
The bulky raw 1s data (caches/ohlcv/**/1s/**) and the rebuildable prepared cache
(caches/hlcvs_data/) are left OUT unless you pass --include-1s / --include-cache.
"""
from __future__ import annotations

import argparse
import fnmatch
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
BUNDLE_PREFIX = "passivbot_sp500"  # top-level dir inside the zip

# --- directories never bundled (matched by exact dir name, anywhere in the tree) ---
EXCLUDE_DIR_NAMES = {
    ".git", ".github", ".hg", ".svn",
    ".claude",
    "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".cache",
    ".idea", ".vscode",
    "node_modules",
    ".venv", "venv",                  # python virtualenvs
    "target",                         # rust build output
    "backtests", "runs",              # run output (re-creatable, can be huge)
    "dist", "build", "deploy_bundle", # packaging output (also avoids zipping our own output)
    "htmlcov", ".tox",
}

# --- path prefixes never bundled, relative to repo root ---
EXCLUDE_PATH_PREFIXES = {
    ("l2_collector", "data"),  # local recorder output; keep collector code, not recorded data
}

# --- files never bundled: exact names that are secrets/credentials ---
SECRET_FILE_NAMES = {
    "aws.env",
    "api-keys.json",
    ".env",
    ".netrc", ".npmrc", ".pypirc",
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
    "credentials", "secrets.json", "secret.json",
}

# --- files never bundled: glob patterns ---
SECRET_GLOBS = [
    "*.pem", "*.key", "*.p12", "*.pfx", "*.keystore", "*.jks", "*.ppk",
    "*.env", ".env.*", "*_rsa", "*_dsa", "id_rsa*", "aws.env.*",
]
JUNK_GLOBS = [
    "*.pyc", "*.pyo", "*.swp", "*.bak", "*.orig",
    "*.log", "*.tmp", "*.temp",
    "*.zip", "*.tar", "*.tar.gz", "*.tgz", "*.7z", "*.rar",
    "*.pyd", "*.so", "*.dll", "*.dylib", "*.exe",
    ".DS_Store", "Thumbs.db",
]

# Explicit keepers: safe files that might otherwise look excludable.
ALWAYS_KEEP_NAMES = {"api-keys.json.example", "aws.env.example", ".gitignore", ".dockerignore"}

# --- content scan: high-confidence secret signatures -> ABORT ---
# Patterns are written so they do NOT match their own definitions in this file or the
# placeholder examples in the docs (verified against README/QUICKSTART/api-keys.json.example).
SECRET_CONTENT_PATTERNS = [
    ("AWS access key id", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("PEM private key", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----")),
    ("hex private key (0x… 64 hex)", re.compile(r'"private_key"\s*:\s*"(?:0x)?[0-9a-fA-F]{64}"')),
    ("aws secret access key", re.compile(r'(?i)aws_secret_access_key\s*[=:]\s*["\']?[A-Za-z0-9/+]{40}')),
    ("SECRET_KEY= value", re.compile(r'(?m)^\s*SECRET_KEY\s*=\s*["\']?[A-Za-z0-9/+]{20,}')),
]

# Only scan textual files for content secrets (skip real binaries).
TEXT_SUFFIXES = {
    ".py", ".json", ".jsonc", ".txt", ".md", ".yml", ".yaml", ".toml", ".ini", ".cfg",
    ".sh", ".bash", ".ps1", ".env", ".rs", ".js", ".ts", ".html", ".css", ".csv",
    ".example", "",
}
MAX_SCAN_BYTES = 2_000_000  # cap per-file read for the content scan


def is_excluded_file(rel: Path) -> str | None:
    """Return a reason string if this file must be excluded, else None."""
    name = rel.name
    if name in ALWAYS_KEEP_NAMES:
        return None
    if name in SECRET_FILE_NAMES:
        return "secret: name"
    for pat in SECRET_GLOBS:
        if fnmatch.fnmatch(name, pat):
            return f"secret: {pat}"
    for pat in JUNK_GLOBS:
        if fnmatch.fnmatch(name, pat):
            return f"junk: {pat}"
    return None


def _coin_allowed(parts: tuple[str, ...], tf: str, coins: set[str] | None) -> bool:
    """Is the coin segment (the path part right after the timeframe dir) in `coins`?
    `coins=None` means no restriction."""
    if coins is None:
        return True
    try:
        coin = parts[parts.index(tf) + 1]
    except (ValueError, IndexError):
        return True  # unfamiliar layout -> don't silently drop
    return coin in coins


def cache_file_keep(rel: Path, include_1m: bool, include_1s: bool, include_cache: bool,
                    coins: set[str] | None) -> bool:
    """Decide whether a file under caches/ is bundled.

    Only candle data for `coins` (None = all) ships; 1m ships by default, while the bulky raw
    1s data and the (rebuildable) prepared hlcvs_data cache are opt-in.
    """
    parts = rel.parts
    if "1s" in parts:
        return include_1s and _coin_allowed(parts, "1s", coins)
    if "1m" in parts:
        return include_1m and _coin_allowed(parts, "1m", coins)
    return include_cache  # e.g. caches/hlcvs_data/<hash>/... (derived; rebuilt from 1m)


def is_excluded_path(rel: Path) -> bool:
    parts = rel.parts
    return any(tuple(parts[:len(prefix)]) == prefix for prefix in EXCLUDE_PATH_PREFIXES)


def collect_files(include_1m: bool, include_1s: bool, include_cache: bool, include_backtests: bool,
                  coins: set[str] | None):
    included: list[Path] = []
    excluded_secrets: list[tuple[Path, str]] = []
    exclude_dirs = set(EXCLUDE_DIR_NAMES)
    if include_backtests:
        exclude_dirs.discard("backtests")

    for path in sorted(REPO_ROOT.rglob("*")):
        if not path.is_file() and not path.is_symlink():
            continue
        rel = path.relative_to(REPO_ROOT)
        if any(part in exclude_dirs for part in rel.parts[:-1]):
            continue
        if is_excluded_path(rel):
            continue
        # caches/ is handled by content type: 1m in by default, 1s/prepared-cache opt-in,
        # and candle data is restricted to the requested coins.
        if rel.parts and rel.parts[0] == "caches":
            if not cache_file_keep(rel, include_1m, include_1s, include_cache, coins):
                continue
        reason = is_excluded_file(rel)
        if reason:
            if reason.startswith("secret"):
                excluded_secrets.append((rel, reason))
            continue
        included.append(rel)
    return included, excluded_secrets


def scan_for_secrets(files: list[Path]):
    findings: list[tuple[Path, str]] = []
    for rel in files:
        if rel.suffix.lower() not in TEXT_SUFFIXES:
            continue
        try:
            data = (REPO_ROOT / rel).read_bytes()[:MAX_SCAN_BYTES]
        except OSError:
            continue
        text = data.decode("utf-8", errors="ignore")
        for label, pat in SECRET_CONTENT_PATTERNS:
            if pat.search(text):
                findings.append((rel, label))
    return findings


def human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f}{unit}"
        n /= 1024
    return f"{n:.1f}TB"


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a secret-free deployment zip bundle.")
    ap.add_argument("-o", "--output", type=Path, default=None, help="Output .zip path.")
    ap.add_argument("--code-only", action="store_true",
                    help="Shortcut for a shareable code/config bundle: exclude all candle/cache data.")
    ap.add_argument("--no-1m", action="store_true", help="Exclude the 1m candles (default: included).")
    ap.add_argument("--include-1s", action="store_true",
                    help="Include raw 1s data caches/ohlcv/**/1s/** (default: excluded; large).")
    ap.add_argument("--include-cache", action="store_true",
                    help="Include the prepared caches/hlcvs_data/ cache (default: excluded; rebuilt from 1m).")
    ap.add_argument("--include-backtests", action="store_true", help="Also include backtests/.")
    ap.add_argument("--coins", default="SP500",
                    help="Comma-separated coins whose candle data to bundle (default: SP500). "
                         "Use 'all' for every coin found in caches/.")
    ap.add_argument("--dry-run", action="store_true", help="List files; write nothing.")
    ap.add_argument("--force", action="store_true",
                    help="Proceed even if the content scan flags suspected secrets (NOT recommended).")
    args = ap.parse_args()
    if args.code_only and (args.include_1s or args.include_cache):
        ap.error("--code-only cannot be combined with --include-1s or --include-cache")

    coins: set[str] | None
    if args.coins.strip().lower() in ("all", "*", ""):
        coins = None
    else:
        coins = {c.strip() for c in args.coins.split(",") if c.strip()}

    include_1m = False if args.code_only else not args.no_1m
    include_1s = False if args.code_only else args.include_1s
    include_cache = False if args.code_only else args.include_cache

    files, excluded_secrets = collect_files(
        include_1m=include_1m,
        include_1s=include_1s,
        include_cache=include_cache,
        include_backtests=args.include_backtests,
        coins=coins,
    )
    if not files:
        print("No files to bundle?! Aborting.", file=sys.stderr)
        return 2

    findings = scan_for_secrets(files)

    total = sum((REPO_ROOT / r).stat().st_size for r in files)
    n_1m = sum(1 for r in files if r.parts and r.parts[0] == "caches" and "1m" in r.parts)
    print(f"Repo:             {REPO_ROOT}")
    print(f"Files to include: {len(files)} ({human(total)})")
    print(f"Data coins:       {'ALL' if coins is None else ', '.join(sorted(coins))}")
    print(f"Data:             1m candles {'INCLUDED' if include_1m else 'excluded'} ({n_1m} files)"
          f" | 1s raw {'INCLUDED' if include_1s else 'excluded'}"
          f" | prepared cache {'INCLUDED' if include_cache else 'excluded'}")
    if excluded_secrets:
        print(f"\nDeliberately EXCLUDED {len(excluded_secrets)} credential/secret file(s):")
        for rel, why in excluded_secrets:
            print(f"  - {rel.as_posix()}  [{why}]")

    if findings:
        print(f"\n*** CONTENT SCAN: {len(findings)} suspected secret(s) in files that WOULD be bundled ***",
              file=sys.stderr)
        for rel, label in findings:
            print(f"  ! {rel.as_posix()}  ->  {label}", file=sys.stderr)
        if not args.force:
            print("\nAborting to avoid leaking secrets. Remove the secrets from those files, or re-run\n"
                  "with --force if these are confirmed false positives (e.g. placeholders).",
                  file=sys.stderr)
            return 1
        print("\n--force given: continuing despite the findings above.", file=sys.stderr)

    if args.dry_run:
        print("\n--dry-run: writing no archive. Files that would be included:")
        for rel in files:
            print(f"  {rel.as_posix()}")
        return 0

    out = args.output
    if out is None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        out = REPO_ROOT / "dist" / f"{BUNDLE_PREFIX}_deploy_{stamp}.zip"
    out = out.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for rel in files:
            zf.write(REPO_ROOT / rel, f"{BUNDLE_PREFIX}/{rel.as_posix()}")

    print(f"\nWrote {out}")
    print(f"  {human(out.stat().st_size)}, {len(files)} files, extracts to '{BUNDLE_PREFIX}/'.")
    print("Reminder: aws.env / api-keys.json are NOT in the bundle — create them on the target host.")
    print("Recipient setup: open DEPLOY_BUNDLE_README.md, then copy api-keys.json.example to api-keys.json.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
