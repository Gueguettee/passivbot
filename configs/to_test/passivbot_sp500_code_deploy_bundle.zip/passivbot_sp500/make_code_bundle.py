#!/usr/bin/env python3
"""
Generate a Markdown bundle containing the repository's Python and Rust source.

Usage
-----
    python make_code_bundle.py
    python make_code_bundle.py -o dist/source_code_bundle.md
    python make_code_bundle.py --exclude-tests
    python make_code_bundle.py --tracked-only
    python make_code_bundle.py --suffix .py --suffix .rs
    python make_code_bundle.py --dry-run

The default output is dist/source_code_bundle.md. Generated data, build products,
virtualenvs, caches, and VCS metadata are skipped.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
DEFAULT_OUTPUT = Path("dist/source_code_bundle.md")
DEFAULT_SUFFIXES = {".py", ".rs"}
LANG_BY_SUFFIX = {
    ".py": "python",
    ".rs": "rust",
}

EXCLUDE_DIR_NAMES = {
    ".cache",
    ".claude",
    ".eggs",
    ".git",
    ".github",
    ".hg",
    ".idea",
    ".mypy_cache",
    ".nox",
    ".pytest_cache",
    ".ruff_cache",
    ".svn",
    ".tox",
    ".venv",
    ".vscode",
    ".worktrees",
    "__pycache__",
    "backtests",
    "build",
    "caches",
    "debug",
    "dist",
    "downloads",
    "eggs",
    "env",
    "ENV",
    "historical_data",
    "htmlcov",
    "lib",
    "Lib",
    "lib64",
    "node_modules",
    "optimize_results",
    "reports",
    "runs",
    "target",
    "venv",
}


def parse_suffixes(values: list[str] | None) -> set[str]:
    if not values:
        return set(DEFAULT_SUFFIXES)

    suffixes: set[str] = set()
    for value in values:
        for raw in value.split(","):
            suffix = raw.strip().lower()
            if not suffix:
                continue
            if not suffix.startswith("."):
                suffix = f".{suffix}"
            suffixes.add(suffix)
    if not suffixes:
        raise ValueError("at least one suffix is required")
    return suffixes


def resolve_output(path: Path, root: Path) -> Path:
    if path.is_absolute():
        return path
    return root / path


def rel_posix(path: Path) -> str:
    return path.as_posix()


def is_excluded(rel: Path, exclude_tests: bool) -> bool:
    if any(part in EXCLUDE_DIR_NAMES for part in rel.parts[:-1]):
        return True
    if not exclude_tests:
        return False

    if rel.parts and rel.parts[0] == "tests":
        return True
    name = rel.name.lower()
    return name.startswith("test_") or name.endswith("_test.py")


def git_tracked_paths(root: Path) -> set[Path] | None:
    try:
        proc = subprocess.run(
            ["git", "ls-files", "-z"],
            cwd=root,
            capture_output=True,
            check=False,
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None

    paths = proc.stdout.decode("utf-8", errors="replace").split("\0")
    return {Path(path) for path in paths if path}


def collect_source_files(
    root: Path,
    suffixes: set[str],
    exclude_tests: bool,
    tracked_paths: set[Path] | None = None,
) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(root)
        if tracked_paths is not None and rel not in tracked_paths:
            continue
        if is_excluded(rel, exclude_tests):
            continue
        if path.suffix.lower() not in suffixes:
            continue
        files.append(rel)
    return sorted(files, key=lambda item: item.as_posix().lower())


def read_source(path: Path) -> str:
    text = path.read_bytes().decode("utf-8-sig", errors="replace")
    return text.replace("\r\n", "\n").replace("\r", "\n")


def fence_for(text: str) -> str:
    longest = max((len(match.group(0)) for match in re.finditer(r"`+", text)), default=0)
    return "`" * max(3, longest + 1)


def human_bytes(n: int) -> str:
    value = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if value < 1024:
            return f"{value:.1f}{unit}"
        value /= 1024
    return f"{value:.1f}TB"


def git_output(root: Path, args: list[str]) -> str | None:
    try:
        proc = subprocess.run(
            ["git", *args],
            cwd=root,
            capture_output=True,
            check=False,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    return proc.stdout.strip()


def build_markdown(root: Path, files: list[Path], suffixes: set[str]) -> str:
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    total_bytes = sum((root / rel).stat().st_size for rel in files)
    head = git_output(root, ["rev-parse", "--short", "HEAD"])
    branch = git_output(root, ["branch", "--show-current"])
    status = git_output(root, ["status", "--short"])

    lines: list[str] = [
        "# Source Code Bundle",
        "",
        f"- Generated: {generated_at}",
        f"- Root: `{root}`",
        f"- Files: {len(files)}",
        f"- Size: {human_bytes(total_bytes)}",
        f"- Suffixes: `{', '.join(sorted(suffixes))}`",
    ]
    if head:
        git_label = head if not branch else f"{branch} @ {head}"
        lines.append(f"- Git: `{git_label}`")
    if status:
        dirty_count = len(status.splitlines())
        lines.append(f"- Working tree status: `{dirty_count} changed/untracked path(s)`")

    lines.extend(["", "## File Index", ""])
    for rel in files:
        size = (root / rel).stat().st_size
        lines.append(f"- `{rel_posix(rel)}` ({human_bytes(size)})")

    lines.extend(["", "---", ""])
    for rel in files:
        text = read_source(root / rel)
        suffix = rel.suffix.lower()
        language = LANG_BY_SUFFIX.get(suffix, suffix.lstrip("."))
        fence = fence_for(text)
        lines.extend([
            f"## `{rel_posix(rel)}`",
            "",
            f"{fence}{language}",
            text.rstrip("\n"),
            fence,
            "",
        ])

    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Bundle Python and Rust source files into one Markdown file.",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=DEFAULT_OUTPUT,
        help=f"Output .md path. Default: {DEFAULT_OUTPUT.as_posix()}",
    )
    parser.add_argument(
        "--root",
        type=Path,
        default=REPO_ROOT,
        help="Repository/source root to scan. Default: directory containing this script.",
    )
    parser.add_argument(
        "--suffix",
        action="append",
        help="Source suffix to include. Can be repeated or comma-separated. Default: .py,.rs",
    )
    parser.add_argument(
        "--exclude-tests",
        action="store_true",
        help="Skip tests/ and test_*.py files.",
    )
    parser.add_argument(
        "--tracked-only",
        action="store_true",
        help="Only bundle files known to git ls-files.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the files that would be bundled without writing Markdown.",
    )
    args = parser.parse_args()

    root = args.root.resolve()
    if not root.exists() or not root.is_dir():
        print(f"Root is not a directory: {root}", file=sys.stderr)
        return 2

    try:
        suffixes = parse_suffixes(args.suffix)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    tracked_paths = git_tracked_paths(root) if args.tracked_only else None
    if args.tracked_only and tracked_paths is None:
        print("Could not read tracked files from git.", file=sys.stderr)
        return 2

    files = collect_source_files(root, suffixes, args.exclude_tests, tracked_paths)
    if not files:
        print("No matching source files found.", file=sys.stderr)
        return 1

    if args.dry_run:
        for rel in files:
            print(rel_posix(rel))
        print(f"\n{len(files)} file(s) would be bundled.")
        return 0

    output = resolve_output(args.output, root).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(build_markdown(root, files, suffixes), encoding="utf-8", newline="\n")
    print(f"Wrote {output}")
    print(f"Bundled {len(files)} file(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
