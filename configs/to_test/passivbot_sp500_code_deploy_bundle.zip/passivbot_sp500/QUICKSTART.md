# passivbot_sp500 — S&P 500 on Hyperliquid — Quickstart

A slimmed passivbot set up to **backtest, optimize, and live-trade the S&P 500-USDC
perpetual on Hyperliquid** as a **single always-on asset**, long-only pure-grid strategy.

- **Main exchange: Hyperliquid.** The asset is **`xyz:SP500`** — the S&P 500-USDC perp on the
  **Trade[XYZ]** HIP-3 builder-deployed perp dex (listed 2026-03-18). In configs the coin token is
  just **`SP500`** (it maps to the Hyperliquid asset `xyz:SP500`).
- **Isolated margin only.** Hyperliquid HIP-3 dexes are isolated-margin; the live bot sets leverage
  with `is_cross=False`. Never cross.
- **Single asset, enforced.** The bot **refuses to start with a config that resolves to more than one
  coin** (backtest or live, any exchange). See `_enforce_single_asset` in `src/config_utils.py`.
- **Lighter is kept** but is no longer the default — use `configs/config_sp500_lighter.json` for it.
- **`configs/config_sp500.json` is the default config everywhere** — a bare `python src/passivbot.py`
  (native conda) or `docker compose run --rm passivbot src/passivbot.py` (docker) uses it with no args.
- **Live trading is implemented and validated** — both the order primitives and the full live-trading
  **engine loop** were exercised against the funded subaccount on real money (see §5).

---

## 1. Prerequisites & environments

Python **3.10**. Runs three ways off the **same `configs/` + `caches/`**:

| Where | How | Rust extension |
|-------|-----|----------------|
| **Windows (dev/test)** | `conda env create -f environment.yml` (py3.10) | full repo only: prebuilt `src/passivbot_rust.cp310-win_amd64.pyd` works as-is; code-only zips exclude compiled binaries |
| **Ubuntu VPS (deploy)** | `conda env create -f environment.yml`, then build the ext (below) | build once via `bash rustbuild.sh` |
| **Docker (deploy)** | `docker compose build` then `docker compose run --rm passivbot` | built automatically in the image |

**Build the Rust extension (Linux/macOS, or any non-3.10 Python):**
```bash
# install rust if needed: curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
pip install -r requirements-rust.txt   # maturin
bash rustbuild.sh                       # produces src/passivbot_rust*.so
```

Install Python deps (native conda/venv):
```bash
pip install -r requirements.txt
```

### Share or deploy a secret-free zip

Use the existing bundle script when sending this project to someone else or moving it
to a VPS:

```bash
python make_deploy_bundle.py --code-only -o dist/passivbot_sp500_code_deploy_bundle.zip
```

The bundle includes code, configs, docs, and credential templates. It excludes local
credentials (`api-keys.json`, `aws.env`, `.env`, private-key files), generated data/results
(`caches/`, `backtests/`, `runs/`, `l2_collector/data/`), and compiled native artifacts
(`*.pyd`, `*.so`, `*.dll`, etc.). Docker is the recommended deploy path for this bundle
because the image builds the Rust extension itself.

Recipients should unzip it, read `DEPLOY_BUNDLE_README.md`, then create their own local
credential files from the templates:

```bash
cp api-keys.json.example api-keys.json
# optional paid S3 history only:
cp aws.env.example aws.env
```

---

## 2. Get the data

The backtest needs 1-minute candles under `caches/ohlcv/hyperliquid/1m/SP500/` (daily `.npy` files).

**By default the backtest pulls data only from the free public API.** The paid Reservoir **S3 archive is
never used unless you explicitly opt in** — it is requester-pays, so it costs money. Whenever a run needs
older candles the free API cannot reach, it **prints a warning naming the exact missing days and the
command to backfill only those days**; you run that S3 step yourself, only when you choose to.

All loaded candles are automatically **deduplicated and quality-checked** on every run — duplicate
timestamps and invalid rows (non-finite values, non-positive close, `high < low`) are dropped, and any
remaining gaps are filled from the previous close.

### A. Default — free public API (no credentials, recent only)
Hyperliquid's public `candleSnapshot` API keeps only the most recent **~5000 1m candles (~3.4 days)**.
This is what the backtest auto-uses on first run; nothing to configure. To run it manually:
```bash
SYMBOLS=SP500 RUN_ONCE=1 EARLIEST_DATE=2026-03-18 PYTHONPATH=src python src/tools/hyperliquid_ohlcv_collector.py
```
To build a continuous 1m record over time, run the always-on collector (section C).

### B. Full history — Hydromancer Reservoir S3 (opt-in, costs money)
For history older than ~3.4 days we pull **1-second** candles from the Hydromancer Reservoir
**requester-pays S3** bucket and aggregate to 1m. **This is opt-in because it costs money** — it needs
AWS credentials *and* an explicit opt-in.

Put your AWS keys in **`aws.env`** in the repo root (gitignored). If you received a
deploy bundle, start from the included template:
```bash
cp aws.env.example aws.env
```
Then edit it:
```
PUBLIC_KEY=your_aws_access_key_id
SECRET_KEY=your_aws_secret_access_key
```

**Recommended workflow — backfill only the holes a backtest reports.** Run a backtest; if it warns about
gaps the free API can't fill, it prints the exact command. Run that to fetch *only the missing days* (it
skips days already on disk), e.g.:
```bash
SYMBOLS=SP500 EARLIEST_DATE=2026-02-26 END_DATE=2026-03-17 PYTHONPATH=src python src/tools/hyperliquid_archive_downloader.py
```
```powershell
$env:SYMBOLS="SP500"; $env:EARLIEST_DATE="2026-02-26"; $env:END_DATE="2026-03-17"; $env:PYTHONPATH="src"
python src\tools\hyperliquid_archive_downloader.py
```

To instead let **backtests auto-use** the archive (fetch missing history automatically), opt in with the
env var (or set `backtest.use_reservoir_archive: true` in the config):
```bash
HL_USE_RESERVOIR_ARCHIVE=1 PYTHONPATH=src python src/backtest.py configs/config_sp500.json --disable_plotting --skip-rust-compile
```

The downloader also **keeps the raw 1-second data** under `caches/ohlcv/hyperliquid/1s/SP500/` (one
parquet per day; set `KEEP_1S=0` to skip). Re-builds of the 1m then come from the local 1s (no extra S3 read).

**Cost & disk:** the whole xyz dex 1s daily parquet is ~11 MB; a full ~5-month SP500 backfill transfers
well under 1 GB → **~$0.10–0.20 one-time** (requester-pays, ap-northeast-1). Disk: the 1m `.npy` is
~40 KB/day (**~6 MB for 5 months**), and the kept 1s parquet is ~0.7 MB/day (**~100 MB for 5 months**,
~250 MB/year). Re-runs skip already-downloaded days.

Both sources write the **same daily `.npy` format**, so you can mix them or drop in your own archive files.

### C. Keep 1m current going forward — always-on collector container
Because the API only keeps ~3.4 days, run a small always-on collector that polls **NVDA + SP500** once a
day and appends new candles, building a continuous 1m record over time. It's a **separate deployable
unit** (e.g. on a tiny VPS), not started by the default compose — launch it when you're ready:
```bash
docker compose -f docker-compose.collector.yml up -d --build   # service/container: hl-xyz-sp500-collector
docker compose -f docker-compose.collector.yml logs -f         # polls daily (POLL_INTERVAL=86400), retries in 30m on failure
docker compose -f docker-compose.collector.yml down
```
No credentials needed; data persists in `./caches`.

---

## 3. Run a backtest

`PYTHONPATH` must point at `src/`. The default config (`configs/config_sp500.json`) is Hyperliquid SP500.
```bash
# Linux / macOS
PYTHONPATH=src python src/backtest.py configs/config_sp500.json --disable_plotting --skip-rust-compile
```
```powershell
# Windows PowerShell
$env:PYTHONPATH="src"; python src\backtest.py configs\config_sp500.json --disable_plotting --skip-rust-compile
```
```bash
# Docker (uses mounted ./caches, ./configs, ./backtests)
docker compose run --rm passivbot
```
The first run auto-downloads missing recent data from the public API. Reservoir archive reads happen
only after explicit opt-in (`HL_USE_RESERVOIR_ARCHIVE=1` or `backtest.use_reservoir_archive: true`). Output
(analysis, fills, equity curve) lands in `backtests/config_sp500/hyperliquid/`.
`--disable_plotting` keeps it fully headless (no matplotlib needed) — ideal for the VPS/Docker.
`analysis.json` also includes `minimum_capital_*` fields and `projected_cagr_pct`; when plotting is on,
the USD balance chart annotates the minimum-capital floors.

### Configs
All Hyperliquid SP500 configs are single-asset, long-only, isolated. Metrics below are local HL/SP500
backtests from the listed configs, $1000 start. Fee settings matter: the template defaults to
`backtest.fee_multiplier: 2.0`, while the current default SP500 config uses `4.0` for extra fee stress.

| File | What it is |
|------|------------|
| `configs/config_sp500.json` | **default** — fee-stressed GA-tuned SP500 config; latest local run over 2026-03-18..2026-06-06: +35.0% gain / 0.27 Sharpe / 4.2% maxDD |
| `configs/config_sp500_hl_opt_tuned.json` | the same high-gain winner, dates pinned for reproducibility |
| `configs/config_sp500_hl_balanced.json` | balanced pick — +36.1% gain / 0.26 Sharpe / **4.3% maxDD** (lower risk) |
| `configs/config_sp500_hl_opt.json` | Lighter-tuned high-gain seed retargeted to HL (the GA seed) — +29.1% / 0.21 |
| `configs/config_sp500_hl_sharpe.json` | Lighter-tuned "high-Sharpe" seed retargeted to HL — +21.1% / 0.19 |
| `configs/config_sp500_legacy_passive.json` | previous default (near-passive, ~+0.07%) — backup only |
| `configs/config_sp500_lighter.json` | the old Lighter SPY default (kept for reference) |
| `configs/config_sp500_opt*.json` | earlier Lighter optimization outputs (strategy params reusable) |

---

## 4. Run an optimization
**Prereq:** the optimizer needs `deap` (pinned `deap==1.4.3` in `requirements.txt`; `pip install -r requirements.txt`
covers it). Backtests don't import it, so a backtest-only env may be missing it — install it before optimizing.

```bash
PYTHONPATH=src python src/optimize.py configs/config_sp500.json --seed 0 --results-dir runs/sp500_opt --skip-rust-compile
```
Tune `optimize.iters` / `population_size` / `n_cpus` in the config. Scoring: `adg_w_usd`, `gain_usd`, `sharpe_ratio_usd`.
Seed the search with one or more starting configs via `--start <file-or-dir>` (a directory is loaded as multiple seeds).
When reusing a `--results-dir`, a fresh run clears stale Pareto/result artifacts first; pass `--resume`
only when you intentionally want to continue the previous run's front.
Because the opt knobs (`n_cpus`, `iters`, `population_size`, `seed`) live in the config, the identical command runs
under Docker: `docker compose run --rm passivbot src/optimize.py configs/config_sp500.json --skip-rust-compile`.

---

## 5. Live trading (validated)

The live bot uses the **native `hyperliquid-python-sdk`** (`src/exchanges/hyperliquid.py`), with
**isolated** margin, **subaccount/vault** support, and the HIP-3 `xyz` dex. Add a user to
`api-keys.json` (gitignored). If you received a deploy bundle, start from the included template:
```bash
cp api-keys.json.example api-keys.json
```
The default live config already uses `hyperliquid_01`, so fill that block:
```json
{
  "hyperliquid_01": {
    "exchange": "hyperliquid",
    "wallet_address": "0x<account or subaccount owner>",
    "private_key": "0x<API/agent wallet private key>",
    "subaccount_address": "0x<subaccount>",   // optional; omit for the main account
    "is_vault": false,
    "dex": "xyz"
  }
}
```
If you use a different user name, set `live.user` in the config to match it. Leverage comes
from `live.leverage` (capped by the market's max).

Start the bot (uses **`configs/config_sp500.json`** by default — no config arg needed):
```bash
PYTHONPATH=src python src/passivbot.py                       # native conda
docker compose run --rm passivbot src/passivbot.py           # docker
# or pass a different config explicitly:  python src/passivbot.py configs/config_sp500_hl_balanced.json
```

### Minimum capital (enforced live safety gate)
On every live start the bot logs a **config-derived minimum-capital assessment** (`assess_minimum_capital`,
before the execution loop) per approved coin. Hyperliquid exposes both wallet-like sizing balance and
true account equity; live safety gates use **risk capital** (`marginSummary.accountValue` account equity
when available), while order sizing keeps using the wallet-style balance:
- **floor** — below it the *initial entry* can't meet the exchange's min cost, so no position can open
  (`risk capital >= min_cost / (wallet_exposure_limit * (1+risk_we_excess_allowance_pct) * entry_initial_qty_pct)`);
- **recommended** — below it the partial take-profit slice (`close_grid_qty_pct` of the entry) rounds under
  the min, so profit-taking is coarse / full-position-only and behavior drifts from the backtest.
- **enforced** — the live safety threshold: `recommended × (1 + live.min_capital_margin_pct)`.

`live.min_capital_enforcement` defaults to `true`; `live.min_capital_margin_pct` defaults to `0.15`.
The enforced threshold is the one that controls live trading. If risk capital is **below enforced**
and there is **no open position** to manage, startup is refused before the execution loop starts
(`risk capital >= enforced` is accepted). If a position is already open at startup, or if a later price/market
change raises the enforced threshold above risk capital, the bot switches that symbol to `tp_only`
instead: it cancels/blocks initial entries and DCA, but keeps reduce-only take-profit/close handling so the
position can exit. Opening is re-enabled once risk capital again meets the enforced threshold.

If `live.balance_override` is set, that value is used by the sizing-balance path. Otherwise the Hyperliquid
adapter keeps two values explicit: `wallet_balance_for_sizing = accountValue - unrealizedPnl`, and
`account_equity_for_risk = marginSummary.accountValue`.

For **`xyz:SP500`** (price ≈ $7,380, qty step 0.001 → each step ≈ $7.4, min order ≈ $14.8): floor ≈ **$29**,
recommended ≈ **$77**, and default enforced is ≈ **$88**. Because the SP500 quantity step is coarse, the
partial-TP grid still only works well with a few hundred dollars — **~$1,000 (the backtest's starting
balance) is the comfortable target**. ~$99 trades, but with a coarse grid. Lower-priced coins
(e.g. NVDA ≈ $204) are fine at far less. Watch the `[capital]` lines at startup.

### WS-health trading gate
The order-update websocket safety gate also defaults on (`live.ws_health_enforcement=true`,
`live.ws_health_grace_s=30`). If the Hyperliquid SDK websocket is unsubscribed or definitively dead for the
grace window, the bot switches entry-permitting modes to `tp_only` until the websocket is healthy again.
Quiet-but-healthy streams are not treated as dead; the gate checks socket/thread state, not message recency.
As with the capital gate, `tp_only` blocks new entries and DCA while preserving reduce-only take-profit/close
orders and REST polling.

### Deploy live on a VPS (Docker)
`docker-compose.yml` has a **`passivbot-live`** service (mounts `api-keys.json` read-only, `restart: unless-stopped`):
```bash
docker compose build passivbot-live
docker compose up -d passivbot-live      # run the SP500 live bot, detached + auto-restart
docker compose logs -f passivbot-live    # monitor
docker compose down                      # stop (resting orders stay on the exchange until restart)
```

### Check whether a quiet live bot is idle or blocked
A flat bot with no open orders can be normal when the strategy has no executable entry after filters. The
live loop now writes a status heartbeat after every order-planning cycle:
```bash
cat runs/sp500_live/engine_status.json
docker compose logs passivbot-live --tail 200 | grep "\\[idle\\]"
```
The status JSON includes `idle_reason`, account equity, sizing balance, positions, open-order counts,
filter counts, websocket gate state, data-staleness state, and minimum-capital blocks. To ask the exchange
directly and run one read-only debug planning cycle:
```bash
PYTHONPATH=src python src/tools/live_status.py --user hyperliquid_01 --dry-cycle --pretty
```
`--dry-cycle` returns would-cancel/would-create orders without submitting or cancelling anything.

### Live integration test (opt-in, real money)
`src/tools/hyperliquid_live_test.py` exercises the live primitives against a real (sub)account:
balance/positions/open-orders (read-only), then — only when explicitly enabled — placing & canceling a
resting limit, opening via market order, and closing via market (SP500) and via reduce-only limit (a 2nd
xyz market, default NVDA). It is **not** part of the standard test suite (it's a `src/tools/` script, not
collected by pytest) and **only trades when both opt-in flags are passed**:
```bash
# read-only (no money spent): connect, balance, specs + computed minimum order sizes
python src/tools/hyperliquid_live_test.py --user hyperliquid_01

# real-money order-flow test (tiny taker fees on ~$10-15 orders; immediately closed)
python src/tools/hyperliquid_live_test.py --user hyperliquid_01 \
    --live-trade --yes-i-understand-real-money --max-spend-usd 2.0
```
Order sizes are always computed from the bot's own specs (`min_costs`/`min_qtys`/`qty_steps`) and asserted
to meet the exchange's $10 min-notional **before** submission. A `try/finally` cleanup cancels orders and
market-closes any residual position so nothing is ever left open; the run reports realized fees/PnL.
A first real run (SP500 + NVDA) passed all 16 checks for a total cost of **< $0.01**.

**Validated:** balance fetch, position/order fetch, isolated-leverage set, limit place+cancel, market open,
and close-via-market/close-via-limit all work on the funded subaccount.

### Live ENGINE test (opt-in) — the full automated loop
`src/tools/hyperliquid_engine_test.py` validates the live **engine** (not just primitives): market-data
maintenance → strategy grid compute (the Rust orchestrator) → desired-vs-open reconciliation → submit/cancel,
plus the websocket order-update stream, the staleness watchdog/reconnect, and graceful shutdown. It runs one
coin at a time (single-asset is enforced); the 2nd xyz market (default NVDA) is covered with its own
single-asset override. Two modes:
```bash
# Mode A -- DRY ENGINE CYCLE (default; $0, NOTHING submitted):
#   runs one real engine cycle with debug_mode and prints/validates the grid orders it WOULD place
#   (each asserted >= the exchange minimum, isolated, entries near/below mid) for SP500 and NVDA.
python src/tools/hyperliquid_engine_test.py --user hyperliquid_01

# Mode B -- LIVE SOAK (opt-in, real money; dual-flag gated):
#   runs the genuine run_execution_loop live for a while placing real (bounded) grid orders, reconciling
#   across cycles, receiving WS updates, then verifies WS reconnect and flattens everything.
python src/tools/hyperliquid_engine_test.py --user hyperliquid_01 \
    --live-soak --yes-i-understand-real-money --minutes 12 --max-exposure-usd 30 --max-spend-usd 2
```
Peak exposure is bounded via `balance_override`; a `--max-spend-usd` guard plus a `try/finally` cleanup
(cancel-all + reduce-only market-close) keep cost near zero and never leave anything open. Like the
primitives test, it lives in `src/tools/` (no `test_` prefix) so **pytest never collects it**. A first real
soak (SP500 + NVDA) confirmed the engine places/fills/reconciles orders, the WS staleness watchdog reconnects,
and the account ends flat — total cost about **$0.014** ($0.0039 SP500 + $0.0101 NVDA).

### Offline engine unit tests (standard suite)
`tests/` holds fast, deterministic, **offline** ($0, no network) checks for the xyz-specific glue the engine
relies on — symbol/coin mapping (`xyz:` prefix), spec parsing, **isolated-margin `is_cross=False`**, price/size
rounding, the `filter_markets` regression, and single-asset enforcement. Run the standard suite with `pytest -q`
(needs `pytest` + `pytest-asyncio`). The opt-in real-money tools above are not part of it.

---

## Notes & caveats
- The S&P 500 perp trades ~24/7; treat any annualized figure from a short window as a rough bound.
- Default market fees are conservative placeholders (`HYPERLIQUID_MARKETS["SP500"]` in
  `src/hlcv_preparation.py`) and are then scaled by `backtest.fee_multiplier`
  (`2.0` template default, `4.0` in the current SP500 config). `maker_fee_override` /
  `taker_fee_override` replace the base market fees before that multiplier. Verify Trade[XYZ]'s
  actual maker/taker before trusting absolute returns.
  After changing market specs, delete `caches/hlcvs_data/` so the cache rebuilds.
- `--skip-rust-compile` skips the build check; drop it to let it (re)build the extension.
