use crate::analysis::analyze_backtest_pair;
use crate::backtest::Backtest;
use crate::closes::{
    calc_closes_long, calc_closes_short, calc_next_close_long, calc_next_close_short,
};
use crate::constants::{LONG, SHORT};
use crate::entries::{
    calc_entries_long, calc_entries_short, calc_next_entry_long, calc_next_entry_short,
};
use crate::equity_hard_stop_loss as ehsl;
use crate::risk::{
    calc_twel_enforcer_actions, calc_unstucking_action, gate_entries_by_twel, GateEntriesCandidate,
    GateEntriesDecision, GateEntriesPosition, TwelEnforcerInputPosition, UnstuckPositionInput,
};
use crate::trailing::{
    trailing_bundle_to_tuple, tuple_to_trailing_bundle, update_trailing_bundle_sequence,
};
use crate::types::OrderType;
use crate::types::{
    BacktestParams, BotParams, BotParamsPair, CoinMeta, EMABands, EquityHardStopLossConfig,
    EquityHardStopLossTierRatios, ExchangeParams, ForagerScoreWeights, HlcvsBundle, HlcvsMeta,
    OrderBook, Position, StateParams, TrailingPriceBundle,
};
use ndarray::Array2;
use numpy::{IntoPyArray, PyArray1, PyArray3, PyArrayMethods, PyReadonlyArray1, PyReadonlyArray3};
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyAny, PyDict, PyList};
use pyo3::PyObject;
use serde::Serialize;
use serde_json;
use std::str::FromStr;

type BacktestPyResult = (PyObject, PyObject, Py<PyDict>, Py<PyDict>, PyObject);

#[pyclass(name = "HlcvsBundle", module = "passivbot_rust", unsendable)]
pub struct HlcvsBundlePy {
    pub inner: HlcvsBundle,
}

#[pyclass(
    name = "EquityHardStopRollingPeak",
    module = "passivbot_rust",
    unsendable
)]
pub struct EquityHardStopRollingPeakPy {
    inner: ehsl::RollingPeakTracker,
}

#[pyclass(name = "EquityHardStopRuntime", module = "passivbot_rust", unsendable)]
pub struct EquityHardStopRuntimePy {
    state: ehsl::HardStopState,
    last_rolling_peak: f64,
}

#[pymethods]
impl HlcvsBundlePy {
    #[new]
    #[pyo3(signature = (hlcvs, btc_usd, timestamps, meta))]
    pub fn new(
        hlcvs: Py<PyArray3<f64>>,
        btc_usd: Py<PyArray1<f64>>,
        timestamps: Py<PyArray1<i64>>,
        meta: &Bound<'_, PyAny>,
    ) -> PyResult<Self> {
        let parsed_meta = hlcvs_meta_from_py(meta)?;
        let bundle = HlcvsBundle {
            hlcvs,
            btc_usd,
            timestamps,
            meta: parsed_meta,
        };
        Python::with_gil(|py| bundle.validate_shapes(py))?;
        Ok(Self { inner: bundle })
    }

    #[getter]
    pub fn hlcvs<'py>(&self, py: Python<'py>) -> PyObject {
        self.inner.hlcvs.clone_ref(py).into_py(py)
    }

    #[getter]
    pub fn btc_usd<'py>(&self, py: Python<'py>) -> PyObject {
        self.inner.btc_usd.clone_ref(py).into_py(py)
    }

    #[getter]
    pub fn timestamps<'py>(&self, py: Python<'py>) -> PyObject {
        self.inner.timestamps.clone_ref(py).into_py(py)
    }

    #[getter]
    pub fn meta<'py>(&self, py: Python<'py>) -> PyResult<PyObject> {
        Ok(hlcvs_meta_to_dict(py, &self.inner.meta)?.into_py(py))
    }

    pub fn coin_meta<'py>(&self, symbol: &str, py: Python<'py>) -> PyResult<Option<PyObject>> {
        if let Some(meta) = self.inner.coin_meta_by_symbol(symbol) {
            Ok(Some(coin_meta_to_dict(py, meta)?.into_py(py)))
        } else {
            Ok(None)
        }
    }

    pub fn coins_len(&self) -> usize {
        self.inner.coins_len()
    }
}

#[pymethods]
impl EquityHardStopRollingPeakPy {
    #[new]
    pub fn new() -> Self {
        Self {
            inner: ehsl::RollingPeakTracker::default(),
        }
    }

    pub fn reset(&mut self) {
        self.inner.reset();
    }

    pub fn len(&self) -> usize {
        self.inner.len()
    }

    pub fn update(&mut self, timestamp_ms: u64, equity: f64, lookback_ms: u64) -> PyResult<f64> {
        self.inner
            .update(timestamp_ms, equity, lookback_ms)
            .map_err(PyValueError::new_err)
    }
}

#[pymethods]
impl EquityHardStopRuntimePy {
    #[new]
    pub fn new() -> Self {
        Self {
            state: ehsl::HardStopState::default(),
            last_rolling_peak: 0.0,
        }
    }

    pub fn reset(&mut self) {
        self.state = ehsl::HardStopState::default();
        self.last_rolling_peak = 0.0;
    }

    pub fn reset_state_keep_peak(&mut self) {
        self.state = ehsl::HardStopState::default();
    }

    pub fn initialized(&self) -> bool {
        self.state.initialized
    }

    pub fn red_latched(&self) -> bool {
        self.state.red_latched
    }

    pub fn tier(&self) -> &'static str {
        hard_stop_tier_to_str(self.state.tier)
    }

    pub fn drawdown_ema(&self) -> f64 {
        self.state.drawdown_ema
    }

    pub fn peak_strategy_equity(&self) -> f64 {
        self.state.peak_strategy_equity
    }

    pub fn rolling_peak_strategy_equity(&self) -> f64 {
        self.last_rolling_peak
    }

    #[pyo3(signature = (
        *,
        timestamp_ms,
        equity,
        peak_strategy_equity,
        red_threshold,
        ema_span_minutes,
        tier_ratio_yellow,
        tier_ratio_orange
    ))]
    pub fn apply_sample(
        &mut self,
        py: Python<'_>,
        timestamp_ms: u64,
        equity: f64,
        peak_strategy_equity: f64,
        red_threshold: f64,
        ema_span_minutes: f64,
        tier_ratio_yellow: f64,
        tier_ratio_orange: f64,
    ) -> PyResult<Py<PyDict>> {
        self.last_rolling_peak = peak_strategy_equity;
        let cfg = ehsl::HardStopConfig {
            red_threshold,
            ema_span_minutes,
            tier_ratios: ehsl::HardStopTierRatios {
                yellow: tier_ratio_yellow,
                orange: tier_ratio_orange,
            },
        };
        let step = ehsl::step_with_peak_strategy_equity(
            &mut self.state,
            cfg,
            equity,
            peak_strategy_equity,
            timestamp_ms,
        )
        .map_err(PyValueError::new_err)?;

        let out = PyDict::new_bound(py);
        out.set_item("initialized", self.state.initialized)?;
        out.set_item("red_latched", self.state.red_latched)?;
        out.set_item("peak_strategy_equity", self.state.peak_strategy_equity)?;
        out.set_item("rolling_peak_strategy_equity", self.last_rolling_peak)?;
        out.set_item("drawdown_ema", self.state.drawdown_ema)?;
        out.set_item("tier", hard_stop_tier_to_str(self.state.tier))?;
        out.set_item("drawdown_raw", step.drawdown_raw)?;
        out.set_item("drawdown_score", step.drawdown_score)?;
        out.set_item("changed", step.changed)?;
        out.set_item("alpha", step.alpha)?;
        out.set_item("elapsed_minutes", step.elapsed_minutes)?;
        Ok(out.unbind())
    }
}

fn hlcvs_meta_from_py(any: &Bound<'_, PyAny>) -> PyResult<HlcvsMeta> {
    let dict = any
        .downcast::<PyDict>()
        .map_err(|_| PyValueError::new_err("hlcvs meta must be a dict"))?;

    let requested = get_u64(dict, "requested_start_timestamp_ms")?;
    let effective = get_u64(dict, "effective_start_timestamp_ms")?;
    let warm_req = get_u64(dict, "warmup_minutes_requested")?;
    let warm_prov = get_u64(dict, "warmup_minutes_provided")?;

    let coins_obj = dict
        .get_item("coins")?
        .ok_or_else(|| PyValueError::new_err("hlcvs meta missing 'coins'"))?;
    let coins_list = coins_obj
        .downcast::<PyList>()
        .map_err(|_| PyValueError::new_err("'coins' must be a list"))?;
    let mut coins = Vec::with_capacity(coins_list.len());
    for (idx, item) in coins_list.iter().enumerate() {
        let coin_dict = item
            .downcast::<PyDict>()
            .map_err(|_| PyValueError::new_err("coin metadata entries must be dicts"))?;
        coins.push(parse_coin_meta(coin_dict, idx)?);
    }

    Ok(HlcvsMeta {
        requested_start_timestamp_ms: requested,
        effective_start_timestamp_ms: effective,
        warmup_minutes_requested: warm_req,
        warmup_minutes_provided: warm_prov,
        coins,
    })
}

fn get_u64(dict: &Bound<'_, PyDict>, key: &str) -> PyResult<u64> {
    dict.get_item(key)?
        .ok_or_else(|| PyValueError::new_err(format!("hlcvs meta missing '{key}'")))?
        .extract::<u64>()
        .map_err(|_| PyValueError::new_err(format!("hlcvs meta field '{key}' must be int")))
}

fn parse_coin_meta(dict: &Bound<'_, PyDict>, default_index: usize) -> PyResult<CoinMeta> {
    let index = dict
        .get_item("index")?
        .map(|val| val.extract::<usize>())
        .transpose()?
        .unwrap_or(default_index);
    let symbol = dict
        .get_item("symbol")?
        .ok_or_else(|| PyValueError::new_err("coin meta missing 'symbol'"))?
        .extract::<String>()?;
    let coin = dict
        .get_item("coin")?
        .map(|val| val.extract::<String>())
        .transpose()?
        .unwrap_or_else(|| symbol.clone());
    let exchange = dict
        .get_item("exchange")?
        .ok_or_else(|| PyValueError::new_err("coin meta missing 'exchange'"))?
        .extract::<String>()?;
    let quote = dict
        .get_item("quote")?
        .ok_or_else(|| PyValueError::new_err("coin meta missing 'quote'"))?
        .extract::<String>()?;
    let base = dict
        .get_item("base")?
        .ok_or_else(|| PyValueError::new_err("coin meta missing 'base'"))?
        .extract::<String>()?;

    macro_rules! fval {
        ($key:literal) => {
            dict.get_item($key)?
                .ok_or_else(|| PyValueError::new_err(format!("coin meta missing '{}'", $key)))?
                .extract::<f64>()
                .map_err(|_| {
                    PyValueError::new_err(format!("coin meta field '{}' must be float", $key))
                })?
        };
    }

    macro_rules! usize_val {
        ($key:literal) => {
            dict.get_item($key)?
                .ok_or_else(|| PyValueError::new_err(format!("coin meta missing '{}'", $key)))?
                .extract::<usize>()
                .map_err(|_| {
                    PyValueError::new_err(format!("coin meta field '{}' must be int", $key))
                })?
        };
    }

    Ok(CoinMeta {
        index,
        symbol,
        coin,
        exchange,
        quote,
        base,
        qty_step: fval!("qty_step"),
        price_step: fval!("price_step"),
        min_qty: fval!("min_qty"),
        min_cost: fval!("min_cost"),
        c_mult: fval!("c_mult"),
        maker_fee: fval!("maker_fee"),
        taker_fee: fval!("taker_fee"),
        first_valid_index: usize_val!("first_valid_index"),
        last_valid_index: usize_val!("last_valid_index"),
        warmup_minutes: usize_val!("warmup_minutes"),
        trade_start_index: usize_val!("trade_start_index"),
    })
}

fn coin_meta_to_dict<'py>(py: Python<'py>, meta: &CoinMeta) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new_bound(py);
    dict.set_item("index", meta.index)?;
    dict.set_item("symbol", &meta.symbol)?;
    dict.set_item("coin", &meta.coin)?;
    dict.set_item("exchange", &meta.exchange)?;
    dict.set_item("quote", &meta.quote)?;
    dict.set_item("base", &meta.base)?;
    dict.set_item("qty_step", meta.qty_step)?;
    dict.set_item("price_step", meta.price_step)?;
    dict.set_item("min_qty", meta.min_qty)?;
    dict.set_item("min_cost", meta.min_cost)?;
    dict.set_item("c_mult", meta.c_mult)?;
    dict.set_item("maker_fee", meta.maker_fee)?;
    dict.set_item("taker_fee", meta.taker_fee)?;
    dict.set_item("first_valid_index", meta.first_valid_index)?;
    dict.set_item("last_valid_index", meta.last_valid_index)?;
    dict.set_item("warmup_minutes", meta.warmup_minutes)?;
    dict.set_item("trade_start_index", meta.trade_start_index)?;
    Ok(dict)
}

fn hlcvs_meta_to_dict<'py>(py: Python<'py>, meta: &HlcvsMeta) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new_bound(py);
    dict.set_item(
        "requested_start_timestamp_ms",
        meta.requested_start_timestamp_ms,
    )?;
    dict.set_item(
        "effective_start_timestamp_ms",
        meta.effective_start_timestamp_ms,
    )?;
    dict.set_item("warmup_minutes_requested", meta.warmup_minutes_requested)?;
    dict.set_item("warmup_minutes_provided", meta.warmup_minutes_provided)?;
    let coins = PyList::empty_bound(py);
    for entry in &meta.coins {
        coins.append(coin_meta_to_dict(py, entry)?)?;
    }
    dict.set_item("coins", coins)?;
    Ok(dict)
}

#[pyfunction]
pub fn trailing_bundle_default_py() -> (f64, f64, f64, f64) {
    let bundle = TrailingPriceBundle::default();
    trailing_bundle_to_tuple(&bundle)
}

#[pyfunction]
#[pyo3(signature = (highs, lows, closes, bundle=None))]
pub fn update_trailing_bundle_py(
    highs: PyReadonlyArray1<'_, f64>,
    lows: PyReadonlyArray1<'_, f64>,
    closes: PyReadonlyArray1<'_, f64>,
    bundle: Option<(f64, f64, f64, f64)>,
) -> PyResult<(f64, f64, f64, f64)> {
    let highs = highs.as_slice()?;
    let lows = lows.as_slice()?;
    let closes = closes.as_slice()?;

    let len = highs.len();
    if lows.len() != len || closes.len() != len {
        return Err(PyValueError::new_err(
            "highs, lows, and closes must have the same length",
        ));
    }

    let mut bundle = match bundle {
        Some(values) => tuple_to_trailing_bundle(values),
        None => TrailingPriceBundle::default(),
    };

    update_trailing_bundle_sequence(&mut bundle, highs, lows, closes);

    Ok(trailing_bundle_to_tuple(&bundle))
}

fn hard_stop_tier_from_str(raw: &str) -> Result<ehsl::HardStopTier, String> {
    match raw {
        "green" => Ok(ehsl::HardStopTier::Green),
        "yellow" => Ok(ehsl::HardStopTier::Yellow),
        "orange" => Ok(ehsl::HardStopTier::Orange),
        "red" => Ok(ehsl::HardStopTier::Red),
        _ => Err(format!(
            "invalid hard-stop tier '{}'; expected one of {{green,yellow,orange,red}}",
            raw
        )),
    }
}

fn hard_stop_tier_to_str(tier: ehsl::HardStopTier) -> &'static str {
    match tier {
        ehsl::HardStopTier::Green => "green",
        ehsl::HardStopTier::Yellow => "yellow",
        ehsl::HardStopTier::Orange => "orange",
        ehsl::HardStopTier::Red => "red",
    }
}

#[pyfunction]
#[pyo3(signature = (
    *,
    initialized,
    red_latched,
    drawdown_ema,
    tier,
    red_threshold,
    ema_span_minutes,
    tier_ratio_yellow,
    tier_ratio_orange,
    equity,
    peak_strategy_equity,
    timestamp_ms
))]
pub fn equity_hard_stop_step_py(
    py: Python<'_>,
    initialized: bool,
    red_latched: bool,
    drawdown_ema: f64,
    tier: &str,
    red_threshold: f64,
    ema_span_minutes: f64,
    tier_ratio_yellow: f64,
    tier_ratio_orange: f64,
    equity: f64,
    peak_strategy_equity: f64,
    timestamp_ms: u64,
) -> PyResult<Py<PyDict>> {
    let mut state = ehsl::HardStopState {
        peak_strategy_equity,
        drawdown_ema,
        tier: hard_stop_tier_from_str(tier).map_err(PyValueError::new_err)?,
        red_latched,
        initialized,
        ..Default::default()
    };
    let cfg = ehsl::HardStopConfig {
        red_threshold,
        ema_span_minutes,
        tier_ratios: ehsl::HardStopTierRatios {
            yellow: tier_ratio_yellow,
            orange: tier_ratio_orange,
        },
    };
    let step = ehsl::step_with_peak_strategy_equity(
        &mut state,
        cfg,
        equity,
        peak_strategy_equity,
        timestamp_ms,
    )
    .map_err(PyValueError::new_err)?;

    let out = PyDict::new_bound(py);
    out.set_item("initialized", state.initialized)?;
    out.set_item("red_latched", state.red_latched)?;
    out.set_item("peak_strategy_equity", state.peak_strategy_equity)?;
    out.set_item("drawdown_ema", state.drawdown_ema)?;
    out.set_item("tier", hard_stop_tier_to_str(state.tier))?;
    out.set_item("drawdown_raw", step.drawdown_raw)?;
    out.set_item("drawdown_score", step.drawdown_score)?;
    out.set_item("changed", step.changed)?;
    out.set_item("alpha", step.alpha)?;
    out.set_item("elapsed_minutes", step.elapsed_minutes)?;
    Ok(out.unbind())
}

#[pyfunction]
pub fn gate_entries_by_twel_py(
    side: &str,
    balance: f64,
    total_wallet_exposure_limit: f64,
    positions: &Bound<'_, PyList>,
    entries: &Bound<'_, PyList>,
) -> PyResult<Vec<(usize, f64, f64, u16)>> {
    let positions = positions.as_ref();
    let entries = entries.as_ref();
    let side_code = match side {
        "long" => LONG,
        "short" => SHORT,
        _ => {
            return Err(PyValueError::new_err(
                "side must be either 'long' or 'short'",
            ))
        }
    };
    if balance <= 0.0 || total_wallet_exposure_limit <= 0.0 {
        return Ok(vec![]);
    }

    let positions_len = positions.len()?;
    let mut positions_vec: Vec<GateEntriesPosition> = Vec::with_capacity(positions_len);
    for item in positions.iter()? {
        let item = item?;
        let dict = item.downcast::<PyDict>()?;
        let idx = dict
            .get_item("idx")?
            .ok_or_else(|| PyValueError::new_err("position missing 'idx'"))?
            .extract::<usize>()?;
        let position_size = dict
            .get_item("position_size")?
            .ok_or_else(|| PyValueError::new_err("position missing 'position_size'"))?
            .extract::<f64>()?;
        let position_price = dict
            .get_item("position_price")?
            .ok_or_else(|| PyValueError::new_err("position missing 'position_price'"))?
            .extract::<f64>()?;
        let c_mult = dict
            .get_item("c_mult")?
            .ok_or_else(|| PyValueError::new_err("position missing 'c_mult'"))?
            .extract::<f64>()?;
        positions_vec.push(GateEntriesPosition {
            idx,
            position_size,
            position_price,
            c_mult,
        });
    }

    let entries_len = entries.len()?;
    let mut entries_vec: Vec<GateEntriesCandidate> = Vec::with_capacity(entries_len);
    for item in entries.iter()? {
        let item = item?;
        let dict = item.downcast::<PyDict>()?;
        let idx = dict
            .get_item("idx")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'idx'"))?
            .extract::<usize>()?;
        let qty = dict
            .get_item("qty")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'qty'"))?
            .extract::<f64>()?;
        let price = dict
            .get_item("price")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'price'"))?
            .extract::<f64>()?;
        let qty_step = dict
            .get_item("qty_step")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'qty_step'"))?
            .extract::<f64>()?;
        let min_qty = dict
            .get_item("min_qty")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'min_qty'"))?
            .extract::<f64>()?;
        let min_cost = dict
            .get_item("min_cost")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'min_cost'"))?
            .extract::<f64>()?;
        let c_mult = dict
            .get_item("c_mult")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'c_mult'"))?
            .extract::<f64>()?;
        let market_price = dict
            .get_item("market_price")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'market_price'"))?
            .extract::<f64>()?;
        let order_type_id = dict
            .get_item("order_type_id")?
            .ok_or_else(|| PyValueError::new_err("entry missing 'order_type_id'"))?
            .extract::<u16>()?;
        let order_type = OrderType::try_from(order_type_id).map_err(|_| {
            PyValueError::new_err("unknown order_type_id provided to gate_entries_by_twel")
        })?;
        entries_vec.push(GateEntriesCandidate {
            idx,
            qty,
            price,
            qty_step,
            min_qty,
            min_cost,
            c_mult,
            market_price,
            order_type,
        });
    }

    let gated = gate_entries_by_twel(
        side_code,
        balance,
        total_wallet_exposure_limit,
        &positions_vec,
        &entries_vec,
    );

    let mut result: Vec<(usize, f64, f64, u16)> = Vec::with_capacity(gated.len());
    for GateEntriesDecision {
        idx,
        qty,
        price,
        order_type,
        ..
    } in gated
    {
        result.push((idx, qty, price, order_type.id()));
    }
    Ok(result)
}

#[pyfunction]
pub fn calc_unstucking_close_py(
    balance: f64,
    allowance_long: f64,
    allowance_short: f64,
    positions: &Bound<'_, PyList>,
) -> PyResult<Option<(usize, usize, f64, f64, u16)>> {
    let positions = positions.as_ref();
    let positions_len = positions.len()?;
    let mut inputs: Vec<UnstuckPositionInput> = Vec::with_capacity(positions_len);
    for item in positions.iter()? {
        let item = item?;
        let dict = item.downcast::<PyDict>()?;
        let idx = dict
            .get_item("idx")?
            .ok_or_else(|| PyValueError::new_err("position missing 'idx'"))?
            .extract::<usize>()?;
        let side_str: String = dict
            .get_item("side")?
            .ok_or_else(|| PyValueError::new_err("position missing 'side'"))?
            .extract::<String>()?;
        let side = match side_str.as_str() {
            "long" => LONG,
            "short" => SHORT,
            _ => {
                return Err(PyValueError::new_err(
                    "position side must be 'long' or 'short'",
                ))
            }
        };
        let position_size = dict
            .get_item("position_size")?
            .ok_or_else(|| PyValueError::new_err("position missing 'position_size'"))?
            .extract::<f64>()?;
        let position_price = dict
            .get_item("position_price")?
            .ok_or_else(|| PyValueError::new_err("position missing 'position_price'"))?
            .extract::<f64>()?;
        let wallet_exposure_limit = dict
            .get_item("wallet_exposure_limit")?
            .ok_or_else(|| PyValueError::new_err("position missing 'wallet_exposure_limit'"))?
            .extract::<f64>()?;
        let risk_we_excess_allowance_pct = dict
            .get_item("risk_we_excess_allowance_pct")?
            .ok_or_else(|| {
                PyValueError::new_err("position missing 'risk_we_excess_allowance_pct'")
            })?
            .extract::<f64>()?;
        let unstuck_threshold = dict
            .get_item("unstuck_threshold")?
            .ok_or_else(|| PyValueError::new_err("position missing 'unstuck_threshold'"))?
            .extract::<f64>()?;
        let unstuck_close_pct = dict
            .get_item("unstuck_close_pct")?
            .ok_or_else(|| PyValueError::new_err("position missing 'unstuck_close_pct'"))?
            .extract::<f64>()?;
        let unstuck_ema_dist = dict
            .get_item("unstuck_ema_dist")?
            .ok_or_else(|| PyValueError::new_err("position missing 'unstuck_ema_dist'"))?
            .extract::<f64>()?;
        let ema_band_upper = dict
            .get_item("ema_band_upper")?
            .ok_or_else(|| PyValueError::new_err("position missing 'ema_band_upper'"))?
            .extract::<f64>()?;
        let ema_band_lower = dict
            .get_item("ema_band_lower")?
            .ok_or_else(|| PyValueError::new_err("position missing 'ema_band_lower'"))?
            .extract::<f64>()?;
        let current_price = dict
            .get_item("current_price")?
            .ok_or_else(|| PyValueError::new_err("position missing 'current_price'"))?
            .extract::<f64>()?;
        let price_step = dict
            .get_item("price_step")?
            .ok_or_else(|| PyValueError::new_err("position missing 'price_step'"))?
            .extract::<f64>()?;
        let qty_step = dict
            .get_item("qty_step")?
            .ok_or_else(|| PyValueError::new_err("position missing 'qty_step'"))?
            .extract::<f64>()?;
        let min_qty = dict
            .get_item("min_qty")?
            .ok_or_else(|| PyValueError::new_err("position missing 'min_qty'"))?
            .extract::<f64>()?;
        let min_cost = dict
            .get_item("min_cost")?
            .ok_or_else(|| PyValueError::new_err("position missing 'min_cost'"))?
            .extract::<f64>()?;
        let c_mult = dict
            .get_item("c_mult")?
            .ok_or_else(|| PyValueError::new_err("position missing 'c_mult'"))?
            .extract::<f64>()?;

        inputs.push(UnstuckPositionInput {
            idx,
            side,
            position_size,
            position_price,
            wallet_exposure_limit,
            risk_we_excess_allowance_pct,
            unstuck_threshold,
            unstuck_close_pct,
            unstuck_ema_dist,
            ema_band_upper,
            ema_band_lower,
            current_price,
            price_step,
            qty_step,
            min_qty,
            min_cost,
            c_mult,
        });
    }

    let result = calc_unstucking_action(balance, allowance_long, allowance_short, &inputs);
    Ok(result.map(|(idx, side, order)| (idx, side, order.qty, order.price, order.order_type.id())))
}

#[cfg(test)]
mod tests {
    use super::*;
    use pyo3::prepare_freethreaded_python;
    use pyo3::types::{PyDict, PyList};

    #[test]
    fn test_gate_entries_blocks_when_twe_if_filled_exceeds() {
        prepare_freethreaded_python();
        Python::with_gil(|py| {
            let side = "long";
            let balance = 1000.0;
            let twel = 1.0;
            // One position small
            let positions = PyList::empty_bound(py);
            let p0 = PyDict::new_bound(py);
            p0.set_item("idx", 0usize).unwrap();
            p0.set_item("position_size", 0.0f64).unwrap();
            p0.set_item("position_price", 0.0f64).unwrap();
            p0.set_item("c_mult", 1.0f64).unwrap();
            positions.append(p0).unwrap();
            // Two entries that together would push twe_if_filled >= 1.0
            let entries = PyList::empty_bound(py);
            let e1 = PyDict::new_bound(py);
            e1.set_item("idx", 0usize).unwrap();
            e1.set_item("qty", 5.0f64).unwrap(); // cost 5*100/1000 = 0.5
            e1.set_item("price", 100.0f64).unwrap();
            e1.set_item("qty_step", 0.01f64).unwrap();
            e1.set_item("min_qty", 0.0f64).unwrap();
            e1.set_item("min_cost", 0.0f64).unwrap();
            e1.set_item("c_mult", 1.0f64).unwrap();
            e1.set_item("market_price", 100.0f64).unwrap();
            e1.set_item("order_type_id", OrderType::EntryGridNormalLong.id())
                .unwrap();
            entries.append(e1).unwrap();
            let e2 = PyDict::new_bound(py);
            e2.set_item("idx", 0usize).unwrap();
            e2.set_item("qty", 6.0f64).unwrap(); // +0.6 exposure -> total 1.1 > 1.0
            e2.set_item("price", 100.0f64).unwrap();
            e2.set_item("qty_step", 0.01f64).unwrap();
            e2.set_item("min_qty", 0.0f64).unwrap();
            e2.set_item("min_cost", 0.0f64).unwrap();
            e2.set_item("c_mult", 1.0f64).unwrap();
            e2.set_item("market_price", 90.0f64).unwrap();
            e2.set_item("order_type_id", OrderType::EntryGridNormalLong.id())
                .unwrap();
            entries.append(e2).unwrap();

            let res = gate_entries_by_twel_py(side, balance, twel, &positions, &entries).unwrap();
            // Should not allow both; either prune one or adjust last
            assert!(!res.is_empty());
            // Simulate twe_if_filled with returned
            let mut psize = 0.0f64;
            let mut pprice = 0.0f64;
            for (idx, qty, price, _ot) in res.into_iter() {
                let (_i, _qty, _price) = (idx, qty, price);
                let (nps, npp) =
                    crate::utils::calc_new_psize_pprice(psize, pprice, qty, price, 0.01);
                psize = nps;
                pprice = npp;
            }
            let twe = crate::utils::calc_wallet_exposure(
                1.0,
                balance,
                psize.abs(),
                if pprice > 0.0 { pprice } else { 100.0 },
            );
            assert!(
                twe < twel - 1e-12,
                "gated twe {} not strictly below {}",
                twe,
                twel
            );
        });
    }
}

#[pyfunction]
pub fn run_backtest(
    hlcvs: PyReadonlyArray3<f64>,
    btc_usd: PyReadonlyArray1<f64>,
    bot_params: &Bound<'_, PyAny>,
    exchange_params_list: &Bound<'_, PyAny>,
    backtest_params_dict: &Bound<'_, PyDict>,
) -> PyResult<BacktestPyResult> {
    run_backtest_core(
        hlcvs,
        btc_usd,
        bot_params,
        exchange_params_list,
        backtest_params_dict,
    )
}

#[pyfunction]
pub fn run_backtest_bundle(
    bundle: &HlcvsBundlePy,
    bot_params: &Bound<'_, PyAny>,
    exchange_params_list: &Bound<'_, PyAny>,
    backtest_params_dict: &Bound<'_, PyDict>,
) -> PyResult<BacktestPyResult> {
    let py = bot_params.py();
    let hlcvs = bundle.inner.hlcvs.bind(py).readonly();
    let btc = bundle.inner.btc_usd.bind(py).readonly();
    run_backtest_core(
        hlcvs,
        btc,
        bot_params,
        exchange_params_list,
        backtest_params_dict,
    )
}

fn run_backtest_core<'py>(
    hlcvs: PyReadonlyArray3<'py, f64>,
    btc_usd: PyReadonlyArray1<'py, f64>,
    bot_params: &Bound<'py, PyAny>,
    exchange_params_list: &Bound<'py, PyAny>,
    backtest_params_dict: &Bound<'py, PyDict>,
) -> PyResult<BacktestPyResult> {
    let hlcvs_rust = hlcvs.as_array();
    let btc_usd_rust = btc_usd.as_array();

    if hlcvs_rust.ndim() != 3 {
        return Err(PyValueError::new_err(format!(
            "Expected 3D HLCV array, got ndim={}",
            hlcvs_rust.ndim()
        )));
    }

    let n_timesteps = hlcvs_rust.shape()[0];
    if btc_usd_rust.len() != n_timesteps {
        return Err(PyValueError::new_err(format!(
            "BTC/USD data length ({}) does not match HLCV timesteps ({})",
            btc_usd_rust.len(),
            n_timesteps
        )));
    }

    let bot_params_py_list_bound = bot_params
        .downcast::<PyList>()
        .map_err(|_| PyValueError::new_err("bot_params must be a list[dict] (one per coin)"))?;
    let bot_params_py_list = bot_params_py_list_bound.as_gil_ref();

    let bot_params_len = bot_params_py_list.len();
    let mut bot_params_vec = Vec::with_capacity(bot_params_len);
    for item in bot_params_py_list.iter() {
        let dict = item
            .downcast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each bot_params element must be a dict"))?;
        bot_params_vec.push(bot_params_pair_from_dict(dict)?);
    }

    let exchange_params_list_bound = exchange_params_list
        .downcast::<PyList>()
        .map_err(|_| PyValueError::new_err("Unsupported data type for exchange_params_list"))?;
    let exchange_params_list = exchange_params_list_bound.as_gil_ref();
    let list_len = exchange_params_list.len();
    let mut exchange_params = Vec::with_capacity(list_len);
    for item in exchange_params_list.iter() {
        let dict = item
            .downcast::<PyDict>()
            .map_err(|_| PyValueError::new_err("Unsupported data type in exchange_params_list"))?;
        exchange_params.push(exchange_params_from_dict(dict)?);
    }

    let backtest_params = backtest_params_from_dict(backtest_params_dict.as_gil_ref())?;
    let metrics_only = backtest_params.metrics_only;
    let mut backtest = Backtest::new(
        hlcvs_rust,
        btc_usd_rust,
        bot_params_vec,
        exchange_params,
        &backtest_params,
    );

    // Run the backtest and process results
    Python::with_gil(|py| {
        let (fills, equities) = backtest.run().map_err(PyValueError::new_err)?;
        let (entry_pct_long, entry_pct_short) = backtest.initial_entry_balance_pct();
        let (mut analysis_usd, mut analysis_btc) = analyze_backtest_pair(
            &fills,
            &equities,
            backtest.balance.use_btc_collateral,
            &backtest.total_wallet_exposures,
            backtest.liquidated(),
        );
        analysis_usd.entry_initial_balance_pct_long = entry_pct_long;
        analysis_usd.entry_initial_balance_pct_short = entry_pct_short;
        analysis_btc.entry_initial_balance_pct_long = entry_pct_long;
        analysis_btc.entry_initial_balance_pct_short = entry_pct_short;

        let hs = backtest.hard_stop_metrics();
        let strategy = backtest.strategy_equity_metrics_for_analysis();
        analysis_usd.hard_stop_triggers = hs.triggers;
        analysis_usd.hard_stop_triggers_per_year = hs.triggers_per_year;
        analysis_usd.hard_stop_triggers_long = hs.triggers_long;
        analysis_usd.hard_stop_triggers_short = hs.triggers_short;
        analysis_usd.hard_stop_halt_to_restart_equity_loss_pct = hs.halt_to_restart_equity_loss_pct;
        analysis_usd.hard_stop_restarts = hs.restarts;
        analysis_usd.hard_stop_restarts_per_year = hs.restarts_per_year;
        analysis_usd.hard_stop_restarts_per_year_long = hs.restarts_per_year_long;
        analysis_usd.hard_stop_restarts_per_year_short = hs.restarts_per_year_short;
        analysis_usd.hard_stop_restarts_long = hs.restarts_long;
        analysis_usd.hard_stop_restarts_short = hs.restarts_short;
        analysis_usd.hard_stop_time_in_yellow_pct = hs.time_in_yellow_pct;
        analysis_usd.hard_stop_time_in_orange_pct = hs.time_in_orange_pct;
        analysis_usd.hard_stop_time_in_red_pct = hs.time_in_red_pct;
        analysis_usd.hard_stop_duration_minutes_mean = hs.duration_minutes_mean;
        analysis_usd.hard_stop_duration_minutes_max = hs.duration_minutes_max;
        analysis_usd.hard_stop_trigger_drawdown_mean = hs.trigger_drawdown_mean;
        analysis_usd.hard_stop_panic_close_loss_sum = hs.panic_close_loss_sum;
        analysis_usd.hard_stop_panic_close_loss_max = hs.panic_close_loss_max;
        analysis_usd.hard_stop_flatten_time_minutes_mean = hs.flatten_time_minutes_mean;
        analysis_usd.hard_stop_post_restart_retrigger_pct = hs.post_restart_retrigger_pct;
        analysis_usd.drawdown_worst_strategy_eq = strategy.overall.drawdown_worst_strategy_eq;
        analysis_usd.drawdown_worst_strategy_eq_long = strategy.long.drawdown_worst_strategy_eq;
        analysis_usd.drawdown_worst_strategy_eq_short = strategy.short.drawdown_worst_strategy_eq;
        analysis_usd.drawdown_worst_ema_strategy_eq = strategy
            .long
            .drawdown_worst_ema_strategy_eq
            .max(strategy.short.drawdown_worst_ema_strategy_eq);
        analysis_usd.drawdown_worst_ema_strategy_eq_long =
            strategy.long.drawdown_worst_ema_strategy_eq;
        analysis_usd.drawdown_worst_ema_strategy_eq_short =
            strategy.short.drawdown_worst_ema_strategy_eq;
        analysis_usd.drawdown_worst_mean_1pct_strategy_eq =
            strategy.overall.drawdown_worst_mean_1pct_strategy_eq;
        analysis_usd.drawdown_worst_mean_1pct_strategy_eq_long =
            strategy.long.drawdown_worst_mean_1pct_strategy_eq;
        analysis_usd.drawdown_worst_mean_1pct_strategy_eq_short =
            strategy.short.drawdown_worst_mean_1pct_strategy_eq;
        analysis_usd.drawdown_worst_mean_1pct_ema_strategy_eq = strategy
            .long
            .drawdown_worst_mean_1pct_ema_strategy_eq
            .max(strategy.short.drawdown_worst_mean_1pct_ema_strategy_eq);
        analysis_usd.drawdown_worst_mean_1pct_ema_strategy_eq_long =
            strategy.long.drawdown_worst_mean_1pct_ema_strategy_eq;
        analysis_usd.drawdown_worst_mean_1pct_ema_strategy_eq_short =
            strategy.short.drawdown_worst_mean_1pct_ema_strategy_eq;
        analysis_usd.peak_recovery_hours_strategy_eq =
            strategy.overall.peak_recovery_hours_strategy_eq;
        analysis_usd.peak_recovery_hours_strategy_eq_long =
            strategy.long.peak_recovery_hours_strategy_eq;
        analysis_usd.peak_recovery_hours_strategy_eq_short =
            strategy.short.peak_recovery_hours_strategy_eq;
        analysis_usd.peak_recovery_days_strategy_eq =
            strategy.overall.peak_recovery_days_strategy_eq;
        analysis_usd.peak_recovery_days_strategy_eq_long =
            strategy.long.peak_recovery_days_strategy_eq;
        analysis_usd.peak_recovery_days_strategy_eq_short =
            strategy.short.peak_recovery_days_strategy_eq;
        analysis_usd.gain_strategy_eq = strategy.overall.gain_strategy_eq;
        analysis_usd.adg_strategy_eq = strategy.overall.adg_strategy_eq;
        analysis_usd.mdg_strategy_eq = strategy.overall.mdg_strategy_eq;
        analysis_usd.sharpe_ratio_strategy_eq = strategy.overall.sharpe_ratio_strategy_eq;
        analysis_usd.sortino_ratio_strategy_eq = strategy.overall.sortino_ratio_strategy_eq;
        analysis_usd.omega_ratio_strategy_eq = strategy.overall.omega_ratio_strategy_eq;
        analysis_usd.expected_shortfall_1pct_strategy_eq =
            strategy.overall.expected_shortfall_1pct_strategy_eq;
        analysis_usd.calmar_ratio_strategy_eq = strategy.overall.calmar_ratio_strategy_eq;
        analysis_usd.sterling_ratio_strategy_eq = strategy.overall.sterling_ratio_strategy_eq;
        analysis_usd.adg_strategy_eq_w = strategy.overall.adg_strategy_eq_w;
        analysis_usd.mdg_strategy_eq_w = strategy.overall.mdg_strategy_eq_w;
        analysis_usd.sharpe_ratio_strategy_eq_w = strategy.overall.sharpe_ratio_strategy_eq_w;
        analysis_usd.sortino_ratio_strategy_eq_w = strategy.overall.sortino_ratio_strategy_eq_w;
        analysis_usd.omega_ratio_strategy_eq_w = strategy.overall.omega_ratio_strategy_eq_w;
        analysis_usd.calmar_ratio_strategy_eq_w = strategy.overall.calmar_ratio_strategy_eq_w;
        analysis_usd.sterling_ratio_strategy_eq_w = strategy.overall.sterling_ratio_strategy_eq_w;
        analysis_btc.hard_stop_triggers = hs.triggers;
        analysis_btc.hard_stop_triggers_per_year = hs.triggers_per_year;
        analysis_btc.hard_stop_triggers_long = hs.triggers_long;
        analysis_btc.hard_stop_triggers_short = hs.triggers_short;
        analysis_btc.hard_stop_halt_to_restart_equity_loss_pct = hs.halt_to_restart_equity_loss_pct;
        analysis_btc.hard_stop_restarts = hs.restarts;
        analysis_btc.hard_stop_restarts_per_year = hs.restarts_per_year;
        analysis_btc.hard_stop_restarts_per_year_long = hs.restarts_per_year_long;
        analysis_btc.hard_stop_restarts_per_year_short = hs.restarts_per_year_short;
        analysis_btc.hard_stop_restarts_long = hs.restarts_long;
        analysis_btc.hard_stop_restarts_short = hs.restarts_short;
        analysis_btc.hard_stop_time_in_yellow_pct = hs.time_in_yellow_pct;
        analysis_btc.hard_stop_time_in_orange_pct = hs.time_in_orange_pct;
        analysis_btc.hard_stop_time_in_red_pct = hs.time_in_red_pct;
        analysis_btc.hard_stop_duration_minutes_mean = hs.duration_minutes_mean;
        analysis_btc.hard_stop_duration_minutes_max = hs.duration_minutes_max;
        analysis_btc.hard_stop_trigger_drawdown_mean = hs.trigger_drawdown_mean;
        analysis_btc.hard_stop_panic_close_loss_sum = hs.panic_close_loss_sum;
        analysis_btc.hard_stop_panic_close_loss_max = hs.panic_close_loss_max;
        analysis_btc.hard_stop_flatten_time_minutes_mean = hs.flatten_time_minutes_mean;
        analysis_btc.hard_stop_post_restart_retrigger_pct = hs.post_restart_retrigger_pct;
        analysis_btc.drawdown_worst_strategy_eq = strategy.overall.drawdown_worst_strategy_eq;
        analysis_btc.drawdown_worst_strategy_eq_long = strategy.long.drawdown_worst_strategy_eq;
        analysis_btc.drawdown_worst_strategy_eq_short = strategy.short.drawdown_worst_strategy_eq;
        analysis_btc.drawdown_worst_ema_strategy_eq = strategy
            .long
            .drawdown_worst_ema_strategy_eq
            .max(strategy.short.drawdown_worst_ema_strategy_eq);
        analysis_btc.drawdown_worst_ema_strategy_eq_long =
            strategy.long.drawdown_worst_ema_strategy_eq;
        analysis_btc.drawdown_worst_ema_strategy_eq_short =
            strategy.short.drawdown_worst_ema_strategy_eq;
        analysis_btc.drawdown_worst_mean_1pct_strategy_eq =
            strategy.overall.drawdown_worst_mean_1pct_strategy_eq;
        analysis_btc.drawdown_worst_mean_1pct_strategy_eq_long =
            strategy.long.drawdown_worst_mean_1pct_strategy_eq;
        analysis_btc.drawdown_worst_mean_1pct_strategy_eq_short =
            strategy.short.drawdown_worst_mean_1pct_strategy_eq;
        analysis_btc.drawdown_worst_mean_1pct_ema_strategy_eq = strategy
            .long
            .drawdown_worst_mean_1pct_ema_strategy_eq
            .max(strategy.short.drawdown_worst_mean_1pct_ema_strategy_eq);
        analysis_btc.drawdown_worst_mean_1pct_ema_strategy_eq_long =
            strategy.long.drawdown_worst_mean_1pct_ema_strategy_eq;
        analysis_btc.drawdown_worst_mean_1pct_ema_strategy_eq_short =
            strategy.short.drawdown_worst_mean_1pct_ema_strategy_eq;
        analysis_btc.peak_recovery_hours_strategy_eq =
            strategy.overall.peak_recovery_hours_strategy_eq;
        analysis_btc.peak_recovery_hours_strategy_eq_long =
            strategy.long.peak_recovery_hours_strategy_eq;
        analysis_btc.peak_recovery_hours_strategy_eq_short =
            strategy.short.peak_recovery_hours_strategy_eq;
        analysis_btc.peak_recovery_days_strategy_eq =
            strategy.overall.peak_recovery_days_strategy_eq;
        analysis_btc.peak_recovery_days_strategy_eq_long =
            strategy.long.peak_recovery_days_strategy_eq;
        analysis_btc.peak_recovery_days_strategy_eq_short =
            strategy.short.peak_recovery_days_strategy_eq;
        analysis_btc.gain_strategy_eq = strategy.overall.gain_strategy_eq;
        analysis_btc.adg_strategy_eq = strategy.overall.adg_strategy_eq;
        analysis_btc.mdg_strategy_eq = strategy.overall.mdg_strategy_eq;
        analysis_btc.sharpe_ratio_strategy_eq = strategy.overall.sharpe_ratio_strategy_eq;
        analysis_btc.sortino_ratio_strategy_eq = strategy.overall.sortino_ratio_strategy_eq;
        analysis_btc.omega_ratio_strategy_eq = strategy.overall.omega_ratio_strategy_eq;
        analysis_btc.expected_shortfall_1pct_strategy_eq =
            strategy.overall.expected_shortfall_1pct_strategy_eq;
        analysis_btc.calmar_ratio_strategy_eq = strategy.overall.calmar_ratio_strategy_eq;
        analysis_btc.sterling_ratio_strategy_eq = strategy.overall.sterling_ratio_strategy_eq;
        analysis_btc.adg_strategy_eq_w = strategy.overall.adg_strategy_eq_w;
        analysis_btc.mdg_strategy_eq_w = strategy.overall.mdg_strategy_eq_w;
        analysis_btc.sharpe_ratio_strategy_eq_w = strategy.overall.sharpe_ratio_strategy_eq_w;
        analysis_btc.sortino_ratio_strategy_eq_w = strategy.overall.sortino_ratio_strategy_eq_w;
        analysis_btc.omega_ratio_strategy_eq_w = strategy.overall.omega_ratio_strategy_eq_w;
        analysis_btc.calmar_ratio_strategy_eq_w = strategy.overall.calmar_ratio_strategy_eq_w;
        analysis_btc.sterling_ratio_strategy_eq_w = strategy.overall.sterling_ratio_strategy_eq_w;

        // Create a dictionary to store analysis results using a more concise approach
        let py_analysis_usd = struct_to_py_dict(py, &analysis_usd)?;
        let py_analysis_btc = struct_to_py_dict(py, &analysis_btc)?;
        if metrics_only {
            return Ok((
                py.None().into_py(py),
                py.None().into_py(py),
                py_analysis_usd,
                py_analysis_btc,
                py.None().into_py(py),
            ));
        }
        let hard_stop_plot_data = backtest.hard_stop_plot_data();
        let py_events_long = PyList::empty_bound(py);
        for event in hard_stop_plot_data.events_long {
            let py_event = PyDict::new_bound(py);
            py_event.set_item("kind", event.kind)?;
            py_event.set_item("timestamp_ms", event.timestamp_ms)?;
            if let Some(cooldown_until_ms) = event.cooldown_until_ms {
                py_event.set_item("cooldown_until_ms", cooldown_until_ms)?;
            }
            py_event.set_item("terminal", event.terminal)?;
            py_events_long.append(py_event)?;
        }
        let py_events_short = PyList::empty_bound(py);
        for event in hard_stop_plot_data.events_short {
            let py_event = PyDict::new_bound(py);
            py_event.set_item("kind", event.kind)?;
            py_event.set_item("timestamp_ms", event.timestamp_ms)?;
            if let Some(cooldown_until_ms) = event.cooldown_until_ms {
                py_event.set_item("cooldown_until_ms", cooldown_until_ms)?;
            }
            py_event.set_item("terminal", event.terminal)?;
            py_events_short.append(py_event)?;
        }
        let py_hard_stop_plot = PyDict::new_bound(py);
        py_hard_stop_plot.set_item("timestamps_ms", hard_stop_plot_data.timestamps_ms)?;
        py_hard_stop_plot.set_item("drawdown_raw", hard_stop_plot_data.drawdown_raw)?;
        py_hard_stop_plot.set_item("timestamps_ms_long", hard_stop_plot_data.timestamps_ms_long)?;
        py_hard_stop_plot.set_item("drawdown_raw_long", hard_stop_plot_data.drawdown_raw_long)?;
        py_hard_stop_plot.set_item("drawdown_ema_long", hard_stop_plot_data.drawdown_ema_long)?;
        py_hard_stop_plot.set_item(
            "drawdown_score_long",
            hard_stop_plot_data.drawdown_score_long,
        )?;
        py_hard_stop_plot.set_item("events_long", py_events_long)?;
        py_hard_stop_plot.set_item(
            "timestamps_ms_short",
            hard_stop_plot_data.timestamps_ms_short,
        )?;
        py_hard_stop_plot.set_item("drawdown_raw_short", hard_stop_plot_data.drawdown_raw_short)?;
        py_hard_stop_plot.set_item("drawdown_ema_short", hard_stop_plot_data.drawdown_ema_short)?;
        py_hard_stop_plot.set_item(
            "drawdown_score_short",
            hard_stop_plot_data.drawdown_score_short,
        )?;
        py_hard_stop_plot.set_item("events_short", py_events_short)?;
        let mut py_fills = Array2::from_elem((fills.len(), 19), py.None());
        for (i, fill) in fills.iter().enumerate() {
            py_fills[(i, 0)] = fill.index.into_py(py);
            py_fills[(i, 1)] = (fill.timestamp_ms as i64).into_py(py);
            py_fills[(i, 2)] = <String as Clone>::clone(&fill.coin).into_py(py);
            py_fills[(i, 3)] = fill.pnl.into_py(py);
            py_fills[(i, 4)] = fill.fee_paid.into_py(py);
            py_fills[(i, 5)] = fill.usd_total_balance.into_py(py);
            py_fills[(i, 6)] = fill.btc_cash_wallet.into_py(py);
            py_fills[(i, 7)] = fill.usd_cash_wallet.into_py(py);
            py_fills[(i, 8)] = fill.btc_price.into_py(py);
            py_fills[(i, 9)] = fill.fill_qty.into_py(py);
            py_fills[(i, 10)] = fill.fill_price.into_py(py);
            py_fills[(i, 11)] = fill.position_size.into_py(py);
            py_fills[(i, 12)] = fill.position_price.into_py(py);
            py_fills[(i, 13)] = fill.order_type.to_string().into_py(py);
            py_fills[(i, 14)] = fill.liquidity.clone().into_py(py);
            py_fills[(i, 15)] = fill.wallet_exposure.into_py(py);
            py_fills[(i, 16)] = fill.twe_long.into_py(py);
            py_fills[(i, 17)] = fill.twe_short.into_py(py);
            py_fills[(i, 18)] = fill.twe_net.into_py(py);
        }

        let strategy_equity_series = backtest.strategy_equity_series_for_artifacts();
        let equities_array =
            Array2::from_shape_fn((equities.timestamps_ms.len(), 4), |(i, j)| match j {
                0 => equities.timestamps_ms[i] as f64,
                1 => equities.usd_total_equity[i],
                2 => equities.btc_total_equity[i],
                3 => strategy_equity_series
                    .get(i)
                    .copied()
                    .unwrap_or(equities.usd_total_equity[i]),
                _ => 0.0,
            })
            .into_pyarray_bound(py)
            .unbind();
        let fills_array = py_fills.into_pyarray_bound(py).unbind();
        Ok((
            fills_array.into_py(py),
            equities_array.into_py(py),
            py_analysis_usd,
            py_analysis_btc,
            py_hard_stop_plot.into_py(py),
        ))
    })
}

fn struct_to_py_dict<T: Serialize + ?Sized>(py: Python<'_>, obj: &T) -> PyResult<Py<PyDict>> {
    // Convert struct to JSON string
    let json_str = serde_json::to_string(obj).map_err(|e| {
        PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("JSON serialization error: {}", e))
    })?;

    // Use Python's json module to convert to a Python dict
    let json = py.import_bound("json")?;
    let py_obj_any = json.call_method1("loads", (json_str,))?.unbind();
    let py_obj_bound = py_obj_any.bind(py);

    // Convert to PyDict
    let py_dict_bound = py_obj_bound.downcast::<PyDict>().map_err(|_| {
        PyErr::new::<pyo3::exceptions::PyTypeError, _>("Failed to convert to Python dict")
    })?;
    Ok(py_dict_bound.clone().unbind())
}

fn backtest_params_from_dict(dict: &PyDict) -> PyResult<BacktestParams> {
    let parse_hsl_cfg = |parent: &PyDict, key: &str| -> PyResult<EquityHardStopLossConfig> {
        let item = parent
            .get_item(key)?
            .ok_or_else(|| PyValueError::new_err(format!("missing required key: {key}")))?;
        let cfg = item
            .downcast::<PyDict>()
            .map_err(|_| PyValueError::new_err(format!("{key} must be a dict")))?;
        let ratios_item = cfg.get_item("tier_ratios")?.ok_or_else(|| {
            PyValueError::new_err(format!("missing required key: {key}.tier_ratios"))
        })?;
        let ratios = ratios_item
            .downcast::<PyDict>()
            .map_err(|_| PyValueError::new_err(format!("{key}.tier_ratios must be a dict")))?;
        let signal_mode = cfg
            .get_item("signal_mode")?
            .map(|item| item.extract::<String>())
            .transpose()?
            .unwrap_or_else(|| "unified".to_string());
        if signal_mode != "pside" && signal_mode != "unified" {
            return Err(PyValueError::new_err(format!(
                "{key}.signal_mode must be one of {{pside, unified}}, got {:?}",
                signal_mode
            )));
        }
        Ok(EquityHardStopLossConfig {
            enabled: extract_value(cfg, "enabled")?,
            signal_mode,
            red_threshold: extract_value(cfg, "red_threshold")?,
            ema_span_minutes: extract_value(cfg, "ema_span_minutes")?,
            cooldown_minutes_after_red: extract_value(cfg, "cooldown_minutes_after_red")?,
            no_restart_drawdown_threshold: extract_value(cfg, "no_restart_drawdown_threshold")?,
            tier_ratios: EquityHardStopLossTierRatios {
                yellow: extract_value(ratios, "yellow")?,
                orange: extract_value(ratios, "orange")?,
            },
            orange_tier_mode: extract_value(cfg, "orange_tier_mode")?,
            panic_close_order_type: extract_value(cfg, "panic_close_order_type")?,
        })
    };
    let hard_stop_cfg = parse_hsl_cfg(dict, "equity_hard_stop_loss")?;

    Ok(BacktestParams {
        starting_balance: extract_value(dict, "starting_balance")?,
        maker_fee: extract_value(dict, "maker_fee")?,
        taker_fee: extract_value(dict, "taker_fee")?,
        coins: extract_value(dict, "coins")?,
        active_coin_indices: match dict.get_item("active_coin_indices")? {
            Some(item) if !item.is_none() => Some(item.extract::<Vec<usize>>()?),
            _ => None,
        },
        first_timestamp_ms: extract_value(dict, "first_timestamp_ms")?,
        requested_start_timestamp_ms: extract_value(dict, "requested_start_timestamp_ms")?,
        first_valid_indices: extract_value(dict, "first_valid_indices")?,
        last_valid_indices: extract_value(dict, "last_valid_indices")?,
        warmup_minutes: extract_value(dict, "warmup_minutes")?,
        trade_start_indices: extract_value(dict, "trade_start_indices")?,
        global_warmup_bars: extract_value(dict, "global_warmup_bars")?,
        btc_collateral_cap: extract_value(dict, "btc_collateral_cap")?,
        btc_collateral_ltv_cap: match dict.get_item("btc_collateral_ltv_cap")? {
            Some(item) if !item.is_none() => Some(item.extract::<f64>()?),
            _ => None,
        },
        metrics_only: dict
            .get_item("metrics_only")?
            .map(|item| item.extract::<bool>())
            .transpose()?
            .unwrap_or(false),
        filter_by_min_effective_cost: dict
            .get_item("filter_by_min_effective_cost")?
            .map(|item| item.extract::<bool>())
            .transpose()?
            .unwrap_or(false),
        dynamic_wel_by_tradability: extract_value(dict, "dynamic_wel_by_tradability")?,
        hedge_mode: dict
            .get_item("hedge_mode")?
            .map(|item| item.extract::<bool>())
            .transpose()?
            .unwrap_or(true),
        max_realized_loss_pct: dict
            .get_item("max_realized_loss_pct")?
            .map(|item| item.extract::<f64>())
            .transpose()?
            .unwrap_or(1.0),
        pnls_max_lookback_days: extract_value(dict, "pnls_max_lookback_days")?,
        liquidation_threshold: dict
            .get_item("liquidation_threshold")?
            .map(|item| item.extract::<f64>())
            .transpose()?
            .unwrap_or(0.05),
        equity_hard_stop_loss: hard_stop_cfg,
        market_orders_allowed: dict
            .get_item("market_orders_allowed")?
            .map(|item| item.extract::<bool>())
            .transpose()?
            .unwrap_or(false),
        market_order_near_touch_threshold: dict
            .get_item("market_order_near_touch_threshold")?
            .map(|item| item.extract::<f64>())
            .transpose()?
            .unwrap_or(0.001),
        market_order_slippage_pct: dict
            .get_item("market_order_slippage_pct")?
            .map(|item| item.extract::<f64>())
            .transpose()?
            .unwrap_or(0.0005),
        forager_score_hysteresis_pct: dict
            .get_item("forager_score_hysteresis_pct")?
            .map(|item| item.extract::<f64>())
            .transpose()?
            .unwrap_or(0.02),
        candle_interval_minutes: dict
            .get_item("candle_interval_minutes")?
            .map(|item| item.extract::<u64>())
            .transpose()?
            .unwrap_or(1), // default to 1m candles
        initial_positions_long: match dict.get_item("initial_positions_long")? {
            Some(item) if !item.is_none() => item.extract::<Vec<(usize, f64, f64)>>()?,
            _ => Vec::new(),
        },
        initial_positions_short: match dict.get_item("initial_positions_short")? {
            Some(item) if !item.is_none() => item.extract::<Vec<(usize, f64, f64)>>()?,
            _ => Vec::new(),
        },
    })
}

fn exchange_params_from_dict(dict: &PyDict) -> PyResult<ExchangeParams> {
    Ok(ExchangeParams {
        qty_step: extract_value(dict, "qty_step").unwrap_or_default(),
        price_step: extract_value(dict, "price_step").unwrap_or_default(),
        min_qty: extract_value(dict, "min_qty").unwrap_or_default(),
        min_cost: extract_value(dict, "min_cost").unwrap_or_default(),
        c_mult: extract_value(dict, "c_mult").unwrap_or_default(),
        maker_fee: extract_value(dict, "maker_fee").unwrap_or(0.0002),
        taker_fee: extract_value(dict, "taker_fee").unwrap_or(0.00055),
    })
}

fn bot_params_pair_from_dict(dict: &PyDict) -> PyResult<BotParamsPair> {
    Ok(BotParamsPair {
        long: bot_params_from_dict(extract_value(dict, "long")?)?,
        short: bot_params_from_dict(extract_value(dict, "short")?)?,
    })
}

fn extract_grid_spacing_we_weight(dict: &PyDict) -> PyResult<f64> {
    if let Some(obj) = dict.get_item("entry_grid_spacing_we_weight")? {
        obj.extract::<f64>()
    } else {
        extract_value(dict, "entry_grid_spacing_we_weight")
    }
}

fn bot_params_from_dict(dict: &PyDict) -> PyResult<BotParams> {
    let risk_wel_enforcer_threshold: f64 = extract_value(dict, "risk_wel_enforcer_threshold")?;
    let risk_twel_enforcer_threshold: f64 = extract_value(dict, "risk_twel_enforcer_threshold")?;
    let risk_we_excess_allowance_pct: f64 = extract_value(dict, "risk_we_excess_allowance_pct")?;
    let total_wallet_exposure_limit: f64 = extract_value(dict, "total_wallet_exposure_limit")?;
    let wallet_exposure_limit_raw: f64 = extract_value(dict, "wallet_exposure_limit")?;
    let n_positions_float: f64 = extract_value(dict, "n_positions")?;
    let n_positions = n_positions_float.round() as usize;
    let hsl_enabled: bool = extract_value(dict, "hsl_enabled")?;
    let hsl_red_threshold: f64 = extract_value(dict, "hsl_red_threshold")?;
    let hsl_ema_span_minutes: f64 = extract_value(dict, "hsl_ema_span_minutes")?;
    let hsl_cooldown_minutes_after_red: f64 =
        extract_value(dict, "hsl_cooldown_minutes_after_red")?;
    let hsl_no_restart_drawdown_threshold: f64 =
        extract_value(dict, "hsl_no_restart_drawdown_threshold")?;
    let hsl_tier_ratios = dict
        .get_item("hsl_tier_ratios")?
        .ok_or_else(|| PyValueError::new_err("position missing 'hsl_tier_ratios'"))?
        .downcast::<PyDict>()
        .map_err(|_| PyValueError::new_err("hsl_tier_ratios must be a dict"))?;
    let hsl_tier_ratio_yellow: f64 = extract_value(hsl_tier_ratios, "yellow")?;
    let hsl_tier_ratio_orange: f64 = extract_value(hsl_tier_ratios, "orange")?;
    let hsl_orange_tier_mode: String = extract_value(dict, "hsl_orange_tier_mode")?;
    let hsl_panic_close_order_type: String = extract_value(dict, "hsl_panic_close_order_type")?;
    // Callers resolve live fixed denominators before building orchestrator input.
    // Preserve zero here: per-symbol zero is the explicit side-disable sentinel.
    let wallet_exposure_limit = wallet_exposure_limit_raw;

    Ok(BotParams {
        close_grid_markup_end: extract_value(dict, "close_grid_markup_end")?,
        close_grid_markup_start: extract_value(dict, "close_grid_markup_start")?,
        close_grid_qty_pct: extract_value(dict, "close_grid_qty_pct")?,
        close_trailing_retracement_pct: extract_value(dict, "close_trailing_retracement_pct")?,
        close_trailing_grid_ratio: extract_value(dict, "close_trailing_grid_ratio")?,
        close_trailing_qty_pct: extract_value(dict, "close_trailing_qty_pct")?,
        close_trailing_threshold_pct: extract_value(dict, "close_trailing_threshold_pct")?,
        entry_grid_double_down_factor: extract_value(dict, "entry_grid_double_down_factor")?,
        entry_grid_spacing_volatility_weight: extract_value(
            dict,
            "entry_grid_spacing_volatility_weight",
        )?,
        entry_grid_spacing_we_weight: extract_grid_spacing_we_weight(dict)?,
        entry_grid_spacing_pct: extract_value(dict, "entry_grid_spacing_pct")?,
        entry_volatility_ema_span_hours: extract_value_with_fallback(
            dict,
            "entry_volatility_ema_span_hours",
            "entry_log_range_ema_span_hours",
        )?,
        entry_initial_ema_dist: extract_value(dict, "entry_initial_ema_dist")?,
        entry_initial_qty_pct: extract_value(dict, "entry_initial_qty_pct")?,
        entry_trailing_double_down_factor: extract_value(
            dict,
            "entry_trailing_double_down_factor",
        )?,
        entry_trailing_retracement_pct: extract_value(dict, "entry_trailing_retracement_pct")?,
        entry_trailing_retracement_we_weight: extract_value(
            dict,
            "entry_trailing_retracement_we_weight",
        )?,
        entry_trailing_retracement_volatility_weight: extract_value(
            dict,
            "entry_trailing_retracement_volatility_weight",
        )?,
        entry_trailing_grid_ratio: extract_value(dict, "entry_trailing_grid_ratio")?,
        entry_trailing_threshold_pct: extract_value(dict, "entry_trailing_threshold_pct")?,
        entry_trailing_threshold_we_weight: extract_value(
            dict,
            "entry_trailing_threshold_we_weight",
        )?,
        entry_trailing_threshold_volatility_weight: extract_value(
            dict,
            "entry_trailing_threshold_volatility_weight",
        )?,
        filter_volatility_ema_span: extract_value_with_fallback(
            dict,
            "forager_volatility_ema_span",
            "filter_volatility_ema_span",
        )
        .or_else(|_| {
            extract_value_with_fallback(
                dict,
                "filter_volatility_ema_span",
                "filter_log_range_ema_span",
            )
        })?,
        filter_volume_ema_span: extract_value_with_fallback(
            dict,
            "forager_volume_ema_span",
            "filter_volume_ema_span",
        )?,
        _legacy_filter_volatility_drop_pct: 0.0,
        forager_volume_drop_pct: extract_value_with_fallback(
            dict,
            "forager_volume_drop_pct",
            "filter_volume_drop_pct",
        )?,
        forager_score_weights: dict
            .get_item("forager_score_weights")
            .ok()
            .flatten()
            .map(|_| extract_forager_score_weights(dict))
            .transpose()?
            .unwrap_or_default(),
        ema_span_0: extract_value(dict, "ema_span_0")?,
        ema_span_1: extract_value(dict, "ema_span_1")?,
        hsl_enabled,
        hsl_red_threshold,
        hsl_ema_span_minutes,
        hsl_cooldown_minutes_after_red,
        hsl_no_restart_drawdown_threshold,
        hsl_tier_ratio_yellow,
        hsl_tier_ratio_orange,
        hsl_orange_tier_mode,
        hsl_panic_close_order_type,
        n_positions,
        total_wallet_exposure_limit,
        wallet_exposure_limit,
        risk_wel_enforcer_threshold,
        risk_twel_enforcer_threshold,
        risk_we_excess_allowance_pct,
        unstuck_close_pct: extract_value(dict, "unstuck_close_pct")?,
        unstuck_ema_dist: extract_value(dict, "unstuck_ema_dist")?,
        unstuck_loss_allowance_pct: extract_value(dict, "unstuck_loss_allowance_pct")?,
        unstuck_threshold: extract_value(dict, "unstuck_threshold")?,
    })
}

fn extract_forager_score_weights(dict: &PyDict) -> PyResult<ForagerScoreWeights> {
    let weights_dict = dict
        .get_item("forager_score_weights")
        .map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyKeyError, _>("Key 'forager_score_weights' not found")
        })?
        .ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Value for key 'forager_score_weights' is None",
            )
        })?
        .downcast::<PyDict>()?;
    let weights = ForagerScoreWeights {
        volume: extract_value(weights_dict, "volume")?,
        ema_readiness: extract_value(weights_dict, "ema_readiness")?,
        volatility: extract_value(weights_dict, "volatility")?,
    };
    weights.canonicalize().map_err(PyValueError::new_err)
}

fn validate_forager_score_weights_pair(bot_params: &BotParamsPair) -> PyResult<()> {
    for (pside, params) in [("long", &bot_params.long), ("short", &bot_params.short)] {
        if let Err(err) = params.forager_score_weights.canonicalize() {
            return Err(PyValueError::new_err(format!("bot.{pside}.{err}")));
        }
    }
    Ok(())
}

fn extract_value<'a, T: pyo3::FromPyObject<'a>>(dict: &'a PyDict, key: &str) -> PyResult<T> {
    dict.get_item(key)
        .map_err(|_| {
            PyErr::new::<pyo3::exceptions::PyKeyError, _>(format!("Key '{}' not found", key))
        })?
        .ok_or_else(|| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
                "Value for key '{}' is None",
                key
            ))
        })
        .and_then(pyo3::FromPyObject::extract)
}

fn extract_value_with_fallback<'a, T: pyo3::FromPyObject<'a>>(
    dict: &'a PyDict,
    primary: &str,
    fallback: &str,
) -> PyResult<T> {
    if let Some(item) = dict.get_item(primary)? {
        return item.extract::<T>();
    }
    if let Some(item) = dict.get_item(fallback)? {
        return item.extract::<T>();
    }
    Err(PyErr::new::<pyo3::exceptions::PyKeyError, _>(format!(
        "Keys '{}' or '{}' not found",
        primary, fallback
    )))
}

#[pyfunction]
pub fn calc_next_entry_long_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    entry_grid_double_down_factor: f64,
    entry_grid_spacing_volatility_weight: f64,
    entry_grid_spacing_we_weight: f64,
    entry_grid_spacing_pct: f64,
    entry_initial_ema_dist: f64,
    entry_initial_qty_pct: f64,
    entry_trailing_double_down_factor: f64,
    entry_trailing_grid_ratio: f64,
    entry_trailing_retracement_pct: f64,
    entry_trailing_retracement_we_weight: f64,
    entry_trailing_retracement_volatility_weight: f64,
    entry_trailing_threshold_pct: f64,
    entry_trailing_threshold_we_weight: f64,
    entry_trailing_threshold_volatility_weight: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    ema_bands_lower: f64,
    entry_volatility_logrange_ema_1h: f64,
    order_book_bid: f64,
) -> (f64, f64, String) {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };
    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            bid: order_book_bid,
            ..Default::default()
        },
        ema_bands: EMABands {
            lower: ema_bands_lower,
            ..Default::default()
        },
        entry_volatility_logrange_ema_1h,
        ..Default::default()
    };
    let bot_params = BotParams {
        entry_grid_double_down_factor,
        entry_grid_spacing_volatility_weight,
        entry_grid_spacing_we_weight,
        entry_grid_spacing_pct,
        entry_initial_ema_dist,
        entry_initial_qty_pct,
        entry_trailing_double_down_factor,
        entry_trailing_grid_ratio,
        entry_trailing_retracement_pct,
        entry_trailing_retracement_we_weight,
        entry_trailing_retracement_volatility_weight,
        entry_trailing_threshold_pct,
        entry_trailing_threshold_we_weight,
        entry_trailing_threshold_volatility_weight,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        ..Default::default()
    };
    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let next_entry = calc_next_entry_long(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    (
        next_entry.qty,
        next_entry.price,
        next_entry.order_type.to_string(),
    )
}

#[pyfunction]
pub fn calc_next_close_long_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    close_grid_markup_end: f64,
    close_grid_markup_start: f64,
    close_grid_qty_pct: f64,
    close_trailing_grid_ratio: f64,
    close_trailing_qty_pct: f64,
    close_trailing_retracement_pct: f64,
    close_trailing_threshold_pct: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    risk_wel_enforcer_threshold: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    order_book_ask: f64,
) -> (f64, f64, String) {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };
    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            ask: order_book_ask,
            ..Default::default()
        },
        ..Default::default()
    };
    let bot_params = BotParams {
        close_grid_markup_end,
        close_grid_markup_start,
        close_grid_qty_pct,
        close_trailing_grid_ratio,
        close_trailing_qty_pct,
        close_trailing_retracement_pct,
        close_trailing_threshold_pct,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        risk_wel_enforcer_threshold,
        ..Default::default()
    };
    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let next_entry = calc_next_close_long(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );
    (
        next_entry.qty,
        next_entry.price,
        next_entry.order_type.to_string(),
    )
}

#[pyfunction]
pub fn calc_next_entry_short_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    entry_grid_double_down_factor: f64,
    entry_grid_spacing_volatility_weight: f64,
    entry_grid_spacing_we_weight: f64,
    entry_grid_spacing_pct: f64,
    entry_initial_ema_dist: f64,
    entry_initial_qty_pct: f64,
    entry_trailing_double_down_factor: f64,
    entry_trailing_grid_ratio: f64,
    entry_trailing_retracement_pct: f64,
    entry_trailing_retracement_we_weight: f64,
    entry_trailing_retracement_volatility_weight: f64,
    entry_trailing_threshold_pct: f64,
    entry_trailing_threshold_we_weight: f64,
    entry_trailing_threshold_volatility_weight: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    ema_bands_upper: f64,
    entry_volatility_logrange_ema_1h: f64,
    order_book_ask: f64,
) -> (f64, f64, String) {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };
    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            ask: order_book_ask,
            ..Default::default()
        },
        ema_bands: EMABands {
            upper: ema_bands_upper,
            ..Default::default()
        },
        entry_volatility_logrange_ema_1h,
        ..Default::default()
    };
    let bot_params = BotParams {
        entry_grid_double_down_factor,
        entry_grid_spacing_volatility_weight,
        entry_grid_spacing_we_weight,
        entry_grid_spacing_pct,
        entry_initial_ema_dist,
        entry_initial_qty_pct,
        entry_trailing_double_down_factor,
        entry_trailing_grid_ratio,
        entry_trailing_retracement_pct,
        entry_trailing_retracement_we_weight,
        entry_trailing_retracement_volatility_weight,
        entry_trailing_threshold_pct,
        entry_trailing_threshold_we_weight,
        entry_trailing_threshold_volatility_weight,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        ..Default::default()
    };
    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let next_entry = calc_next_entry_short(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    (
        next_entry.qty,
        next_entry.price,
        next_entry.order_type.to_string(),
    )
}

#[pyfunction]
pub fn calc_next_close_short_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    close_grid_markup_end: f64,
    close_grid_markup_start: f64,
    close_grid_qty_pct: f64,
    close_trailing_grid_ratio: f64,
    close_trailing_qty_pct: f64,
    close_trailing_retracement_pct: f64,
    close_trailing_threshold_pct: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    risk_wel_enforcer_threshold: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    order_book_bid: f64,
) -> (f64, f64, String) {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };
    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            bid: order_book_bid,
            ..Default::default()
        },
        ..Default::default()
    };
    let bot_params = BotParams {
        close_grid_markup_end,
        close_grid_markup_start,
        close_grid_qty_pct,
        close_trailing_grid_ratio,
        close_trailing_qty_pct,
        close_trailing_retracement_pct,
        close_trailing_threshold_pct,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        risk_wel_enforcer_threshold,
        ..Default::default()
    };
    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let next_entry = calc_next_close_short(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );
    (
        next_entry.qty,
        next_entry.price,
        next_entry.order_type.to_string(),
    )
}

#[pyfunction]
pub fn calc_entries_long_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    entry_grid_double_down_factor: f64,
    entry_grid_spacing_volatility_weight: f64,
    entry_grid_spacing_we_weight: f64,
    entry_grid_spacing_pct: f64,
    entry_initial_ema_dist: f64,
    entry_initial_qty_pct: f64,
    entry_trailing_double_down_factor: f64,
    entry_trailing_grid_ratio: f64,
    entry_trailing_retracement_pct: f64,
    entry_trailing_retracement_we_weight: f64,
    entry_trailing_retracement_volatility_weight: f64,
    entry_trailing_threshold_pct: f64,
    entry_trailing_threshold_we_weight: f64,
    entry_trailing_threshold_volatility_weight: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    ema_bands_lower: f64,
    entry_volatility_logrange_ema_1h: f64,
    order_book_bid: f64,
) -> Vec<(f64, f64, u16)> {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };

    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            bid: order_book_bid,
            ..Default::default()
        },
        ema_bands: EMABands {
            lower: ema_bands_lower,
            ..Default::default()
        },
        entry_volatility_logrange_ema_1h,
        ..Default::default()
    };

    let bot_params = BotParams {
        entry_grid_double_down_factor,
        entry_grid_spacing_volatility_weight,
        entry_grid_spacing_we_weight,
        entry_grid_spacing_pct,
        entry_initial_ema_dist,
        entry_initial_qty_pct,
        entry_trailing_double_down_factor,
        entry_trailing_grid_ratio,
        entry_trailing_retracement_pct,
        entry_trailing_retracement_we_weight,
        entry_trailing_retracement_volatility_weight,
        entry_trailing_threshold_pct,
        entry_trailing_threshold_we_weight,
        entry_trailing_threshold_volatility_weight,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        ..Default::default()
    };

    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let entries = calc_entries_long(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    // Convert entries to Python-compatible format
    entries
        .into_iter()
        .map(|order| (order.qty, order.price, order.order_type.id()))
        .collect()
}

#[pyfunction]
pub fn calc_entries_short_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    entry_grid_double_down_factor: f64,
    entry_grid_spacing_volatility_weight: f64,
    entry_grid_spacing_we_weight: f64,
    entry_grid_spacing_pct: f64,
    entry_initial_ema_dist: f64,
    entry_initial_qty_pct: f64,
    entry_trailing_double_down_factor: f64,
    entry_trailing_grid_ratio: f64,
    entry_trailing_retracement_pct: f64,
    entry_trailing_retracement_we_weight: f64,
    entry_trailing_retracement_volatility_weight: f64,
    entry_trailing_threshold_pct: f64,
    entry_trailing_threshold_we_weight: f64,
    entry_trailing_threshold_volatility_weight: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    ema_bands_upper: f64,
    entry_volatility_logrange_ema_1h: f64,
    order_book_ask: f64,
) -> Vec<(f64, f64, u16)> {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };

    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            ask: order_book_ask,
            ..Default::default()
        },
        ema_bands: EMABands {
            upper: ema_bands_upper,
            ..Default::default()
        },
        entry_volatility_logrange_ema_1h,
        ..Default::default()
    };

    let bot_params = BotParams {
        entry_grid_double_down_factor,
        entry_grid_spacing_volatility_weight,
        entry_grid_spacing_we_weight,
        entry_grid_spacing_pct,
        entry_initial_ema_dist,
        entry_initial_qty_pct,
        entry_trailing_double_down_factor,
        entry_trailing_grid_ratio,
        entry_trailing_retracement_pct,
        entry_trailing_retracement_we_weight,
        entry_trailing_retracement_volatility_weight,
        entry_trailing_threshold_pct,
        entry_trailing_threshold_we_weight,
        entry_trailing_threshold_volatility_weight,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        ..Default::default()
    };

    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let entries = calc_entries_short(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    // Convert entries to Python-compatible format
    entries
        .into_iter()
        .map(|order| (order.qty, order.price, order.order_type.id()))
        .collect()
}

#[pyfunction]
pub fn calc_min_entry_qty_py(
    price: f64,
    c_mult: f64,
    qty_step: f64,
    min_qty: f64,
    min_cost: f64,
) -> f64 {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step: 0.0,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };
    crate::entries::calc_min_entry_qty(price, &exchange_params)
}

#[pyfunction]
pub fn calc_closes_long_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    close_grid_markup_end: f64,
    close_grid_markup_start: f64,
    close_grid_qty_pct: f64,
    close_trailing_grid_ratio: f64,
    close_trailing_qty_pct: f64,
    close_trailing_retracement_pct: f64,
    close_trailing_threshold_pct: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    risk_wel_enforcer_threshold: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    order_book_ask: f64,
) -> Vec<(f64, f64, u16)> {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };

    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            ask: order_book_ask,
            ..Default::default()
        },
        ..Default::default()
    };

    let bot_params = BotParams {
        close_grid_markup_end,
        close_grid_markup_start,
        close_grid_qty_pct,
        close_trailing_grid_ratio,
        close_trailing_qty_pct,
        close_trailing_retracement_pct,
        close_trailing_threshold_pct,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        risk_wel_enforcer_threshold,
        ..Default::default()
    };

    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let closes = calc_closes_long(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    // Convert closes to Python-compatible format
    closes
        .into_iter()
        .map(|order| (order.qty, order.price, order.order_type.id()))
        .collect()
}

#[pyfunction]
pub fn calc_closes_short_py(
    qty_step: f64,
    price_step: f64,
    min_qty: f64,
    min_cost: f64,
    c_mult: f64,
    close_grid_markup_end: f64,
    close_grid_markup_start: f64,
    close_grid_qty_pct: f64,
    close_trailing_grid_ratio: f64,
    close_trailing_qty_pct: f64,
    close_trailing_retracement_pct: f64,
    close_trailing_threshold_pct: f64,
    wallet_exposure_limit: f64,
    risk_we_excess_allowance_pct: f64,
    risk_wel_enforcer_threshold: f64,
    balance: f64,
    position_size: f64,
    position_price: f64,
    min_since_open: f64,
    max_since_min: f64,
    max_since_open: f64,
    min_since_max: f64,
    order_book_bid: f64,
) -> Vec<(f64, f64, u16)> {
    let exchange_params = ExchangeParams {
        qty_step,
        price_step,
        min_qty,
        min_cost,
        c_mult,
        ..Default::default()
    };

    let state_params = StateParams {
        balance,
        order_book: OrderBook {
            bid: order_book_bid,
            ..Default::default()
        },
        ..Default::default()
    };

    let bot_params = BotParams {
        close_grid_markup_end,
        close_grid_markup_start,
        close_grid_qty_pct,
        close_trailing_grid_ratio,
        close_trailing_qty_pct,
        close_trailing_retracement_pct,
        close_trailing_threshold_pct,
        wallet_exposure_limit,
        risk_we_excess_allowance_pct,
        risk_wel_enforcer_threshold,
        ..Default::default()
    };
    let position = Position {
        size: position_size,
        price: position_price,
    };
    let trailing_price_bundle = TrailingPriceBundle {
        min_since_open: min_since_open,
        max_since_min: max_since_min,
        max_since_open: max_since_open,
        min_since_max: min_since_max,
    };
    let closes = calc_closes_short(
        &exchange_params,
        &state_params,
        &bot_params,
        &position,
        &trailing_price_bundle,
    );

    // Convert closes to Python-compatible format
    closes
        .into_iter()
        .map(|order| (order.qty, order.price, order.order_type.id()))
        .collect()
}

#[pyfunction]
pub fn calc_twel_enforcer_orders_py(
    side: &str,
    red_threshold: f64,
    total_wallet_exposure_limit: f64,
    effective_n_positions: usize,
    balance: f64,
    positions: &Bound<'_, PyList>,
    skip_idx: Option<usize>,
) -> PyResult<Vec<(usize, f64, f64, u16)>> {
    let positions = positions.as_ref();
    let side_code = match side {
        "long" => LONG,
        "short" => SHORT,
        _ => {
            return Err(PyValueError::new_err(
                "side must be either 'long' or 'short'",
            ))
        }
    };
    let positions_len = positions.len()?;
    let mut parsed_positions: Vec<TwelEnforcerInputPosition> = Vec::with_capacity(positions_len);
    for item in positions.iter()? {
        let item = item?;
        let dict = item.downcast::<PyDict>()?;
        parsed_positions.push(TwelEnforcerInputPosition {
            idx: dict
                .get_item("idx")?
                .ok_or_else(|| PyValueError::new_err("twel enforcer position missing 'idx'"))?
                .extract::<usize>()?,
            position_size: dict
                .get_item("position_size")?
                .ok_or_else(|| {
                    PyValueError::new_err("twel enforcer position missing 'position_size'")
                })?
                .extract::<f64>()?,
            position_price: dict
                .get_item("position_price")?
                .ok_or_else(|| {
                    PyValueError::new_err("twel enforcer position missing 'position_price'")
                })?
                .extract::<f64>()?,
            market_price: dict
                .get_item("market_price")?
                .ok_or_else(|| {
                    PyValueError::new_err("twel enforcer position missing 'market_price'")
                })?
                .extract::<f64>()?,
            base_wallet_exposure_limit: dict
                .get_item("base_wallet_exposure_limit")?
                .ok_or_else(|| {
                    PyValueError::new_err(
                        "twel enforcer position missing 'base_wallet_exposure_limit'",
                    )
                })?
                .extract::<f64>()?,
            c_mult: dict
                .get_item("c_mult")?
                .ok_or_else(|| PyValueError::new_err("twel enforcer position missing 'c_mult'"))?
                .extract::<f64>()?,
            qty_step: dict
                .get_item("qty_step")?
                .ok_or_else(|| PyValueError::new_err("twel enforcer position missing 'qty_step'"))?
                .extract::<f64>()?,
            price_step: dict
                .get_item("price_step")?
                .ok_or_else(|| {
                    PyValueError::new_err("twel enforcer position missing 'price_step'")
                })?
                .extract::<f64>()?,
            min_qty: dict
                .get_item("min_qty")?
                .ok_or_else(|| PyValueError::new_err("twel enforcer position missing 'min_qty'"))?
                .extract::<f64>()?,
            min_cost: dict
                .get_item("min_cost")?
                .ok_or_else(|| PyValueError::new_err("twel enforcer position missing 'min_cost'"))?
                .extract::<f64>()?,
        });
    }

    let actions = calc_twel_enforcer_actions(
        side_code,
        red_threshold,
        total_wallet_exposure_limit,
        effective_n_positions,
        balance,
        &parsed_positions,
        skip_idx,
    );
    Ok(actions
        .into_iter()
        .map(|(idx, order)| (idx, order.qty, order.price, order.order_type.id()))
        .collect())
}

#[pyfunction]
pub fn order_type_id_to_snake(id: u16) -> PyResult<String> {
    let ot = OrderType::try_from(id)
        .map_err(|_| pyo3::exceptions::PyValueError::new_err("unknown order type id"))?;
    Ok(ot.to_string())
}

#[pyfunction]
pub fn all_order_types_ids(py: Python<'_>) -> PyResult<Py<PyDict>> {
    use strum::IntoEnumIterator;
    let d = PyDict::new_bound(py);
    for ot in OrderType::iter() {
        let id: u16 = ot.into();
        d.set_item(id, ot.to_string())?;
    }
    Ok(d.unbind())
}

#[pyfunction]
pub fn order_type_snake_to_id(name: &str) -> PyResult<u16> {
    OrderType::from_str(name)
        .map(|ot| ot.id())
        .map_err(|_| pyo3::exceptions::PyValueError::new_err("unknown order type name"))
}

#[pyfunction(name = "get_order_id_type_from_string")]
pub fn get_order_id_type_from_string_alias(name: &str) -> PyResult<u16> {
    order_type_snake_to_id(name)
}

// -------- Orchestrator JSON API --------

#[pyfunction]
pub fn compute_ideal_orders_json(input_json: &str) -> PyResult<String> {
    let input: crate::orchestrator::OrchestratorInput =
        serde_json::from_str(input_json).map_err(|e| {
            pyo3::exceptions::PyValueError::new_err(format!(
                "failed to parse OrchestratorInput JSON: {}",
                e
            ))
        })?;
    validate_forager_score_weights_pair(&input.global.global_bot_params)?;

    let out = crate::orchestrator::compute_ideal_orders(&input).map_err(|e| {
        pyo3::exceptions::PyValueError::new_err(format!(
            "orchestrator compute_ideal_orders failed: {:?}",
            e
        ))
    })?;

    serde_json::to_string(&out).map_err(|e| {
        pyo3::exceptions::PyValueError::new_err(format!(
            "failed to serialize OrchestratorOutput JSON: {}",
            e
        ))
    })
}
