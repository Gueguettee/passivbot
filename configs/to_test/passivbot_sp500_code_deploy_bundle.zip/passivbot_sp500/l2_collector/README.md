# `l2_collector` — live Hyperliquid l2Book recorder

A self-contained, dockerized daemon that subscribes to the **public `l2Book` WebSocket**
for one coin (default **`xyz:SP500`**, the Trade[XYZ] HIP-3 S&P 500 perp) and records every
distinct order-book snapshot into **crash-safe hourly parquet files**.

This is the forward-only, **sub-1-minute** companion to the 1-minute Reservoir archive.
Reservoir's HIP-3 L2 tops out at 1-minute cadence; the only way to get finer `xyz:SP500`
book history is to capture the live feed — which is what this does. See
[`../docs/reservoir_archive.md`](../docs/reservoir_archive.md) for the wider data landscape.

It runs **independently of the rest of the project**: its own image (no Rust, no conda, no
SDK), its own compose file, its own `data/` volume. No credentials — `l2Book` is public.
When the main repo is shared with `make_deploy_bundle.py --code-only`, this collector's
source and compose files are included, but local recorder output under `l2_collector/data/`
is intentionally excluded. A recipient's first `docker compose up -d` creates a fresh local
data volume on their host.

## Quick start

```bash
# from this folder (l2_collector/)
docker compose build
docker compose run --rm hl-l2-collector python -m pytest -q   # offline tests (no network)
docker compose up -d                                          # collect in the background
docker compose logs -f                                        # watch
docker compose down                                           # stop (resumes cleanly on next up)
```

Run it directly instead of in Docker (needs `pip install -r requirements.txt`):

```bash
DATA_DIR=./data COIN=xyz:SP500 python collector.py
```

## Output layout & schema

```
data/hyperliquid/<dex>/<base>/YYYY-MM-DD/HH.parquet      # exactly ONE file per UTC hour
data/hyperliquid/<dex>/<base>/events.jsonl               # durable start/stop/gap/reconnect ledger
data/status.json                                          # live heartbeat / counters
```

For `xyz:SP500` that's `data/hyperliquid/xyz/SP500/...`. There is **one parquet per hour**,
**updated in place** as data streams (no shard files, no sidecars). Parquet is **zstd-compressed**
internally. Schema matches the Reservoir L2 archive minus the on-chain `block_number` the live
feed has no equivalent for, plus a local receive stamp:

| column  | type                                   | meaning |
|---------|----------------------------------------|---------|
| `time_ms` | int64                                | exchange snapshot time (ms) — Reservoir's `block_time_ms` |
| `recv_ms` | int64                                | local receive time (ms), for latency/dedup analysis |
| `bids`  | list<struct<px:string, sz:string, n:int32>> | up to 20 levels; `px`/`sz` exact strings, `n` = orders at level |
| `asks`  | list<struct<px:string, sz:string, n:int32>> | up to 20 levels |

Read it back with DuckDB or pyarrow:

```python
import pyarrow.parquet as pq
pq.read_table("data/hyperliquid/xyz/SP500/2026-06-09/14.parquet").to_pylist()[:1]
# duckdb: SELECT * FROM 'data/hyperliquid/xyz/SP500/**/*.parquet' ORDER BY time_ms;
```

## Sanity behaviour

- **Levels:** stores up to **20 per side**, fewer when the book is thin (`MAX_LEVELS`).
- **One file per hour, updated in place:** the current hour's snapshots are held in memory
  (keyed by exchange `time_ms`) and the single `HH.parquet` is **atomically rewritten** (temp
  file + rename) every `FLUSH_INTERVAL`. zstd-compressed. No shard files ever.
- **Dedup by full content:** consecutive identical snapshots are dropped live, and within an hour
  rows are keyed by their full `(time_ms, levels)` signature — so exact repeats never duplicate, yet
  two genuinely *distinct* books that share a millisecond are **both kept** (every distinct snapshot
  is recorded). Only the configured coin is accepted; a frame for any other coin is dropped + counted.
- **Fail-safe on corrupt files:** an unreadable existing hour file or shard is **quarantined**
  (renamed `*.corrupt-<ns>`) and logged loudly — never silently overwritten or deleted.
- **Durable gap ledger:** start/stop/reconnect/gap events are appended to `events.jsonl` next to the
  parquet data, so backtests can see exactly where the forward-only feed has holes (Docker logs
  rotate; this file does not).
- **Staleness + reconnect:** an app-level `{"method":"ping"}` goes out every `PING_INTERVAL`;
  the server's `pong` (or any data frame) keeps the socket "fresh". A quiet book (e.g. the
  cash market is closed) is therefore **not** mistaken for a dead socket. If *no* frame
  arrives for `STALE_TIMEOUT`, the socket is force-closed and reconnected with exponential
  backoff + jitter (resets once a healthy session delivers frames). WebSocket protocol
  ping/pong is a second, independent liveness layer.
- **Resume after any stop / PC restart:** on the first snapshot of an hour the collector loads
  that hour's existing `HH.parquet` back into memory, so a restart **in the same hour
  concatenates** into the same file. A restart **in a new hour** writes a separate file and
  **leaves earlier hours untouched**. Downtime simply leaves a **hole** (missing rows) — that's
  fine and expected; gaps are logged, not hidden. At most one `FLUSH_INTERVAL` of un-flushed
  tail can be lost on a hard crash; the on-disk file is always complete. `restart:
  unless-stopped` brings the container back automatically.
- **Graceful shutdown:** SIGINT/SIGTERM write any dirty hour file and a final status, then exit.
- **Legacy migration:** if an older build left `HH/part-*.parquet` shard dirs, they are folded
  into `HH.parquet` once on startup.

## Environment variables (defaults)

| var | default | meaning |
|-----|---------|---------|
| `HL_WS_URL` | `wss://api.hyperliquid.xyz/ws` | WebSocket endpoint |
| `COIN` | `xyz:SP500` | coin to record (`dex:base`, or bare for main dex) |
| `MAX_LEVELS` | `20` | max book levels stored per side |
| `DATA_DIR` | `/app/data` | output root |
| `STATUS_PATH` | `$DATA_DIR/status.json` | heartbeat file |
| `FLUSH_INTERVAL` | `15` | seconds between in-place hour-file rewrites |
| `PING_INTERVAL` | `20` | seconds between app-level pings |
| `STALE_TIMEOUT` | `45` | no-frame seconds before forced reconnect |
| `BACKOFF_CAP` | `60` | max reconnect backoff (seconds) |

To record more coins later, run a second service with a different `COIN` (and
`container_name`) — each writes to its own coin sub-path, so they never collide.

## Files

- `collector.py` — asyncio daemon (connect → subscribe → recv → buffer → flush; signals; status).
- `l2lib.py` — pure, network-free logic (parse, dedup, hour paths, hour-file write/load,
  backoff, staleness, status, legacy-shard migration) — fully unit-tested.
- `tests/test_l2lib.py` — offline pytest suite.
