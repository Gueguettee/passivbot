"""
Offline unit tests for the Hyperliquid orderUpdates WS resubscribe fix (fixes/02).

Part of the STANDARD suite: no network, no real account, no money. The HL server periodically
closes an idle orderUpdates socket ('Expired' goodbye); the SDK does not auto-recover. The fix
detects death by SOCKET/THREAD state (never message recency -- that false signal caused an earlier
reconnect storm) via _ws_connection_dead(), and resubscribes through _subscribe_orders_ws().

The bot is built with object.__new__ (bypassing __init__/SDK construction) and only the few
attributes each method reads are stubbed, so we exercise the real methods without any I/O. The
SDK Info object is monkeypatched on the module so _subscribe_orders_ws builds a fake instead of a
real websocket. Coroutines are driven with asyncio.run (no pytest-asyncio dependency).
"""
import asyncio

import pytest

# The hyperliquid SDK is optional in this env; the module imports without it (Info is None).
from exchanges import hyperliquid as hl
from exchanges.hyperliquid import HyperliquidBot


# --------------------------------------------------------------------------- #
# Fakes mirroring the SDK chain: Info -> ws_manager (a thread) -> ws
# --------------------------------------------------------------------------- #
class _FakeWs:
    def __init__(self, keep_running=True):
        self.keep_running = keep_running


class _FakeWsManager:
    """Stand-in for the SDK WebsocketManager(threading.Thread)."""

    def __init__(self, alive=True, keep_running=True):
        self._alive = alive
        self.ws = _FakeWs(keep_running=keep_running)

    def is_alive(self):
        return self._alive


class _FakeInfo:
    """Stand-in for hyperliquid.info.Info(skip_ws=False). Records subscribe/disconnect calls."""

    instances = []

    def __init__(self, *args, **kwargs):
        self.ws_manager = _FakeWsManager(alive=True, keep_running=True)
        self.subscribed = []
        self.disconnected = False
        _FakeInfo.instances.append(self)

    def subscribe(self, sub, cb):
        self.subscribed.append((sub, cb))

    def disconnect_websocket(self):
        self.disconnected = True
        # A disconnected manager reads dead.
        self.ws_manager._alive = False
        self.ws_manager.ws.keep_running = False


def _bot(query_address="0xabc", info_ws=None, subscribed=False):
    bot = object.__new__(HyperliquidBot)
    bot.query_address = query_address
    bot.base_url = "https://example.invalid"
    bot.dex = "xyz"
    bot.info_ws = info_ws
    bot._ws_subscribed = subscribed
    bot._ws_resub_check_s = 5.0
    bot._health_ws_reconnects = 0
    # _subscribe_orders_ws builds updates -> _safe_handle_order_update; never invoked here.
    bot.hlname_to_symbol = {}
    return bot


@pytest.fixture(autouse=True)
def _patch_info(monkeypatch):
    """Point the module's Info at the fake and reset the instance log each test."""
    _FakeInfo.instances = []
    monkeypatch.setattr(hl, "Info", _FakeInfo)
    yield


def _run_subscribe(bot, force=False):
    """Drive _subscribe_orders_ws, resolving the loop INSIDE the running loop (get_running_loop
    rather than get_event_loop, which raises outside a loop on 3.10 once asyncio.run has closed
    the previous one). The loop is only used by _cb's call_soon_threadsafe, never invoked here."""
    async def _go():
        return await bot._subscribe_orders_ws(asyncio.get_running_loop(), force=force)

    return asyncio.run(_go())


# --------------------------------------------------------------------------- #
# _ws_connection_dead -- the silence-INDEPENDENT death probe
# --------------------------------------------------------------------------- #
def test_dead_false_when_not_subscribed():
    bot = _bot(subscribed=False, info_ws=_FakeInfo())
    assert bot._ws_connection_dead() is False


def test_dead_false_when_no_info_ws():
    bot = _bot(subscribed=True, info_ws=None)
    assert bot._ws_connection_dead() is False


def test_dead_false_when_no_ws_manager():
    info = _FakeInfo()
    info.ws_manager = None  # nothing to introspect -> never risk a false reconnect
    bot = _bot(subscribed=True, info_ws=info)
    assert bot._ws_connection_dead() is False


def test_dead_false_when_healthy_but_quiet():
    # alive thread + keep_running True == a healthy, idle socket -> NOT dead (the anti-storm case).
    info = _FakeInfo()
    info.ws_manager = _FakeWsManager(alive=True, keep_running=True)
    bot = _bot(subscribed=True, info_ws=info)
    assert bot._ws_connection_dead() is False


def test_dead_true_when_thread_died():
    info = _FakeInfo()
    info.ws_manager = _FakeWsManager(alive=False, keep_running=True)
    bot = _bot(subscribed=True, info_ws=info)
    assert bot._ws_connection_dead() is True


def test_dead_true_when_socket_closed():
    info = _FakeInfo()
    info.ws_manager = _FakeWsManager(alive=True, keep_running=False)
    bot = _bot(subscribed=True, info_ws=info)
    assert bot._ws_connection_dead() is True


# --------------------------------------------------------------------------- #
# _subscribe_orders_ws
# --------------------------------------------------------------------------- #
def test_subscribe_builds_one_subscription():
    bot = _bot(subscribed=False, info_ws=None)
    ok = _run_subscribe(bot)
    assert ok is True
    assert bot._ws_subscribed is True
    assert len(_FakeInfo.instances) == 1
    assert _FakeInfo.instances[0].subscribed[0][0] == {"type": "orderUpdates", "user": "0xabc"}


def test_subscribe_noop_when_already_subscribed():
    bot = _bot(subscribed=True, info_ws=_FakeInfo())
    n_before = len(_FakeInfo.instances)
    ok = _run_subscribe(bot)
    assert ok is True
    # No new Info built when already subscribed and not forced.
    assert len(_FakeInfo.instances) == n_before


def test_subscribe_no_query_address_does_not_subscribe():
    bot = _bot(query_address="", info_ws=None, subscribed=False)
    ok = _run_subscribe(bot)
    assert ok is False
    assert bot._ws_subscribed is False
    assert len(_FakeInfo.instances) == 0


def test_force_tears_down_old_info_and_rebuilds():
    old = _FakeInfo()
    bot = _bot(subscribed=True, info_ws=old)
    ok = _run_subscribe(bot, force=True)
    assert ok is True
    assert old.disconnected is True              # prior Info torn down
    assert len(_FakeInfo.instances) == 2         # old + exactly one fresh
    assert bot.info_ws is _FakeInfo.instances[-1]


def test_resubscribe_converges_no_storm():
    # A dead socket -> repair -> reads healthy again, so the watch loop goes quiet (no storm).
    dead = _FakeInfo()
    dead.ws_manager = _FakeWsManager(alive=False, keep_running=False)
    bot = _bot(subscribed=True, info_ws=dead)
    assert bot._ws_connection_dead() is True
    _run_subscribe(bot, force=True)
    assert bot._ws_connection_dead() is False


# --------------------------------------------------------------------------- #
# close() -- full teardown: disconnect the native (non-daemon) WS thread AND close ccxt sessions.
# main()'s finally now delegates shutdown to bot.close(); if it did not disconnect the SDK Info,
# the non-daemon websocket thread would survive and block clean process/container exit.
# --------------------------------------------------------------------------- #
class _FakeCcxt:
    def __init__(self):
        self.closed = False

    async def close(self):
        self.closed = True


def test_close_disconnects_ws_and_closes_sessions():
    bot = object.__new__(HyperliquidBot)
    bot.info_ws = _FakeInfo()
    bot.info = _FakeInfo()
    bot._ws_task = None
    bot._ws_subscribed = True
    bot.stop_websocket = False
    bot.maintainers = {}            # stop_data_maintainers() iterates this -> no-op
    bot.cca = _FakeCcxt()
    bot.ccp = _FakeCcxt()

    asyncio.run(bot.close())

    # Both SDK Info objects had their websocket disconnected (kills the native thread)...
    assert bot.info_ws.disconnected is True
    assert bot.info.disconnected is True
    # ...the ccxt sessions were closed (via super().close())...
    assert bot.cca.closed is True
    assert bot.ccp.closed is True
    # ...and the resubscribe loop is told to stop and not resubscribe mid-shutdown.
    assert bot.stop_websocket is True
    assert bot._ws_subscribed is False


async def _close_race_scenario():
    # Reproduce the startup/shutdown race: the watch_orders maintainer assigns a FRESH native
    # client (info_ws) during shutdown -- after close() would have captured the old/None value.
    # The fix cancels+awaits the maintainer BEFORE the disconnect loop, so the new client is
    # still disconnected. (With the old ordering it leaked: info_ws was never disconnected.)
    bot = object.__new__(HyperliquidBot)
    bot.info = _FakeInfo()          # REST client present -> close()'s disconnect loop yields
    bot.info_ws = None              # no WS client captured yet
    bot._ws_task = None
    bot._ws_subscribed = True
    bot.stop_websocket = False
    bot.cca = _FakeCcxt()
    bot.ccp = _FakeCcxt()

    async def _racing_subscribe():
        try:
            await asyncio.sleep(3600)        # idle like the resubscribe loop
        except asyncio.CancelledError:
            # Mimics the initial _subscribe_orders_ws assigning a fresh Info as the task unwinds.
            bot.info_ws = _FakeInfo()
            raise

    bot.maintainers = {"watch_orders": asyncio.create_task(_racing_subscribe())}
    await asyncio.sleep(0)          # let the task reach its sleep

    await bot.close()

    assert bot.info_ws is not None
    assert bot.info_ws.disconnected is True   # the racing client was disconnected, not leaked


def test_close_disconnects_ws_assigned_during_shutdown_race():
    asyncio.run(_close_race_scenario())


def test_subscribe_is_noop_once_stopping():
    # Once shutdown has begun, _subscribe_orders_ws must build no new native client.
    bot = _bot(subscribed=False, info_ws=None)
    bot.stop_websocket = True
    n_before = len(_FakeInfo.instances)
    ok = _run_subscribe(bot)
    assert ok is False
    assert bot._ws_subscribed is False
    assert len(_FakeInfo.instances) == n_before
