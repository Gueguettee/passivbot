"""
Offline unit tests for the churn-breaker trading gate (_apply_churn_breaker_modes) and the
anti-ping-pong re-entry cooldown (_symbols_in_reentry_cooldown).

Part of the STANDARD suite: no network, no real account, no money. The churn breaker downgrades
every entry-permitting symbol (mode 'normal'/'graceful_stop') to 'tp_only' and LATCHES (no
auto-recovery this process lifetime) when the number of exchange-confirmed fills (self.pnls,
refreshed from REST every cycle) inside the rolling window reaches the configured maximum.
Motivation: the Jun 7 2026 episode -- 851 alternating taker fills in ~2 h (-$4.06, almost all
fees) with no bot-side guard (runs/forensics/jun7_churn_postmortem.md).

The bot is built with object.__new__ (bypassing __init__/SDK construction) and only the few
attributes the gate reads are stubbed (config, PB_modes, pnls, get_exchange_time), so we exercise
the real methods without any I/O. Both are synchronous, so no asyncio is needed.
"""
import logging

import pytest

from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"
NOW_MS = 1_781_000_000_000


# --------------------------------------------------------------------------- #
# Builders
# --------------------------------------------------------------------------- #
def _fill(age_s, side="buy", position_side="long", symbol=SYMBOL):
    return {
        "id": f"{age_s}-{side}",
        "symbol": symbol,
        "timestamp": NOW_MS - int(age_s * 1000),
        "side": side,
        "position_side": position_side,
        "pnl": 0.0,
    }


def _gate_bot(modes, fills, *, enabled=True, max_fills=10, window_min=10.0, tripped=False):
    """A Passivbot with __init__ bypassed, stubbing only what _apply_churn_breaker_modes /
    _churn_breaker_cfg / _count_recent_fills read."""
    bot = object.__new__(Passivbot)
    bot.PB_modes = modes
    bot.pnls = sorted(fills, key=lambda x: x["timestamp"])
    bot.get_exchange_time = lambda: NOW_MS
    bot._churn_breaker_tripped = tripped
    bot._churn_trip_fill_count = 0
    bot.config = {
        "live": {
            "churn_breaker_enforcement": enabled,
            "churn_breaker_max_fills": max_fills,
            "churn_breaker_window_minutes": window_min,
        }
    }
    return bot


def _both(longmode, shortmode=None):
    return {"long": {SYMBOL: longmode}, "short": {SYMBOL: shortmode or longmode}}


# --------------------------------------------------------------------------- #
# _churn_breaker_cfg defaults / parsing
# --------------------------------------------------------------------------- #
def test_cfg_defaults():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {}}
    assert bot._churn_breaker_cfg() == (True, 10, 10.0)


def test_cfg_string_false_disables():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"churn_breaker_enforcement": "false"}}
    enabled, _, _ = bot._churn_breaker_cfg()
    assert enabled is False


def test_cfg_clamps_degenerate_values():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"churn_breaker_max_fills": 0, "churn_breaker_window_minutes": 0}}
    assert bot._churn_breaker_cfg() == (True, 2, 1.0)


# --------------------------------------------------------------------------- #
# Fill counting
# --------------------------------------------------------------------------- #
def test_count_recent_fills_window():
    fills = [_fill(30), _fill(120), _fill(700)]  # 700 s is outside a 10 min window
    bot = _gate_bot(_both("normal"), fills)
    assert bot._count_recent_fills(600_000.0) == 2


# --------------------------------------------------------------------------- #
# Gate behavior
# --------------------------------------------------------------------------- #
def test_below_threshold_modes_unchanged():
    bot = _gate_bot(_both("normal", "graceful_stop"), [_fill(i) for i in range(9)], max_fills=10)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes == _both("normal", "graceful_stop")
    assert bot._churn_breaker_tripped is False


def test_at_threshold_trips_both_psides():
    bot = _gate_bot(_both("normal", "graceful_stop"), [_fill(i) for i in range(10)], max_fills=10)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["short"][SYMBOL] == "tp_only"
    assert bot._churn_breaker_tripped is True
    assert bot._churn_trip_fill_count == 10


def test_latch_holds_after_window_drains():
    # Tripped earlier; the window is now EMPTY -- the latch must keep forcing tp_only.
    bot = _gate_bot(_both("normal"), fills=[], tripped=True)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["short"][SYMBOL] == "tp_only"
    assert bot._churn_breaker_tripped is True


def test_protected_modes_untouched():
    modes = {"long": {SYMBOL: "manual"}, "short": {SYMBOL: "panic"}}
    bot = _gate_bot(modes, [_fill(i) for i in range(50)], max_fills=10)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes["long"][SYMBOL] == "manual"
    assert bot.PB_modes["short"][SYMBOL] == "panic"


def test_disabled_is_noop():
    bot = _gate_bot(_both("normal"), [_fill(i) for i in range(50)], enabled=False)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes == _both("normal")
    assert bot._churn_breaker_tripped is False


def test_warns_once_on_trip(caplog):
    bot = _gate_bot(_both("normal"), [_fill(i) for i in range(10)], max_fills=10)
    with caplog.at_level(logging.WARNING):
        bot._apply_churn_breaker_modes()  # trips: one warning
        bot._apply_churn_breaker_modes()  # already latched: no new warning
    warnings = [r for r in caplog.records if "[churn]" in r.getMessage()]
    assert len(warnings) == 1
    assert "LATCHING" in warnings[0].getMessage()


def test_old_fills_outside_window_do_not_trip():
    # 50 fills, all older than the window.
    bot = _gate_bot(_both("normal"), [_fill(700 + i) for i in range(50)], max_fills=10)
    bot._apply_churn_breaker_modes()
    assert bot.PB_modes == _both("normal")
    assert bot._churn_breaker_tripped is False


# --------------------------------------------------------------------------- #
# Re-entry cooldown
# --------------------------------------------------------------------------- #
def _cooldown_bot(fills, *, seconds=60.0):
    bot = object.__new__(Passivbot)
    bot.pnls = sorted(fills, key=lambda x: x["timestamp"])
    bot.get_exchange_time = lambda: NOW_MS
    bot.config = {"live": {"reentry_cooldown_seconds": seconds}}
    return bot


def test_recent_close_fill_puts_symbol_in_cooldown():
    # sell on a long position = close fill
    bot = _cooldown_bot([_fill(10, side="sell", position_side="long")])
    assert bot._symbols_in_reentry_cooldown() == {SYMBOL}


def test_short_close_is_buy():
    bot = _cooldown_bot([_fill(10, side="buy", position_side="short")])
    assert bot._symbols_in_reentry_cooldown() == {SYMBOL}


def test_entry_fill_does_not_trigger_cooldown():
    # buy on a long position = entry fill, no cooldown
    bot = _cooldown_bot([_fill(10, side="buy", position_side="long")])
    assert bot._symbols_in_reentry_cooldown() == set()


def test_old_close_fill_expires():
    bot = _cooldown_bot([_fill(120, side="sell", position_side="long")], seconds=60.0)
    assert bot._symbols_in_reentry_cooldown() == set()


def test_zero_seconds_disables_cooldown():
    bot = _cooldown_bot([_fill(1, side="sell", position_side="long")], seconds=0.0)
    assert bot._symbols_in_reentry_cooldown() == set()
