"""
Offline unit tests for the hard minimum-capital floor on the live xyz/stock bot.

Part of the STANDARD suite: no network, no real account, no money. The bot is built with
object.__new__ (bypassing __init__/SDK construction) and only the attributes each method reads
are stubbed, so we exercise the real Passivbot logic. Async methods are driven with asyncio.run
(no pytest-asyncio dependency).

Covers:
  - _min_capital_floors: the (hard_floor, recommended_floor) math.
  - _apply_min_capital_modes: per-cycle downgrade of entry-permitting modes ('normal' or
    'graceful_stop') -> 'tp_only' below the enforced threshold (recommended + margin), leaving
    non-entry modes and well-funded coins alone. tp_only (not graceful_stop) is required because
    the Rust orchestrator treats graceful_stop WITH an open position as normal, so graceful_stop
    does not actually block DCA -- only tp_only blocks all entries regardless of position.
  - _refuse_start_if_undercapitalized: startup hard gate, with the open-position carve-out.
"""
import asyncio

from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"

# SP500 == NVDA config params; effective_min_cost floored at $10.
# denom = wel*allowance*eiqp = 2.0 * 1.43598 * 0.11971 = 0.343802
# hard_floor = 10/denom = 29.09 ; recommended = hard_floor/cgqp = 29.09/0.37823 = 76.90
# enforced (margin 15%) = 76.90 * 1.15 = 88.43
EXPECT_HARD = 29.09
EXPECT_REC = 76.90
EXPECT_ENFORCED_15 = 88.43


def _bot(balance=50.0, modes=None, enforcement=True, margin=0.15, has_pos=False, emc=10.0):
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"min_capital_enforcement": enforcement, "min_capital_margin_pct": margin}}
    bot.balance = balance
    bot.effective_min_cost = {SYMBOL: emc}
    bot.get_wallet_exposure_limit = lambda pside, symbol=None: 2.0
    bot.bp = lambda pside, key, symbol=None: {
        "risk_we_excess_allowance_pct": 0.43598,
        "entry_initial_qty_pct": 0.11971,
        "close_grid_qty_pct": 0.37823,
    }.get(key, 0.0)
    bot.PB_modes = modes if modes is not None else {"long": {SYMBOL: "normal"}, "short": {}}
    bot.is_pside_enabled = lambda pside: pside == "long"
    bot.approved_coins_minus_ignored_coins = {"long": [SYMBOL], "short": []}
    bot.has_position = lambda pside, symbol: has_pos
    bot.stop_signal_received = False
    return bot


# --------------------------------------------------------------------------- #
# Floor math
# --------------------------------------------------------------------------- #
def test_min_capital_floors_values():
    hard, rec = _bot()._min_capital_floors("long", SYMBOL)
    assert abs(hard - EXPECT_HARD) < 0.1
    assert abs(rec - EXPECT_REC) < 0.2


def test_min_capital_floors_not_computable_returns_zero():
    # No effective min cost yet -> not computable -> (0, 0) (treated as "no constraint").
    assert _bot(emc=0.0)._min_capital_floors("long", SYMBOL) == (0.0, 0.0)


def test_threshold_applies_margin():
    assert abs(_bot(margin=0.15)._min_capital_threshold("long", SYMBOL) - EXPECT_ENFORCED_15) < 0.3
    # 0% margin -> threshold equals the recommended floor.
    assert abs(_bot(margin=0.0)._min_capital_threshold("long", SYMBOL) - EXPECT_REC) < 0.2


# --------------------------------------------------------------------------- #
# Per-cycle enforcement
# --------------------------------------------------------------------------- #
def test_apply_below_threshold_downgrades_to_tp_only():
    bot = _bot(balance=50.0)
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"


def test_apply_uses_account_equity_for_risk_when_available():
    bot = _bot(balance=200.0)
    bot.account_equity = 50.0
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot._capital_status()["risk_capital_source"] == "account_equity"


def test_apply_within_margin_band_still_blocked():
    # $80 is above recommended ($77) but below enforced ($88) -> the margin must still block it.
    bot = _bot(balance=80.0, margin=0.15)
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"


def test_apply_above_threshold_stays_normal():
    bot = _bot(balance=120.0)
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "normal"


def test_apply_graceful_stop_is_upgraded_to_tp_only():
    # graceful_stop does NOT block DCA on an open position, so an undercapitalized graceful_stop
    # symbol must be upgraded to tp_only; truly-no-entry modes (tp_only/manual) stay put.
    modes = {"long": {SYMBOL: "graceful_stop", "X/USDC:USDC": "tp_only", "M/USDC:USDC": "manual"}, "short": {}}
    bot = _bot(balance=1.0, modes=modes)
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["long"]["X/USDC:USDC"] == "tp_only"
    assert bot.PB_modes["long"]["M/USDC:USDC"] == "manual"


def test_apply_disabled_does_not_downgrade():
    bot = _bot(balance=1.0, enforcement=False)
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "normal"


def test_apply_string_false_disables():
    # A string "false" override must disable the gate (bool("false") is True -- the bug).
    bot = _bot(balance=1.0, enforcement="false")
    assert bot._min_capital_cfg()[0] is False
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "normal"


def test_apply_string_true_enables():
    bot = _bot(balance=1.0, enforcement="true")
    assert bot._min_capital_cfg()[0] is True
    bot._apply_min_capital_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"


def test_enforcement_flag_parsing():
    # JSON bool, string tokens, and absent all resolve correctly.
    assert _bot(enforcement=True)._min_capital_cfg()[0] is True
    assert _bot(enforcement=False)._min_capital_cfg()[0] is False
    assert _bot(enforcement="0")._min_capital_cfg()[0] is False
    assert _bot(enforcement="no")._min_capital_cfg()[0] is False
    assert _bot(enforcement="off")._min_capital_cfg()[0] is False
    assert _bot(enforcement="1")._min_capital_cfg()[0] is True
    assert _bot(enforcement="yes")._min_capital_cfg()[0] is True


# --------------------------------------------------------------------------- #
# Startup refuse-to-start gate
# --------------------------------------------------------------------------- #
def test_refuse_when_below_and_no_position():
    bot = _bot(balance=50.0, has_pos=False)
    ok = asyncio.run(bot._refuse_start_if_undercapitalized())
    assert ok is False
    assert bot.stop_signal_received is True
    assert bot._shutdown_reason == "startup_refused_undercapitalized"


def test_refuse_uses_account_equity_for_risk_when_available():
    bot = _bot(balance=200.0, has_pos=False)
    bot.account_equity = 50.0
    ok = asyncio.run(bot._refuse_start_if_undercapitalized())
    assert ok is False
    assert bot.stop_signal_received is True


def test_allow_when_below_but_position_open():
    # An open position must still be managed/closed -> start is allowed (tp_only handles it).
    bot = _bot(balance=50.0, has_pos=True)
    ok = asyncio.run(bot._refuse_start_if_undercapitalized())
    assert ok is True
    assert bot.stop_signal_received is False


def test_allow_when_sufficiently_funded():
    bot = _bot(balance=120.0, has_pos=False)
    ok = asyncio.run(bot._refuse_start_if_undercapitalized())
    assert ok is True
    assert bot.stop_signal_received is False


def test_refuse_disabled_always_allows():
    bot = _bot(balance=1.0, has_pos=False, enforcement=False)
    ok = asyncio.run(bot._refuse_start_if_undercapitalized())
    assert ok is True
    assert bot.stop_signal_received is False
