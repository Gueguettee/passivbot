"""
Offline unit tests for the transient-MissingEma guard on low-volume xyz/stock markets.

Part of the STANDARD suite: no network, no real account, no money. On a no-trade minute the
candle manager synthesizes a zero-volume candle; when real data backfills it invalidates the
EMA cache, and a candle read in that brief window can return an empty range -> NaN close-EMAs
-> the Rust orchestrator raises MissingEma. `_load_orchestrator_ema_bundle` re-fetches the
mandatory close spans once for any symbol that came back empty (first line of defense); a
residual miss is converted to the typed, benign `TransientEmaUnavailable` so the live loop
skips the cycle instead of logging a hard error.

The bot is built with object.__new__ (bypassing __init__/SDK construction) and only the few
attributes `_load_orchestrator_ema_bundle` reads are stubbed, so we exercise the real method
without any I/O. The coroutine is driven with asyncio.run() (no pytest-asyncio dependency).
"""
import asyncio
import math

import passivbot as passivbot_module
import pytest

from passivbot import (
    Passivbot,
    TransientEmaUnavailable,
    _is_missing_ema_error,
    _symbols_missing_close_emas,
)

SYMBOL = "SP500/USDC:USDC"


# --------------------------------------------------------------------------- #
# Fixtures / builders
# --------------------------------------------------------------------------- #
class _FakeCM:
    """Minimal candle-manager stub. Counts close-EMA fetches per span so tests can assert how
    many times each span was read. `mode` controls what the close-EMA read returns:
      - "recover"      : NaN on the FIRST call per span, finite after (the real race)
      - "always_finite": finite immediately (EMAs ready first try -> no retry)
      - "always_nan"   : NaN forever (a genuine longer gap -> retry can't help)
    Volume / log-range reads always return finite values (only close-EMAs trigger the guard).
    """

    def __init__(self, mode="recover"):
        self.mode = mode
        self.close_calls: dict[float, int] = {}

    async def get_latest_ema_close(self, symbol, span, max_age_ms=0):
        n = self.close_calls.get(span, 0)
        self.close_calls[span] = n + 1
        if self.mode == "always_finite":
            return 100.0 + span
        if self.mode == "always_nan":
            return float("nan")
        # "recover": empty range (NaN) the first time this span is read, finite afterwards.
        return float("nan") if n == 0 else 100.0 + span

    async def get_latest_ema_quote_volume(self, symbol, span, max_age_ms=0):
        return 1000.0

    async def get_latest_ema_log_range(self, symbol, span, max_age_ms=0, tf="1m"):
        return 0.01


def _bundle_bot(cm):
    """A Passivbot with __init__ bypassed, stubbing only the attributes
    _load_orchestrator_ema_bundle reads. `_pb_mode_to_orchestrator_mode` returns a non-manual
    mode so close-EMAs are REQUIRED for the symbol (otherwise the method would skip it)."""
    bot = object.__new__(Passivbot)
    bot.cm = cm
    bot._ema_recompute_retry_delay_s = 0.0  # no real sleep in the retry path
    bot._pb_mode_to_orchestrator_mode = lambda mode: "normal"
    bot.has_position = lambda pside, symbol: False

    def bp(pside, key, symbol):
        return {
            "ema_span_0": 100.0,
            "ema_span_1": 400.0,  # span2 = sqrt(100*400) = 200 -> three close spans
            "entry_volatility_ema_span_hours": 24.0,
        }.get(key, 0.0)

    def bot_value(side, key):
        return {"filter_volume_ema_span": 50.0, "filter_volatility_ema_span": 60.0}.get(key, 0.0)

    bot.bp = bp
    bot.bot_value = bot_value
    return bot


def _load_bundle(cm):
    bot = _bundle_bot(cm)
    modes = {"long": {SYMBOL: "normal"}, "short": {SYMBOL: "normal"}}
    result = asyncio.run(bot._load_orchestrator_ema_bundle([SYMBOL], modes))
    m1_close_emas = result[0]
    return m1_close_emas, cm


def _snapshot_bot():
    bot = object.__new__(Passivbot)
    bot.balance = 1000.0
    bot._config_hedge_mode = False
    bot.hedge_mode = False
    bot.markets_dict = {SYMBOL: {"active": True}}
    bot.effective_min_cost = {SYMBOL: 10.0}
    bot.qty_steps = {SYMBOL: 0.01}
    bot.price_steps = {SYMBOL: 0.1}
    bot.min_qtys = {SYMBOL: 0.01}
    bot.min_costs = {SYMBOL: 10.0}
    bot.c_mults = {SYMBOL: 1.0}
    bot.PB_modes = {"long": {SYMBOL: "normal"}, "short": {SYMBOL: "manual"}}
    bot.positions = {
        SYMBOL: {
            "long": {"size": 0.0, "price": 0.0},
            "short": {"size": 0.0, "price": 0.0},
        }
    }
    bot.trailing_prices = {
        SYMBOL: {
            "long": {
                "min_since_open": 0.0,
                "max_since_min": 0.0,
                "max_since_open": 0.0,
                "min_since_max": 0.0,
            },
            "short": {
                "min_since_open": 0.0,
                "max_since_min": 0.0,
                "max_since_open": 0.0,
                "min_since_max": 0.0,
            },
        }
    }
    bot.live_value = lambda key: True if key == "filter_by_min_effective_cost" else None
    bot._bot_params_to_rust_dict = lambda pside, symbol: {}
    bot._pb_mode_to_orchestrator_mode = lambda mode: mode
    return bot


def _orchestrator_snapshot():
    return {
        "symbols": [SYMBOL],
        "last_prices": {SYMBOL: 100.0},
        "m1_close_emas": {SYMBOL: {100.0: 100.0}},
        "m1_volume_emas": {SYMBOL: {50.0: 1000.0}},
        "m1_log_range_emas": {SYMBOL: {60.0: 0.01}},
        "h1_log_range_emas": {SYMBOL: {24.0: 0.01}},
        "unstuck_allowances": {"long": 0.0, "short": 0.0},
    }


# --------------------------------------------------------------------------- #
# Error classifier / typed exception
# --------------------------------------------------------------------------- #
def test_is_missing_ema_error_true_for_value_error_with_text():
    assert _is_missing_ema_error(
        ValueError("orchestrator compute_ideal_orders failed: MissingEma { symbol_idx: 0 }")
    ) is True


def test_is_missing_ema_error_false_for_wrong_type_or_text():
    # Right text, wrong type -> False (we never swallow an unrelated error that mentions it).
    assert _is_missing_ema_error(RuntimeError("MissingEma { symbol_idx: 0 }")) is False
    assert _is_missing_ema_error(Exception("MissingEma")) is False
    # A genuine, unrelated ValueError -> False.
    assert _is_missing_ema_error(ValueError("some other failure")) is False


def test_transient_ema_unavailable_not_value_error():
    # MUST NOT subclass ValueError, or the loop's except-paths would swallow it before our
    # typed handler runs.
    assert not issubclass(TransientEmaUnavailable, ValueError)
    assert isinstance(TransientEmaUnavailable("x"), Exception)


# --------------------------------------------------------------------------- #
# Missing-symbol detector
# --------------------------------------------------------------------------- #
def test_symbols_missing_close_emas_flags_only_need_but_empty():
    symbols = ["A", "B", "C"]
    need = {"A": {100.0}, "B": {100.0}, "C": set()}
    close = {"A": {}, "B": {100.0: 1.0}, "C": {}}
    # A needs spans but came back empty -> flagged; B needs and is populated -> not; C does not
    # need close-EMAs at all -> not.
    assert _symbols_missing_close_emas(symbols, need, close) == ["A"]


# --------------------------------------------------------------------------- #
# _load_orchestrator_ema_bundle retry behavior
# --------------------------------------------------------------------------- #
def test_bundle_recovers_after_one_retry():
    m1_close_emas, cm = _load_bundle(_FakeCM(mode="recover"))
    # Three close spans (100, 200, 400), each read twice: initial NaN (dropped) + retry finite.
    assert len(cm.close_calls) == 3
    assert all(count == 2 for count in cm.close_calls.values())
    # After the single retry the close-EMA map is populated for all three spans.
    assert set(m1_close_emas[SYMBOL].keys()) == {100.0, 200.0, 400.0}
    assert all(math.isfinite(v) for v in m1_close_emas[SYMBOL].values())


def test_bundle_no_retry_when_present_first_try():
    m1_close_emas, cm = _load_bundle(_FakeCM(mode="always_finite"))
    # EMAs ready immediately -> no symbol flagged -> no retry -> each span read exactly once.
    assert len(cm.close_calls) == 3
    assert all(count == 1 for count in cm.close_calls.values())
    assert set(m1_close_emas[SYMBOL].keys()) == {100.0, 200.0, 400.0}


def test_bundle_persistent_miss_empty_after_two_attempts():
    m1_close_emas, cm = _load_bundle(_FakeCM(mode="always_nan"))
    # A genuine gap: retry can't help -> map stays empty after exactly two attempts
    # (initial + one retry) per span, so the 3e/3f backstop handles it downstream.
    assert m1_close_emas[SYMBOL] == {}
    assert len(cm.close_calls) == 3
    assert all(count == 2 for count in cm.close_calls.values())


# --------------------------------------------------------------------------- #
# Snapshot replay helper parity
# --------------------------------------------------------------------------- #
def test_snapshot_helper_converts_missing_ema_value_error(monkeypatch):
    def raise_missing_ema(_payload):
        raise ValueError("orchestrator compute_ideal_orders failed: MissingEma { symbol_idx: 0 }")

    monkeypatch.setattr(passivbot_module.pbr, "compute_ideal_orders_json", raise_missing_ema)

    with pytest.raises(TransientEmaUnavailable):
        asyncio.run(
            _snapshot_bot().calc_ideal_orders_orchestrator_from_snapshot(
                _orchestrator_snapshot(), return_snapshot=False
            )
        )


def test_snapshot_helper_preserves_unrelated_value_error(monkeypatch):
    def raise_other_value_error(_payload):
        raise ValueError("some other orchestrator failure")

    monkeypatch.setattr(passivbot_module.pbr, "compute_ideal_orders_json", raise_other_value_error)

    with pytest.raises(ValueError, match="some other orchestrator failure"):
        asyncio.run(
            _snapshot_bot().calc_ideal_orders_orchestrator_from_snapshot(
                _orchestrator_snapshot(), return_snapshot=False
            )
        )
