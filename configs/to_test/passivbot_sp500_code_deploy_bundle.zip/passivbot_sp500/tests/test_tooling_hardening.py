from concurrent.futures import ThreadPoolExecutor

from fill_events_manager import RateLimitCoordinator
from tools.hyperliquid_archive_downloader import _sql_literal


def test_rate_limit_record_call_preserves_concurrent_updates(tmp_path):
    endpoint = "fetch_my_trades"

    def record(i):
        coordinator = RateLimitCoordinator(
            "hyperliquid",
            f"user_{i}",
            temp_dir=tmp_path,
            limits={endpoint: 100, "default": 100},
        )
        coordinator.record_call(endpoint)

    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(record, range(20)))

    coordinator = RateLimitCoordinator(
        "hyperliquid",
        "reader",
        temp_dir=tmp_path,
        limits={endpoint: 100, "default": 100},
    )

    assert coordinator.get_current_usage(endpoint) == 20


def test_duckdb_secret_sql_literal_escapes_single_quotes():
    assert _sql_literal("abc'def") == "abc''def"
