"""
Offline unit tests for the xyz-specific glue the LIVE ENGINE depends on.

Part of the STANDARD suite: no network, no real account, no money. The bot is built with
object.__new__ (bypassing __init__/SDK construction) and only the attributes each method
reads are set, so we test the real HyperliquidBot logic without any I/O.

Covers the surfaces the engine loop relies on for xyz:SP500 that differ from a normal
crypto perp:
  - symbol/coin/hlname mapping (the "xyz:" prefix)
  - per-symbol spec parsing (qty/price step, min cost, max leverage)
  - ISOLATED-margin enforcement (Hyperliquid HIP-3 is isolated-only)
  - price/size rounding to the xyz tick
  - single-asset enforcement
"""
import asyncio

import pytest

from exchanges.hyperliquid import HyperliquidBot
from config_utils import _enforce_single_asset


# --------------------------------------------------------------------------- #
# Fixtures / builders
# --------------------------------------------------------------------------- #
def _xyz_market_dict(coin, sz_dec=3, max_lev=20, only_isolated=False):
    """Mirror the market dict HyperliquidBot.init_markets() builds for an xyz asset."""
    hlname = f"xyz:{coin}"
    symbol = f"{coin}/USDC:USDC"
    max_dec = 6
    price_tick = 10 ** -(max_dec - sz_dec) if (max_dec - sz_dec) > 0 else 1.0
    amount_tick = 10 ** -sz_dec
    return symbol, hlname, {
        "symbol": symbol,
        "id": hlname,
        "base": coin,
        "quote": "USDC",
        "active": True,
        "swap": True,
        "linear": True,
        "type": "swap",
        "precision": {"amount": amount_tick, "price": price_tick},
        "limits": {"amount": {"min": amount_tick}, "cost": {"min": 10.0}},
        "maker": 0.0002,
        "taker": 0.0005,
        "contractSize": 1.0,
        "info": {"name": hlname, "szDecimals": sz_dec, "maxLeverage": max_lev,
                 "onlyIsolated": only_isolated},
    }


def _bare_bot(coins=(("SP500", 3, 20), ("NVDA", 3, 10))):
    """A HyperliquidBot instance with __init__ bypassed and only the mapping/spec state set,
    exactly as init_markets() would populate it for the given coins."""
    bot = object.__new__(HyperliquidBot)
    bot.quote = "USDC"
    bot.dex = "xyz"
    bot.symbol_to_hlname = {}
    bot.hlname_to_symbol = {}
    bot.coin_to_symbol_map = {}
    bot.symbol_to_coin_map = {}
    bot.sz_decimals = {}
    bot.markets_dict = {}
    for coin, sz_dec, max_lev in coins:
        symbol, hlname, md = _xyz_market_dict(coin, sz_dec=sz_dec, max_lev=max_lev)
        bot.symbol_to_hlname[symbol] = hlname
        bot.hlname_to_symbol[hlname] = symbol
        bot.coin_to_symbol_map[coin.upper()] = symbol
        bot.symbol_to_coin_map[symbol] = coin.upper()
        bot.sz_decimals[symbol] = sz_dec
        bot.markets_dict[symbol] = md
    return bot


# --------------------------------------------------------------------------- #
# Symbol / coin / hlname mapping (the xyz: prefix the whole loop relies on)
# --------------------------------------------------------------------------- #
def test_coin_to_symbol_roundtrip():
    bot = _bare_bot()
    assert bot.coin_to_symbol("SP500") == "SP500/USDC:USDC"
    assert bot.coin_to_symbol("sp500") == "SP500/USDC:USDC"   # case-insensitive
    assert bot.symbol_to_coin("SP500/USDC:USDC") == "SP500"
    assert bot._hlname("SP500/USDC:USDC") == "xyz:SP500"
    assert bot.coin_to_symbol("NVDA") == "NVDA/USDC:USDC"
    assert bot._hlname("NVDA/USDC:USDC") == "xyz:NVDA"


def test_coin_to_symbol_unknown_returns_empty():
    bot = _bare_bot()
    assert bot.coin_to_symbol("DOESNOTEXIST", verbose=False) == ""


def test_symbol_to_coin_strips_dex_prefix_for_unmapped():
    bot = _bare_bot()
    # not in the map -> parse from the symbol string, stripping a leading "dex:" on the base
    assert bot.symbol_to_coin("xyz:FOO/USDC:USDC") == "FOO"


# --------------------------------------------------------------------------- #
# Per-symbol spec parsing
# --------------------------------------------------------------------------- #
def test_set_market_specific_settings_parses_xyz_specs():
    bot = _bare_bot(coins=(("SP500", 3, 20), ("NVDA", 3, 10)))
    # dicts the override writes into must pre-exist (base __init__ normally makes them)
    bot.min_costs = {}
    bot.qty_steps = {}
    bot.min_qtys = {}
    bot.price_steps = {}
    bot.c_mults = {}
    bot.max_leverage = {}

    bot.set_market_specific_settings()

    sp = "SP500/USDC:USDC"
    assert bot.min_costs[sp] == 10.0
    assert bot.qty_steps[sp] == pytest.approx(0.001)      # 10**-szDec (szDec=3)
    assert bot.min_qtys[sp] == pytest.approx(0.001)
    assert bot.price_steps[sp] == pytest.approx(0.001)    # 10**-(6-szDec)
    assert bot.c_mults[sp] == 1.0
    assert bot.max_leverage[sp] == 20
    assert bot.max_leverage["NVDA/USDC:USDC"] == 10
    # symbol_ids populated by the base method
    assert bot.symbol_ids[sp] == "xyz:SP500"


# --------------------------------------------------------------------------- #
# ISOLATED-margin enforcement (Hyperliquid HIP-3 is isolated-only)
# --------------------------------------------------------------------------- #
class _RecordingExchange:
    """Stand-in for the SDK Exchange: records update_leverage(name, leverage, is_cross)."""
    def __init__(self):
        self.calls = []

    def update_leverage(self, leverage, name, is_cross):
        self.calls.append({"leverage": leverage, "name": name, "is_cross": is_cross})
        return {"status": "ok"}


def test_update_exchange_config_by_symbols_sets_isolated():
    bot = _bare_bot(coins=(("SP500", 3, 20),))
    bot.hl_exchange = _RecordingExchange()
    bot.max_leverage = {"SP500/USDC:USDC": 20}
    # live.leverage = 10 in the config; config_get is what the method consults.
    bot.config_get = lambda path, symbol=None: 10

    asyncio.run(bot.update_exchange_config_by_symbols(["SP500/USDC:USDC"]))

    assert len(bot.hl_exchange.calls) == 1
    call = bot.hl_exchange.calls[0]
    # the 3rd positional arg to update_leverage is is_cross -> MUST be False (isolated)
    assert call["is_cross"] is False
    assert call["name"] == "xyz:SP500"
    assert call["leverage"] == 10            # min(max_leverage=20, live.leverage=10)


def test_update_exchange_config_caps_leverage_at_market_max():
    bot = _bare_bot(coins=(("SP500", 3, 5),))   # market max leverage = 5
    bot.hl_exchange = _RecordingExchange()
    bot.max_leverage = {"SP500/USDC:USDC": 5}
    bot.config_get = lambda path, symbol=None: 10   # request 10x but market only allows 5x

    asyncio.run(bot.update_exchange_config_by_symbols(["SP500/USDC:USDC"]))

    assert bot.hl_exchange.calls[0]["leverage"] == 5
    assert bot.hl_exchange.calls[0]["is_cross"] is False


# --------------------------------------------------------------------------- #
# Price / size rounding to the xyz tick
# --------------------------------------------------------------------------- #
def test_round_size_floors_to_step():
    bot = _bare_bot()
    sym = "SP500/USDC:USDC"          # szDec=3 -> step 0.001
    assert bot._round_size(0.0019, sym) == pytest.approx(0.001)
    assert bot._round_size(0.002, sym) == pytest.approx(0.002)
    assert bot._round_size(0.0025, sym) == pytest.approx(0.002)


def test_round_price_respects_sig_figs_and_decimals():
    bot = _bare_bot()
    sym = "SP500/USDC:USDC"          # szDec=3 -> <=5 sig figs, <=3 decimals
    # 7403.126 -> 5 sig figs -> 7403.1
    assert bot._round_price(7403.126, sym) == pytest.approx(7403.1)
    # a 2nd-market-scale price stays within its precision
    assert bot._round_price(206.37, sym) == pytest.approx(206.37)
    # non-positive prices pass through
    assert bot._round_price(0, sym) == 0


# --------------------------------------------------------------------------- #
# Single-asset enforcement (this bundle trades exactly one coin)
# --------------------------------------------------------------------------- #
def test_single_asset_enforcement_allows_one_coin():
    cfg = {"live": {"approved_coins": {"long": ["SP500"], "short": []}},
           "backtest": {"coins": {"hyperliquid": ["SP500"]}}}
    _enforce_single_asset(cfg)   # must not raise


def test_single_asset_enforcement_rejects_two_coins():
    cfg = {"live": {"approved_coins": {"long": ["SP500", "NVDA"], "short": []}}}
    with pytest.raises(ValueError):
        _enforce_single_asset(cfg)


# --------------------------------------------------------------------------- #
# Account equity / sizing-balance split
# --------------------------------------------------------------------------- #
def test_parse_account_state_splits_equity_wallet_balance_and_margin():
    state = {
        "marginSummary": {
            "accountValue": "299.5",
            "withdrawable": "250.25",
        },
        "assetPositions": [
            {"position": {"unrealizedPnl": "-10.0"}},
            {"position": {"unrealizedPnl": "2.5"}},
        ],
    }

    parsed = HyperliquidBot._parse_account_state(state)

    assert parsed["account_equity_for_risk"] == pytest.approx(299.5)
    assert parsed["unrealized_pnl"] == pytest.approx(-7.5)
    assert parsed["wallet_balance_for_sizing"] == pytest.approx(307.0)
    assert parsed["available_margin"] == pytest.approx(250.25)


def test_parse_account_state_rejects_non_finite_account_value():
    # A missing/garbage accountValue must RAISE (caller keeps the previous balance), never
    # coerce to 0.0: a phantom zero balance makes wallet exposure explode and can arm the
    # loss-closing risk paths (Jun 7 2026 churn episode -- see
    # runs/forensics/jun7_churn_postmortem.md).
    state = {
        "marginSummary": {
            "accountValue": "NaN",
            "withdrawable": "Infinity",
            "totalRawUsd": "123.0",
        },
        "assetPositions": [
            {"position": {"unrealizedPnl": "NaN"}},
            {"position": {"unrealizedPnl": "1.5"}},
        ],
    }

    with pytest.raises(ValueError, match="accountValue"):
        HyperliquidBot._parse_account_state(state)


def test_parse_account_state_still_tolerates_non_finite_upnl():
    # Only accountValue is load-bearing for sizing; garbage in a single position's upnl is
    # still coerced (0.0) rather than failing the whole read.
    state = {
        "marginSummary": {
            "accountValue": "300.0",
            "withdrawable": "Infinity",
            "totalRawUsd": "123.0",
        },
        "assetPositions": [
            {"position": {"unrealizedPnl": "NaN"}},
            {"position": {"unrealizedPnl": "1.5"}},
        ],
    }

    parsed = HyperliquidBot._parse_account_state(state)

    assert parsed["account_equity_for_risk"] == pytest.approx(300.0)
    assert parsed["unrealized_pnl"] == pytest.approx(1.5)
    assert parsed["wallet_balance_for_sizing"] == pytest.approx(298.5)
    assert parsed["available_margin"] == pytest.approx(123.0)
