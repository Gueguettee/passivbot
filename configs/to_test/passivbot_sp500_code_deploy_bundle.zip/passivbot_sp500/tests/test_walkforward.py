"""Tests for the walk-forward optimization (WFO) module.

Covers the pure helpers (window generation, Pareto selection, the trade-count
overfit guard, equity stitching, parameter drift), the deterministic optimization
cache key, the per-window train-config builder, the seed (window 0) choice, and
that the optimize.* keys the WFO writes survive format_config.

These exercise only the ported WFO module (src/walkforward.py + src/tools/wfo_utils.py
+ src/tools/wfo_meta.py); they need neither the Rust engine nor a live optimizer run.
Run from the repo root:  pytest tests/test_walkforward.py -q
"""

import copy
import json
import os

import pytest

from tools.wfo_utils import (
    generate_windows,
    select_best_from_pareto,
    rank_pareto_candidates,
    pareto_trade_rate,
    select_with_trade_guard,
    ParetoChoice,
    stitch_oos_equity,
    param_drift,
    normalized_distance,
)


# ---------------------------------------------------------------------------
# Window generation
# ---------------------------------------------------------------------------
class TestGenerateWindows:
    def test_basic_calendar_windows_contiguous_and_nonoverlapping(self):
        windows = generate_windows(
            "2025-01-01", "2026-01-01",
            train_months=6, test_months=1, step_months=1, calendar_months=True,
        )
        assert len(windows) >= 6
        # First window: 6mo train then 1mo test.
        w0 = windows[0]
        assert w0.train_start == "2025-01-01"
        assert w0.train_end == "2025-07-01"
        assert w0.test_start == "2025-07-01"  # contiguous: test starts where train ends
        assert w0.test_end == "2025-08-01"
        # Step == test => consecutive OOS segments are non-overlapping and contiguous.
        for prev, nxt in zip(windows, windows[1:]):
            assert nxt.test_start == prev.test_end
        # Indices are sequential from 0.
        assert [w.index for w in windows] == list(range(len(windows)))

    def test_last_partial_test_window_dropped(self):
        # Span ends mid-month so the final OOS would be too short.
        windows = generate_windows(
            "2025-01-01", "2025-08-10",
            train_months=6, test_months=1, step_months=1, min_test_days=7,
        )
        # 6mo train -> 2025-07-01..2025-08-01 (full), next train_start 2025-02-01 ->
        # train_end 2025-08-01, test 2025-08-01..2025-09-01 clamped to 2025-08-10 (9 days, kept).
        for w in windows:
            assert w.test_end <= "2025-08-10"

    def test_fixed_30day_mode_differs_from_calendar(self):
        cal = generate_windows("2025-01-01", "2026-01-01", 6, 1, 1, calendar_months=True)
        fixed = generate_windows("2025-01-01", "2026-01-01", 6, 1, 1, calendar_months=False)
        assert cal[0].train_end == "2025-07-01"
        # 6*30 = 180 days from Jan 1 -> Jun 30, not Jul 1.
        assert fixed[0].train_end == "2025-06-30"

    def test_no_windows_when_history_too_short(self):
        windows = generate_windows("2025-01-01", "2025-03-01", 6, 1, 1)
        assert windows == []

    def test_sp500_t1_yields_two_windows(self):
        # The actual SP500 case (data 2026-03-18 -> 2026-06-07, ~2.7 months):
        # t1 = 1mo train / 1mo test / 1mo step. The final OOS is clamped (~20 days).
        windows = generate_windows("2026-03-18", "2026-06-07", 1, 1, 1)
        assert [w.index for w in windows] == [0, 1]
        assert windows[0].train_start == "2026-03-18"
        assert windows[1].test_end == "2026-06-07"  # clamped to the data end

    def test_sp500_t2_yields_one_window_t3_yields_none(self):
        # t2 = 2mo train: only the seed window fits. t3 = 3mo train: no window yet.
        assert len(generate_windows("2026-03-18", "2026-06-07", 2, 1, 1)) == 1
        assert generate_windows("2026-03-18", "2026-06-07", 3, 1, 1) == []

    @pytest.mark.parametrize("bad", [{"train_months": 0}, {"test_months": 0}, {"step_months": 0}])
    def test_invalid_args_raise(self, bad):
        kwargs = {"train_months": 6, "test_months": 1, "step_months": 1}
        kwargs.update(bad)
        with pytest.raises(ValueError):
            generate_windows("2025-01-01", "2026-01-01", **kwargs)


# ---------------------------------------------------------------------------
# Pareto selection
# ---------------------------------------------------------------------------
def _write_pareto_entry(directory, hash_id, w0, w1, violation=0.0, trade_rate=None):
    stats = {"adg": {"mean": -w0}}
    if trade_rate is not None:
        stats["positions_held_per_day"] = {"mean": trade_rate}
    entry = {
        "bot": {"long": {"x": 1.0}, "short": {}},
        "optimize": {"scoring": ["adg", "sharpe"]},
        "metrics": {
            "objectives": {"w_0": w0, "w_1": w1},
            "constraint_violation": violation,
            "stats": stats,
        },
    }
    with open(os.path.join(directory, f"{hash_id}.json"), "w", encoding="utf-8") as fh:
        json.dump(entry, fh)


class TestSelectBestFromPareto:
    def test_picks_member_closest_to_ideal(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        # objectives are minimized; ideal = (-1.0, -1.0)
        _write_pareto_entry(d, "a", -1.0, -0.5)
        _write_pareto_entry(d, "b", -0.5, -1.0)
        _write_pareto_entry(d, "c", -0.9, -0.9)  # closest to ideal corner
        choice = select_best_from_pareto(str(d), ["adg", "sharpe"])
        assert choice is not None
        assert choice.hash_id == "c"
        assert choice.n_candidates == 3
        # The returned config is a full config with metrics stripped.
        assert "bot" in choice.config
        assert "metrics" not in choice.config

    def test_feasible_members_preferred_over_lower_objective_infeasible(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        _write_pareto_entry(d, "c", -0.9, -0.9, violation=0.0)
        _write_pareto_entry(d, "infeasible", -2.0, -2.0, violation=1e6)
        choice = select_best_from_pareto(str(d), ["adg", "sharpe"])
        assert choice.hash_id == "c"

    def test_deterministic_tie_break_by_hash(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        _write_pareto_entry(d, "bbb", -1.0, -1.0)
        _write_pareto_entry(d, "aaa", -1.0, -1.0)
        choice = select_best_from_pareto(str(d), ["adg", "sharpe"])
        assert choice.hash_id == "aaa"

    def test_empty_dir_returns_none(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        assert select_best_from_pareto(str(d), ["adg", "sharpe"]) is None


# ---------------------------------------------------------------------------
# Ranking the full front (fall-back candidates for the trade guard)
# ---------------------------------------------------------------------------
class TestRankParetoCandidates:
    def test_ranked_list_best_first_matches_select_best(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        _write_pareto_entry(d, "a", -1.0, -0.5)
        _write_pareto_entry(d, "b", -0.5, -1.0)
        _write_pareto_entry(d, "c", -0.9, -0.9)  # closest to ideal corner
        ranked = rank_pareto_candidates(str(d), ["adg", "sharpe"])
        assert [c.hash_id for c in ranked][0] == "c"            # best first
        assert set(c.hash_id for c in ranked) == {"a", "b", "c"}  # all present
        assert ranked[0].hash_id == select_best_from_pareto(str(d), ["adg", "sharpe"]).hash_id
        assert all(c.n_candidates == 3 for c in ranked)

    def test_empty_dir_returns_empty_list(self, tmp_path):
        d = tmp_path / "pareto"
        d.mkdir()
        assert rank_pareto_candidates(str(d), ["adg", "sharpe"]) == []


# ---------------------------------------------------------------------------
# Trade-count overfit guard
# ---------------------------------------------------------------------------
def _choice(hash_id, rate):
    metrics = {} if rate is None else {"stats": {"positions_held_per_day": {"mean": rate}}}
    return ParetoChoice(hash_id, {"bot": {}}, (1.0,), 0.0, 0.0, metrics, 9)


class TestParetoTradeRate:
    def test_reads_positions_held_per_day(self):
        assert pareto_trade_rate(_choice("a", 4.25)) == pytest.approx(4.25)

    def test_weighted_fallback(self):
        c = ParetoChoice("a", {}, (1.0,), 0.0, 0.0,
                         {"stats": {"positions_held_per_day_w": {"mean": 3.1}}}, 1)
        assert pareto_trade_rate(c) == pytest.approx(3.1)

    def test_none_when_absent(self):
        assert pareto_trade_rate(_choice("a", None)) is None


class TestSelectWithTradeGuard:
    def test_window0_no_prev_takes_top_rank(self):
        cands = [_choice("top", 1.0), _choice("b", 9.0)]
        choice, info = select_with_trade_guard(cands, None, 0.5)
        assert choice.hash_id == "top"
        assert info["applied"] is False

    def test_rejects_big_drop_and_falls_to_next(self):
        # prev rate 10, threshold = 5; rank-0 trades 2 (>50% drop) -> reject; rank-1 trades 6 -> ok.
        cands = [_choice("r0", 2.0), _choice("r1", 6.0), _choice("r2", 1.0)]
        choice, info = select_with_trade_guard(cands, 10.0, 0.5)
        assert choice.hash_id == "r1"
        assert info["applied"] is True
        assert info["chosen_rank"] == 1
        assert [r["hash_id"] for r in info["rejected"]] == ["r0"]

    def test_all_fail_picks_highest_trade_rate(self):
        cands = [_choice("r0", 1.0), _choice("r1", 3.0), _choice("r2", 2.0)]
        choice, info = select_with_trade_guard(cands, 10.0, 0.5)  # threshold 5, none pass
        assert choice.hash_id == "r1"        # highest rate (3.0)
        assert info["no_pass"] is True
        assert info["fallback"] == "highest_trade_rate"

    def test_min_ratio_zero_disables(self):
        cands = [_choice("top", 0.1), _choice("b", 9.0)]
        choice, info = select_with_trade_guard(cands, 10.0, 0.0)
        assert choice.hash_id == "top"
        assert info["applied"] is False

    def test_unjudgeable_candidate_accepted(self):
        # rank-0 has no trade-rate metric -> cannot be judged -> accepted at its rank.
        choice, info = select_with_trade_guard([_choice("r0", None), _choice("r1", 9.0)], 10.0, 0.5)
        assert choice.hash_id == "r0"
        assert info["chosen_rank"] == 0


# ---------------------------------------------------------------------------
# Cache round-trip of the ranked candidate list
# ---------------------------------------------------------------------------
class TestCandidateCache:
    def test_save_load_roundtrip_and_header_validation(self, tmp_path):
        from walkforward import _save_cached_candidates, _load_cached_candidates
        from tools.wfo_utils import Window

        w = Window(0, "2025-01-01", "2025-07-01", "2025-07-01", "2025-08-01")
        cands = [_choice("r0", 5.0), _choice("r1", 2.0)]
        path = tmp_path / "candidates.json"
        _save_cached_candidates(path, cands, "key-a", w, 7)

        loaded = _load_cached_candidates(path, expected_key="key-a",
                                         expected_window=w.to_dict(), expected_seed=7)
        assert loaded is not None
        assert [c.hash_id for c in loaded] == ["r0", "r1"]
        assert pareto_trade_rate(loaded[0]) == pytest.approx(5.0)
        # Header mismatches reject the entry.
        assert _load_cached_candidates(path, expected_key="other") is None
        assert _load_cached_candidates(path, expected_seed=8) is None


# ---------------------------------------------------------------------------
# Aggregate trade-guard rollup for walkforward_summary.json
# ---------------------------------------------------------------------------
class TestSummarizeTradeGuards:
    def test_rolls_up_walked_no_pass_and_rejections(self):
        from walkforward import _summarize_trade_guards

        # Build per-window guard decisions from the real selector so the rollup is tied
        # to the actual trade_guard dict shape.
        _, g_win0 = select_with_trade_guard([_choice("a", 5.0)], None, 0.5)       # disabled (window 0)
        _, g_walked = select_with_trade_guard(                                    # walks to rank 1
            [_choice("r0", 2.0), _choice("r1", 6.0)], 10.0, 0.5)
        _, g_nopass = select_with_trade_guard(                                    # none pass -> fallback
            [_choice("r0", 1.0), _choice("r1", 3.0)], 10.0, 0.5)

        records = [
            {"index": 0, "trade_guard": g_win0},
            {"index": 1, "trade_guard": g_walked},
            {"index": 2, "trade_guard": g_nopass},
        ]
        out = _summarize_trade_guards(records)
        assert out["windows_total"] == 3
        assert out["windows_guard_walked"] == [1]
        assert out["windows_no_pass"] == [2]
        assert out["n_candidates_rejected_total"] == 3   # 0 (win0) + 1 (walked) + 2 (no_pass)
        assert out["min_trade_ratio"] == pytest.approx(0.5)

    def test_empty_and_legacy_records_tolerated(self):
        from walkforward import _summarize_trade_guards

        assert _summarize_trade_guards([]) == {
            "min_trade_ratio": None,
            "windows_total": 0,
            "windows_seeded": [],
            "windows_guard_walked": [],
            "windows_no_pass": [],
            "n_candidates_rejected_total": 0,
        }
        # A record predating the guard (no trade_guard key) must not raise.
        out = _summarize_trade_guards([{"index": 0}])
        assert out["windows_total"] == 1
        assert out["windows_guard_walked"] == []

    def test_seed_window_counted_separately(self):
        from walkforward import _summarize_trade_guards

        # Window 0 is the seed (initial config used as-is): it never walks the front and
        # must not be counted as a guard action; it's reported under windows_seeded.
        _, g_walked = select_with_trade_guard(
            [_choice("r0", 2.0), _choice("r1", 6.0)], 10.0, 0.5)
        records = [
            {"index": 0, "trade_guard": {"applied": False, "seeded": True}},
            {"index": 1, "trade_guard": g_walked},
        ]
        out = _summarize_trade_guards(records)
        assert out["windows_seeded"] == [0]
        assert out["windows_guard_walked"] == [1]
        assert out["windows_no_pass"] == []
        assert out["n_candidates_rejected_total"] == 1  # only window 1's rejection counts


# ---------------------------------------------------------------------------
# Seed window 0: initial config used as-is (no optimization)
# ---------------------------------------------------------------------------
class TestSeedChoiceFromConfig:
    def test_builds_unoptimized_choice_from_initial_config(self):
        from walkforward import seed_choice_from_config

        choice = seed_choice_from_config("configs/config_sp500.json")
        # Carries the initial config's strategy parameters...
        assert isinstance(choice.config.get("bot"), dict)
        assert "long" in choice.config["bot"] and "short" in choice.config["bot"]
        assert isinstance(choice.hash_id, str) and choice.hash_id
        # ...but no optimization artifacts.
        assert choice.metrics == {}
        assert choice.n_candidates == 0
        assert choice.objectives == ()
        assert choice.violation == 0.0

    def test_seed_choice_has_no_trade_rate_so_guard_stays_off_next_window(self):
        from walkforward import seed_choice_from_config

        seed = seed_choice_from_config("configs/config_sp500.json")
        # No in-sample metrics => unknown trade rate => prev_trade_rate stays None into
        # window 1 => the trade-count guard is disabled there (activates from window 2).
        assert pareto_trade_rate(seed) is None
        choice, info = select_with_trade_guard([_choice("top", 1.0), _choice("b", 9.0)],
                                               pareto_trade_rate(seed), 0.5)
        assert choice.hash_id == "top"
        assert info["applied"] is False


# ---------------------------------------------------------------------------
# Equity stitching
# ---------------------------------------------------------------------------
class TestStitchOosEquity:
    def test_compounds_segments(self):
        # segment 1: +10% (100 -> 110); segment 2: -50% then back (200 -> 100, ratio 0.5)
        seg1 = [100.0, 105.0, 110.0]
        seg2 = [200.0, 150.0, 100.0]
        out = stitch_oos_equity([seg1, seg2], starting_balance=1000.0)
        eq = out["equity"]
        assert eq[0] == pytest.approx(1000.0)
        # after seg1: 1000 * 1.1 = 1100
        assert eq[2] == pytest.approx(1100.0)
        # after seg2: 1100 * 0.5 = 550
        assert eq[-1] == pytest.approx(550.0)
        assert out["metrics"]["final_equity"] == pytest.approx(550.0)
        assert out["metrics"]["total_return"] == pytest.approx(-0.45)
        assert out["metrics"]["max_drawdown"] == pytest.approx(0.5)

    def test_empty_segments(self):
        out = stitch_oos_equity([], starting_balance=100.0)
        assert out["equity"] == []
        assert out["metrics"]["final_equity"] == pytest.approx(100.0)

    def test_dict_segment_without_timestamps_uses_legacy_stitching(self):
        out = stitch_oos_equity([{"equity": [100.0, 110.0]}], starting_balance=1000.0)
        assert out["equity"] == pytest.approx([1000.0, 1100.0])
        assert "timestamps" not in out

    def test_timestamped_segments_dedupe_overlap(self):
        seg1 = {"timestamps": [1, 2, 3], "equity": [100.0, 110.0, 121.0]}
        # Starts at the same timestamp as seg1's last point. The duplicate timestamp
        # is used as the anchor, then skipped, so the overlap is not double-counted.
        seg2 = {"timestamps": [3, 4], "equity": [200.0, 220.0]}
        out = stitch_oos_equity([seg1, seg2], starting_balance=1000.0)
        assert out["timestamps"] == [1, 2, 3, 4]
        assert out["equity"] == pytest.approx([1000.0, 1100.0, 1210.0, 1331.0])

    def test_timestamped_segments_sorted_before_stitching(self):
        seg = {"timestamps": [3, 1, 2], "equity": [121.0, 100.0, 110.0]}
        out = stitch_oos_equity([seg], starting_balance=1000.0)
        assert out["timestamps"] == [1, 2, 3]
        assert out["equity"] == pytest.approx([1000.0, 1100.0, 1210.0])

    def test_stateful_concatenates_and_dedupes_overlap(self):
        # Stateful segments are already value-continuous: concatenate raw values,
        # dropping the duplicate boundary timestamp.
        seg1 = {"timestamps": [1, 2, 3], "equity": [100.0, 110.0, 120.0]}
        seg2 = {"timestamps": [3, 4], "equity": [120.0, 130.0]}  # overlaps at ts 3
        out = stitch_oos_equity([seg1, seg2], starting_balance=100.0, stateful=True)
        assert out["timestamps"] == [1, 2, 3, 4]
        assert out["equity"] == pytest.approx([100.0, 110.0, 120.0, 130.0])
        assert out["metrics"]["final_equity"] == pytest.approx(130.0)
        assert out["metrics"]["total_return"] == pytest.approx(0.30)

    def test_stateful_differs_from_compounded(self):
        seg1 = {"timestamps": [1, 2], "equity": [100.0, 110.0]}
        seg2 = {"timestamps": [3, 4], "equity": [200.0, 220.0]}
        stateful = stitch_oos_equity([seg1, seg2], starting_balance=100.0, stateful=True)
        compounded = stitch_oos_equity([seg1, seg2], starting_balance=100.0, stateful=False)
        assert stateful["equity"] == pytest.approx([100.0, 110.0, 200.0, 220.0])
        assert stateful["equity"] != compounded["equity"]


# ---------------------------------------------------------------------------
# Parameter drift
# ---------------------------------------------------------------------------
class TestParamDrift:
    def test_drift_and_normalization(self):
        prev = {"bot": {"long": {"a": 1.0, "b": 2.0}}}
        cur = {"bot": {"long": {"a": 1.5, "b": 2.0}}}
        ranges = {"long.a": 1.0, "long.b": 4.0}
        out = param_drift(prev, cur, ranges)
        assert out["per_param"]["long.a"]["delta"] == pytest.approx(0.5)
        assert out["per_param"]["long.a"]["normalized"] == pytest.approx(0.5)
        assert out["per_param"]["long.b"]["delta"] == pytest.approx(0.0)
        assert out["l2_normalized"] == pytest.approx(0.5)

    def test_normalized_distance(self):
        assert normalized_distance([1.0, 1.0], [0.0, 0.0], [1.0, 1.0]) == pytest.approx(1.0)
        assert normalized_distance([1.0], [1.0], [2.0]) == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# Deterministic optimization cache key
# ---------------------------------------------------------------------------
def _train_cfg():
    return {
        "bot": {"long": {"x": 1.0}, "short": {}},
        "optimize": {
            "seed": 7,
            "scoring": ["adg"],
            "bounds": {"long_x": [0.0, 2.0]},
            "stop": {"patience": 10, "min_rel_improvement": 0.001, "max_evals": 0},
            "proximity": {"weight": 0.0, "reference_config": ""},
            "n_cpus": 5,
            "iters": 1000,
            "population_size": 100,
        },
        "backtest": {
            "start_date": "2026-03-18",
            "end_date": "2026-04-18",
            "exchanges": ["hyperliquid"],
            "starting_balance": 1000.0,
            "base_dir": "some/dir",
            "cache_dir": {"hyperliquid": "x"},
            "coins": {"hyperliquid": ["SP500"]},
        },
        "results_dir": "volatile/path",
    }


class TestWindowCacheKey:
    def test_identical_meta_same_key(self):
        from walkforward import window_cache_key

        assert window_cache_key(_train_cfg(), None) == window_cache_key(_train_cfg(), None)

    def test_volatile_fields_excluded(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        variant = _train_cfg()
        variant["results_dir"] = "other/path"
        variant["backtest"]["base_dir"] = "other"
        variant["backtest"]["cache_dir"] = {"hyperliquid": "y"}
        variant["backtest"]["hyperliquid_data_dir"] = "/some/machine/specific/path"
        variant["optimize"]["n_cpus"] = 16
        assert window_cache_key(base, None) == window_cache_key(variant, None)

    def test_seed_changes_key(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        variant = _train_cfg()
        variant["optimize"]["seed"] = 999
        assert window_cache_key(base, None) != window_cache_key(variant, None)

    def test_dates_change_key(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        variant = _train_cfg()
        variant["backtest"]["start_date"] = "2026-02-01"
        assert window_cache_key(base, None) != window_cache_key(variant, None)

    def test_coin_universe_changes_key(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        variant = _train_cfg()
        variant["backtest"]["coins"] = {"hyperliquid": ["OTHER"]}
        assert window_cache_key(base, None) != window_cache_key(variant, None)

    def test_walk_forward_run_id_does_not_change_key(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        variant = _train_cfg()
        base["walk_forward"] = {"run_id": "run-a", "train_months": 6}
        variant["walk_forward"] = {"run_id": "run-b", "train_months": 6}
        assert window_cache_key(base, None) == window_cache_key(variant, None)

    def test_invariant_to_config_metadata_and_base_path(self):
        from walkforward import window_cache_key

        base = _train_cfg()
        base.setdefault("live", {})["base_config_path"] = "/runs/A/train_config.json"
        variant = _train_cfg()
        # Per-run metadata that must NOT affect the cache key.
        variant["_transform_log"] = [{"ts_ms": 123456789, "step": "load_config"}]
        variant["_raw"] = {"whatever": 1}
        variant.setdefault("live", {})["base_config_path"] = "/runs/B/train_config.json"
        assert window_cache_key(base, None) == window_cache_key(variant, None)

    def test_warm_start_hash_ignores_metadata_and_base_path(self, tmp_path):
        from walkforward import window_cache_key

        ws_a = tmp_path / "a.json"
        ws_b = tmp_path / "b.json"
        # Same bot params, different run-specific metadata/path => same effective warm-start.
        ws_a.write_text(json.dumps({
            "bot": {"long": {"x": 1.0}},
            "live": {"base_config_path": "/runs/A/x.json"},
        }))
        ws_b.write_text(json.dumps({
            "bot": {"long": {"x": 1.0}},
            "live": {"base_config_path": "/runs/B/x.json"},
            "_transform_log": [{"ts_ms": 999}],
        }))
        assert window_cache_key(_train_cfg(), str(ws_a)) == window_cache_key(_train_cfg(), str(ws_b))

    def test_warm_start_content_changes_key(self, tmp_path):
        from walkforward import window_cache_key

        ws1 = tmp_path / "ws1.json"
        ws2 = tmp_path / "ws2.json"
        ws1.write_text(json.dumps({"bot": {"long": {"x": 1.0}}}))
        ws2.write_text(json.dumps({"bot": {"long": {"x": 9.0}}}))
        k_none = window_cache_key(_train_cfg(), None)
        k1 = window_cache_key(_train_cfg(), str(ws1))
        k2 = window_cache_key(_train_cfg(), str(ws2))
        assert k1 != k_none
        assert k1 != k2
        # Same content => same key.
        assert k1 == window_cache_key(_train_cfg(), str(ws1))

    def test_cached_choice_rejects_mismatched_key_window_or_seed(self, tmp_path):
        from walkforward import _load_cached_choice

        payload = {
            "cache_key": "key-a",
            "window": {"index": 0},
            "seed": 7,
            "hash_id": "abc",
            "objectives": [1.0],
            "violation": 0.0,
            "distance": 0.0,
            "n_candidates": 1,
            "metrics": {},
            "config": {"bot": {"long": {}}},
        }
        path = tmp_path / "choice.json"
        path.write_text(json.dumps(payload), encoding="utf-8")

        assert _load_cached_choice(path, expected_key="key-a", expected_window={"index": 0}, expected_seed=7)
        assert _load_cached_choice(path, expected_key="key-b", expected_window={"index": 0}, expected_seed=7) is None
        assert _load_cached_choice(path, expected_key="key-a", expected_window={"index": 1}, expected_seed=7) is None
        assert _load_cached_choice(path, expected_key="key-a", expected_window={"index": 0}, expected_seed=8) is None


# ---------------------------------------------------------------------------
# Per-window train config: proximity gating + data-dir injection
# ---------------------------------------------------------------------------
class TestBuildTrainConfigProximity:
    def _base(self):
        return {"backtest": {}, "optimize": {}}

    def _window(self):
        from tools.wfo_utils import Window

        return Window(0, "2026-03-18", "2026-04-18", "2026-04-18", "2026-05-18")

    def test_window0_has_no_proximity_penalty(self):
        from walkforward import build_train_config

        cfg = build_train_config(
            self._base(), self._window(), seed=0,
            stop_cfg={"patience": 0, "min_rel_improvement": 0.0, "max_evals": 0},
            proximity_weight=0.05, reference_config=None, iters=None, n_cpus=None,
        )
        # No previous window => no reference => penalty disabled even with weight > 0.
        assert cfg["optimize"]["proximity"]["weight"] == 0.0
        assert cfg["optimize"]["proximity"]["reference_config"] == ""
        # The shared hyperliquid data dir is pinned so every window reuses one cache.
        assert cfg["backtest"]["hyperliquid_data_dir"].replace("\\", "/").endswith(
            "caches/ohlcv/hyperliquid/1m"
        )

    def test_later_window_has_proximity_penalty(self, tmp_path):
        from walkforward import build_train_config

        prev = tmp_path / "prev.json"
        prev.write_text(json.dumps({"bot": {"long": {"x": 1.0}}}), encoding="utf-8")
        cfg = build_train_config(
            self._base(), self._window(), seed=1,
            stop_cfg={"patience": 0, "min_rel_improvement": 0.0, "max_evals": 0},
            proximity_weight=0.05, reference_config=str(prev), iters=None, n_cpus=None,
        )
        assert cfg["optimize"]["proximity"]["weight"] == pytest.approx(0.05)
        assert cfg["optimize"]["proximity"]["reference_config"]  # resolved abs path

    def test_zero_weight_never_sets_proximity(self, tmp_path):
        from walkforward import build_train_config

        prev = tmp_path / "prev.json"
        prev.write_text(json.dumps({"bot": {"long": {"x": 1.0}}}), encoding="utf-8")
        cfg = build_train_config(
            self._base(), self._window(), seed=1,
            stop_cfg={"patience": 0, "min_rel_improvement": 0.0, "max_evals": 0},
            proximity_weight=0.0, reference_config=str(prev), iters=None, n_cpus=None,
        )
        assert cfg["optimize"]["proximity"]["weight"] == 0.0
        assert cfg["optimize"]["proximity"]["reference_config"] == ""


class TestOptimizeOneWindow:
    def test_raises_window_error_on_optimizer_failure(self, tmp_path):
        from walkforward import optimize_one_window, WindowOptimizeError
        from tools.wfo_utils import Window

        base = {"backtest": {}, "optimize": {}, "bot": {"long": {}, "short": {}}}
        w = Window(0, "2026-03-18", "2026-04-18", "2026-04-18", "2026-05-18")
        with pytest.raises(WindowOptimizeError) as ei:
            optimize_one_window(
                base, w,
                seed=0,
                stop_cfg={"patience": 0, "min_rel_improvement": 0.0, "max_evals": 0},
                proximity_weight=0.0,
                proximity_reference=None,
                warm_start=None,
                scoring_keys=["adg"],
                train_cfg_path=str(tmp_path / "train.json"),
                results_dir=str(tmp_path / "res"),
                log_path=str(tmp_path / "opt.log"),
                cache_dir=None,
                no_cache=True,
                optimize_script=str(tmp_path / "does_not_exist.py"),
            )
        assert ei.value.code == 2
        # The train config is written before the optimizer runs (so it's reusable).
        assert (tmp_path / "train.json").exists()


# ---------------------------------------------------------------------------
# The optimize.* keys the WFO writes per window survive format_config
# ---------------------------------------------------------------------------
def test_new_optimize_keys_survive_format_config():
    from config_utils import get_template_config, format_config

    tmpl = get_template_config()
    assert "seed" in tmpl["optimize"]
    assert "stop" in tmpl["optimize"]
    assert "proximity" in tmpl["optimize"]

    cfg = copy.deepcopy(tmpl)
    cfg["optimize"]["seed"] = 4242
    cfg["optimize"]["stop"] = {"patience": 9, "min_rel_improvement": 0.002, "max_evals": 5000}
    cfg["optimize"]["proximity"] = {"weight": 0.05, "reference_config": "configs/config_sp500.json"}
    out = format_config(copy.deepcopy(cfg), verbose=False)
    assert out["optimize"]["seed"] == 4242
    assert int(out["optimize"]["stop"]["patience"]) == 9
    assert float(out["optimize"]["stop"]["min_rel_improvement"]) == pytest.approx(0.002)
    assert float(out["optimize"]["proximity"]["weight"]) == pytest.approx(0.05)
    assert out["optimize"]["proximity"]["reference_config"] == "configs/config_sp500.json"


# ---------------------------------------------------------------------------
# optimize_first_window meta flag
# ---------------------------------------------------------------------------
class TestOptimizeFirstWindow:
    def test_default_is_false_seed_behavior(self):
        from tools.wfo_meta import WF_DEFAULTS, merge_wf_params

        assert WF_DEFAULTS["optimize_first_window"] is False
        assert merge_wf_params({})["optimize_first_window"] is False

    def test_override_true_survives_merge(self):
        from tools.wfo_meta import merge_wf_params

        assert merge_wf_params({"optimize_first_window": True})["optimize_first_window"] is True

    def test_sp500_meta_trains_first_window(self):
        # The SP500 schedule opts in (short history => train window 0 too).
        from tools.wfo_meta import load_wf_meta

        wf, _ = load_wf_meta("configs/wfo_sp500.json")
        assert wf["optimize_first_window"] is True
