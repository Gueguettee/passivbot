import asyncio
import signal

import passivbot as pb
from passivbot import Passivbot


class _SignalBot:
    def __init__(self):
        self.stop_signal_received = False
        self.shutdown_calls = 0

    async def shutdown_gracefully(self):
        self.shutdown_calls += 1


def test_signal_handler_schedules_current_bot_shutdown():
    loop = asyncio.new_event_loop()
    fake_bot = _SignalBot()
    old_bot = pb.bot
    try:
        asyncio.set_event_loop(loop)
        pb.bot = fake_bot

        pb.signal_handler(signal.SIGINT, None)

        assert fake_bot.stop_signal_received is True
        assert fake_bot._shutdown_reason == "manual_signal"
        assert hasattr(fake_bot, "_shutdown_task")
        loop.run_until_complete(fake_bot._shutdown_task)
        assert fake_bot.shutdown_calls == 1
    finally:
        pb.bot = old_bot
        asyncio.set_event_loop(None)
        loop.close()


def test_shutdown_gracefully_delegates_to_overridden_close_once():
    bot = object.__new__(Passivbot)
    bot.stop_signal_received = False
    bot.close_calls = 0

    async def close():
        bot.close_calls += 1

    bot.close = close

    asyncio.run(Passivbot.shutdown_gracefully(bot))
    asyncio.run(Passivbot.shutdown_gracefully(bot))

    assert bot.stop_signal_received is True
    assert bot.close_calls == 1
