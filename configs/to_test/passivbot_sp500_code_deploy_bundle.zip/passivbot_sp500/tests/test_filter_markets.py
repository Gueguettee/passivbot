"""
Offline regression tests for utils.filter_markets on Hyperliquid xyz markets.

These are part of the STANDARD suite: no network, no exchange, no money.

Background: HyperliquidBot.init_markets() builds market dicts from the native SDK `meta`,
which does NOT include an `openInterest` field. An earlier version of filter_markets did
`float(v["info"]["openInterest"]) == 0.0` and crashed with TypeError on Hyperliquid,
blocking every live start. The fix added `_hl_open_interest_is_zero` which treats an
absent/None/unparseable open-interest as "not zero" (i.e. does not make the market
ineligible). These tests pin that behavior plus the onlyIsolated handling.
"""
from utils import filter_markets, _hl_open_interest_is_zero


def _xyz_market(coin, sz_dec=3, max_lev=20, only_isolated=False, open_interest="__absent__"):
    """Build a market dict mirroring HyperliquidBot.init_markets() (src/exchanges/hyperliquid.py)."""
    hlname = f"xyz:{coin}"
    symbol = f"{coin}/USDC:USDC"
    max_dec = 6
    price_tick = 10 ** -(max_dec - sz_dec) if (max_dec - sz_dec) > 0 else 1.0
    amount_tick = 10 ** -sz_dec
    info = {
        "name": hlname,
        "szDecimals": sz_dec,
        "maxLeverage": max_lev,
        "onlyIsolated": only_isolated,
    }
    # Hyperliquid's native meta omits openInterest entirely; only add it if a test asks.
    if open_interest != "__absent__":
        info["openInterest"] = open_interest
    return symbol, {
        "symbol": symbol,
        "id": hlname,
        "base": coin,
        "quote": "USDC",
        "active": True,
        "swap": True,
        "linear": True,
        "type": "swap",
        "precision": {"amount": amount_tick, "price": price_tick},
        "limits": {"amount": {"min": amount_tick}, "cost": {"min": 10.0}},
        "maker": 0.0002,
        "taker": 0.0005,
        "contractSize": 1.0,
        "info": info,
    }


def test_hl_open_interest_helper():
    # absent / None -> not zero (so NOT ineligible), never crashes
    assert _hl_open_interest_is_zero(None) is False
    assert _hl_open_interest_is_zero("not-a-number") is False
    # present and zero -> True
    assert _hl_open_interest_is_zero(0.0) is True
    assert _hl_open_interest_is_zero("0") is True
    # present and non-zero -> False
    assert _hl_open_interest_is_zero(5) is False
    assert _hl_open_interest_is_zero("123.4") is False


def test_filter_markets_no_open_interest_does_not_crash():
    """Regression: xyz markets have no openInterest field; filter_markets must not raise."""
    sym, md = _xyz_market("SP500")
    eligible, ineligible, reasons = filter_markets({sym: md}, "hyperliquid", quote="USDC")
    assert sym in eligible
    assert sym not in ineligible


def test_filter_markets_sp500_eligible_nvda_eligible():
    s1, m1 = _xyz_market("SP500", sz_dec=3, max_lev=20)
    s2, m2 = _xyz_market("NVDA", sz_dec=3, max_lev=10)
    eligible, ineligible, reasons = filter_markets({s1: m1, s2: m2}, "hyperliquid", quote="USDC")
    assert s1 in eligible and s2 in eligible
    assert not ineligible


def test_filter_markets_only_isolated_is_ineligible():
    s_ok, m_ok = _xyz_market("SP500", only_isolated=False)
    s_iso, m_iso = _xyz_market("WEIRD", only_isolated=True)
    eligible, ineligible, reasons = filter_markets({s_ok: m_ok, s_iso: m_iso}, "hyperliquid", quote="USDC")
    assert s_ok in eligible
    assert s_iso in ineligible
    assert "ineligible" in reasons[s_iso]


def test_filter_markets_zero_open_interest_is_ineligible():
    """If openInterest IS present and parses to 0.0, the market is ineligible (parity w/ other exchanges)."""
    s_zero, m_zero = _xyz_market("ZERO", open_interest=0.0)
    eligible, ineligible, reasons = filter_markets({s_zero: m_zero}, "hyperliquid", quote="USDC")
    assert s_zero in ineligible
