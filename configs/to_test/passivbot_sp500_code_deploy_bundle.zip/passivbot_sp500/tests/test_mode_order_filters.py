"""
Offline unit tests for Passivbot._apply_mode_filters (per-symbol cancel/create mode rules).

Part of the STANDARD suite: no network, no real account, no money. The bot is built with
object.__new__ (bypassing __init__/SDK construction); only PB_modes is stubbed, so we exercise
the real reconciliation filter.

The key invariant under test (the reviewer's High finding): in 'tp_only' the bot must place no
new entries AND actively CANCEL any resting entry orders -- otherwise a safety halt (min-capital
floor / WS-health gate) downgrades a symbol to tp_only yet leaves live DCA orders on the book that
can still fill while the bot believes it has halted opening. This mirrors the backtest's
tp_only_with_active_entry_cancellation semantics. Closes (reduce_only) are always kept; 'manual'
freezes the side entirely; 'normal' is a passthrough.

Orders are built in the shape _snapshot_actual_orders emits: position_side / reduce_only / side /
qty / price.
"""
from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"


def _bot(modes):
    bot = object.__new__(Passivbot)
    bot.PB_modes = modes
    return bot


def _order(position_side, reduce_only, price=100.0, qty=1.0):
    """An order dict matching _snapshot_actual_orders' shape."""
    if position_side == "long":
        side = "sell" if reduce_only else "buy"
    else:  # short
        side = "buy" if reduce_only else "sell"
    return {
        "symbol": SYMBOL,
        "side": side,
        "position_side": position_side,
        "qty": qty,
        "price": price,
        "reduce_only": reduce_only,
    }


LONG_ENTRY = _order("long", reduce_only=False, price=90.0)   # resting DCA buy
LONG_TP = _order("long", reduce_only=True, price=110.0)      # take-profit close
SHORT_ENTRY = _order("short", reduce_only=False, price=110.0)
SHORT_TP = _order("short", reduce_only=True, price=90.0)


# --------------------------------------------------------------------------- #
# tp_only -- the regression: resting entries must be CANCELLED, not frozen
# --------------------------------------------------------------------------- #
def test_tp_only_cancels_resting_entry_and_keeps_tp():
    bot = _bot({"long": {SYMBOL: "tp_only"}, "short": {}})
    to_cancel = [LONG_ENTRY, LONG_TP]
    to_create = [LONG_ENTRY, LONG_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    # The reviewer's invariant, exactly: entry creates are suppressed, entry cancels are NOT.
    assert LONG_ENTRY in out_cancel, "resting entry must be cancelled, not frozen on the book"
    assert LONG_ENTRY not in out_create, "no new entry may be created in tp_only"
    # Reduce-only take-profit closes are still managed (kept in both lists).
    assert LONG_TP in out_cancel
    assert LONG_TP in out_create


def test_tp_only_long_does_not_touch_short_side():
    # Only the long side is tp_only -> short entries/closes pass through untouched.
    bot = _bot({"long": {SYMBOL: "tp_only"}, "short": {SYMBOL: "normal"}})
    to_cancel = [LONG_ENTRY, SHORT_ENTRY, SHORT_TP]
    to_create = [LONG_ENTRY, SHORT_ENTRY, SHORT_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    assert LONG_ENTRY in out_cancel        # long entry cancelled
    assert LONG_ENTRY not in out_create    # long entry create suppressed
    assert SHORT_ENTRY in out_cancel and SHORT_ENTRY in out_create  # short untouched
    assert SHORT_TP in out_cancel and SHORT_TP in out_create


def test_tp_only_both_sides_cancels_both_entries():
    bot = _bot({"long": {SYMBOL: "tp_only"}, "short": {SYMBOL: "tp_only"}})
    to_cancel = [LONG_ENTRY, SHORT_ENTRY, LONG_TP, SHORT_TP]
    to_create = [LONG_ENTRY, SHORT_ENTRY, LONG_TP, SHORT_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    # Both entries cancelled; neither entry recreated; both TP closes kept.
    assert LONG_ENTRY in out_cancel and SHORT_ENTRY in out_cancel
    assert LONG_ENTRY not in out_create and SHORT_ENTRY not in out_create
    assert LONG_TP in out_create and SHORT_TP in out_create


# --------------------------------------------------------------------------- #
# manual -- freezes the side entirely (unchanged behavior; locked so it can't drift)
# --------------------------------------------------------------------------- #
def test_manual_freezes_both_entry_and_close():
    bot = _bot({"long": {SYMBOL: "manual"}, "short": {}})
    to_cancel = [LONG_ENTRY, LONG_TP]
    to_create = [LONG_ENTRY, LONG_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    # manual = bot ignores the side: it neither cancels nor creates anything on that side.
    assert out_cancel == [] and out_create == []


def test_manual_long_leaves_short_untouched():
    bot = _bot({"long": {SYMBOL: "manual"}, "short": {SYMBOL: "normal"}})
    to_cancel = [LONG_ENTRY, SHORT_ENTRY]
    to_create = [LONG_TP, SHORT_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    assert out_cancel == [SHORT_ENTRY]   # long dropped, short kept
    assert out_create == [SHORT_TP]


# --------------------------------------------------------------------------- #
# normal -- passthrough
# --------------------------------------------------------------------------- #
def test_normal_is_passthrough():
    bot = _bot({"long": {SYMBOL: "normal"}, "short": {SYMBOL: "normal"}})
    to_cancel = [LONG_ENTRY, LONG_TP, SHORT_ENTRY, SHORT_TP]
    to_create = [LONG_ENTRY, LONG_TP, SHORT_ENTRY, SHORT_TP]
    out_cancel, out_create = bot._apply_mode_filters(SYMBOL, to_cancel, to_create)

    assert out_cancel == to_cancel
    assert out_create == to_create
