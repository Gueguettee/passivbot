"""
Offline unit tests for the data-staleness trading gate (_apply_data_staleness_modes).

Part of the STANDARD suite: no network, no real account, no money. The gate downgrades every
entry-permitting symbol (mode 'normal'/'graceful_stop') to 'tp_only' when the number of
consecutive exchange candle-fetch failures (`_candle_fetch_fails`, incremented in
HyperliquidBot._fetch_candles) reaches the configured threshold, and auto-recovers when fetches
succeed (the counter resets to 0). The signal is a FAILURE COUNT, not time-since-refresh, so a
healthy-but-quiet market (which legitimately returns no new candles) is never blocked.

The bot is built with object.__new__ (bypassing __init__/SDK construction) and only the few
attributes the gate reads are stubbed (config, PB_modes, _candle_fetch_fails), so we exercise the
real method without any I/O. The gate is synchronous, so no asyncio is needed.
"""
import logging

import pytest

from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"


# --------------------------------------------------------------------------- #
# Builder
# --------------------------------------------------------------------------- #
def _gate_bot(modes, fails, *, enabled=True, max_fails=3, blocked=None):
    """A Passivbot with __init__ bypassed, stubbing only what _apply_data_staleness_modes /
    _data_staleness_cfg read."""
    bot = object.__new__(Passivbot)
    bot.PB_modes = modes
    bot._candle_fetch_fails = fails
    bot.config = {
        "live": {
            "data_staleness_enforcement": enabled,
            "max_consecutive_candle_fetch_fails": max_fails,
        }
    }
    if blocked is not None:
        bot._data_stale_blocked = blocked
    return bot


def _both(longmode, shortmode=None):
    """PB_modes dict with one symbol per side."""
    return {"long": {SYMBOL: longmode}, "short": {SYMBOL: shortmode or longmode}}


# --------------------------------------------------------------------------- #
# _data_staleness_cfg defaults / parsing
# --------------------------------------------------------------------------- #
def test_cfg_defaults_on_three():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {}}
    assert bot._data_staleness_cfg() == (True, 3)


def test_cfg_string_false_disables():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"data_staleness_enforcement": "false"}}
    enabled, _ = bot._data_staleness_cfg()
    assert enabled is False


def test_cfg_clamps_nonpositive_threshold():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"max_consecutive_candle_fetch_fails": 0}}
    assert bot._data_staleness_cfg() == (True, 1)


# --------------------------------------------------------------------------- #
# Gate behavior
# --------------------------------------------------------------------------- #
def test_below_threshold_modes_unchanged():
    bot = _gate_bot(_both("normal", "graceful_stop"), fails=2, max_fails=3)
    bot._apply_data_staleness_modes()
    assert bot.PB_modes == _both("normal", "graceful_stop")
    assert bot._data_stale_blocked is False


def test_at_threshold_blocks_entry_permitting_modes():
    bot = _gate_bot(_both("normal", "graceful_stop"), fails=3, max_fails=3)
    bot._apply_data_staleness_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["short"][SYMBOL] == "tp_only"
    assert bot._data_stale_blocked is True


def test_above_threshold_blocks():
    bot = _gate_bot(_both("normal"), fails=10, max_fails=3)
    bot._apply_data_staleness_modes()
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["short"][SYMBOL] == "tp_only"


def test_protected_modes_untouched():
    # tp_only / manual / panic place no entries already and must not be rewritten.
    modes = {"long": {SYMBOL: "manual"}, "short": {SYMBOL: "panic"}}
    bot = _gate_bot(modes, fails=99, max_fails=3)
    bot._apply_data_staleness_modes()
    assert bot.PB_modes["long"][SYMBOL] == "manual"
    assert bot.PB_modes["short"][SYMBOL] == "panic"


def test_disabled_is_noop():
    bot = _gate_bot(_both("normal"), fails=99, enabled=False)
    bot._apply_data_staleness_modes()
    assert bot.PB_modes == _both("normal")
    # method returns before touching _data_stale_blocked
    assert getattr(bot, "_data_stale_blocked", False) is False


def test_warns_once_on_transition(caplog):
    bot = _gate_bot(_both("normal"), fails=3, max_fails=3)
    with caplog.at_level(logging.WARNING):
        bot._apply_data_staleness_modes()  # False -> True: one warning
        bot._apply_data_staleness_modes()  # still blocked: no new warning
    warnings = [r for r in caplog.records if "[data-stale]" in r.getMessage()]
    assert len(warnings) == 1
    assert "halting NEW entries" in warnings[0].getMessage()


def test_recovery_reenables_and_logs(caplog):
    # Was blocked last cycle; fetches healthy now (fails reset to 0) -> recover.
    bot = _gate_bot(_both("normal"), fails=0, max_fails=3, blocked=True)
    with caplog.at_level(logging.INFO):
        bot._apply_data_staleness_modes()
    assert bot.PB_modes == _both("normal")  # not forced to tp_only
    assert bot._data_stale_blocked is False
    infos = [r for r in caplog.records if "[data-stale]" in r.getMessage()]
    assert len(infos) == 1
    assert "healthy again" in infos[0].getMessage()
