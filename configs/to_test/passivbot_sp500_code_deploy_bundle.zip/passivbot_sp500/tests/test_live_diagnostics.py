import asyncio

from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"


def _diagnostic_bot():
    bot = object.__new__(Passivbot)
    bot.config = {"live": {}}
    bot.exchange = "hyperliquid"
    bot.user = "test_user"
    bot.active_symbols = [SYMBOL]
    bot.positions = {
        SYMBOL: {
            "long": {"size": 0.0, "price": 0.0},
            "short": {"size": 0.0, "price": 0.0},
        }
    }
    bot.balance = 300.0
    bot.account_equity = 299.0
    bot.available_margin = 250.0
    bot.unrealized_pnl = -1.0
    bot._last_raw_ideal_orders_count = 0
    bot._last_order_filter_counts = {}
    bot._min_capital_blocked = set()
    bot._data_stale_blocked = False
    bot._ws_health_blocked = False
    bot.ws_enabled = True
    bot._ws_subscribed = True
    bot._health_ws_reconnects = 0
    bot._last_order_plan_summary_text = ""
    return bot


def test_engine_status_reports_idle_reason_and_capital_state():
    bot = _diagnostic_bot()

    status = bot._serialize_engine_status(
        actual_orders={SYMBOL: []},
        ideal_orders={},
        to_cancel=[],
        to_create=[],
        plan_summaries=[],
    )

    assert status["idle_reason"] == "strategy_no_entry"
    assert status["balance"] == 300.0
    assert status["account_equity"] == 299.0
    assert status["capital_state"]["risk_capital"] == 299.0
    assert status["capital_state"]["risk_capital_source"] == "account_equity"
    assert status["data_staleness_state"]["blocked"] is False


def test_engine_status_reports_data_staleness_idle_reason():
    bot = _diagnostic_bot()
    bot._data_stale_blocked = True
    bot._candle_fetch_fails = 3

    status = bot._serialize_engine_status(
        actual_orders={SYMBOL: []},
        ideal_orders={SYMBOL: []},
        to_cancel=[],
        to_create=[],
        plan_summaries=[],
    )

    assert status["idle_reason"] == "data_staleness_tp_only"
    assert status["data_staleness_state"]["blocked"] is True
    assert status["data_staleness_state"]["consecutive_failures"] == 3


def test_cancellation_prioritizes_camel_case_reduce_only_orders():
    bot = object.__new__(Passivbot)
    bot.debug_mode = False
    bot._health_orders_cancelled = 0
    bot.state_change_detected_by_symbol = set()
    bot.live_value = lambda key: 1
    bot.add_to_recent_order_cancellations = lambda order: None
    bot.log_order_action = lambda *args, **kwargs: None
    bot._log_order_action_summary = lambda *args, **kwargs: None
    bot.did_cancel_order = lambda ex, od: True
    bot.remove_order = lambda order, source=None: None
    seen = []

    async def execute_cancellations(orders):
        seen.extend(orders)
        return [{"id": order["id"], "symbol": order["symbol"], "status": "success"} for order in orders]

    bot.execute_cancellations = execute_cancellations
    orders = [
        {"id": "entry", "symbol": SYMBOL, "side": "buy", "position_side": "long"},
        {"id": "close", "symbol": SYMBOL, "side": "sell", "position_side": "long", "reduceOnly": True},
    ]

    asyncio.run(bot.execute_cancellations_parent(orders))

    assert [order["id"] for order in seen] == ["close"]
