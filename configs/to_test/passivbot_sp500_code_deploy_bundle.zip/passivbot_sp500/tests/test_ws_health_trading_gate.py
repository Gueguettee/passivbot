"""
Offline unit tests for the WS-health trading gate (live safety).

Part of the STANDARD suite: no network, no real account, no money. When the orderUpdates websocket
is dead and cannot reconnect for longer than the grace window, the bot must stop OPENING new trades
(initial AND DCA) so a fill-blind bot does not churn fast buys/sells on stale REST state (the ~$4
flash-loss failure mode). It does this by forcing every entry-permitting symbol ('normal' or
'graceful_stop') to 'tp_only' -- the only mode that blocks DCA on an open position -- while leaving
take-profit closes in place. It auto-recovers when the WS is healthy again.

The bot is built with object.__new__ (bypassing __init__/SDK construction); only the attributes
_apply_ws_health_modes reads are stubbed. Time is injected via now_ms so the grace window is
deterministic (no real clock).
"""
from passivbot import Passivbot

SYMBOL = "SP500/USDC:USDC"
GRACE_S = 30.0


def _bot(modes=None, ws_enabled=True, enforcement=True, grace=GRACE_S,
         subscribed=True, dead=False, unhealthy_since=0.0, was_blocked=False):
    bot = object.__new__(Passivbot)
    bot.config = {"live": {"ws_health_enforcement": enforcement, "ws_health_grace_s": grace}}
    bot.ws_enabled = ws_enabled
    bot._ws_subscribed = subscribed
    bot._ws_connection_dead = lambda: dead
    bot._ws_unhealthy_since_ms = unhealthy_since
    bot._ws_health_blocked = was_blocked
    bot.PB_modes = modes if modes is not None else {"long": {SYMBOL: "normal"}, "short": {}}
    return bot


# --------------------------------------------------------------------------- #
# Healthy WS -> never blocks
# --------------------------------------------------------------------------- #
def test_healthy_ws_no_downgrade():
    bot = _bot(subscribed=True, dead=False)
    bot._apply_ws_health_modes(now_ms=1_000_000.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"
    assert bot._ws_unhealthy_since_ms == 0.0
    assert bot._ws_health_blocked is False


def test_disabled_enforcement_no_downgrade():
    bot = _bot(subscribed=False, dead=True, enforcement=False, unhealthy_since=1.0)
    bot._apply_ws_health_modes(now_ms=10_000_000.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"


def test_ws_not_enabled_is_noop():
    bot = _bot(subscribed=False, dead=True, ws_enabled=False, unhealthy_since=1.0)
    bot._apply_ws_health_modes(now_ms=10_000_000.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"


# --------------------------------------------------------------------------- #
# Grace window
# --------------------------------------------------------------------------- #
def test_unhealthy_stamps_since_but_within_grace_no_downgrade():
    # First unhealthy observation: stamp the timestamp, but do not block yet.
    bot = _bot(subscribed=False, unhealthy_since=0.0)
    bot._apply_ws_health_modes(now_ms=1_000_000.0)
    assert bot._ws_unhealthy_since_ms == 1_000_000.0
    assert bot.PB_modes["long"][SYMBOL] == "normal"  # 0s elapsed < 30s grace
    assert bot._ws_health_blocked is False


def test_unhealthy_just_under_grace_no_downgrade():
    since = 1_000_000.0
    bot = _bot(subscribed=False, unhealthy_since=since)
    bot._apply_ws_health_modes(now_ms=since + GRACE_S * 1000.0 - 1.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"
    assert bot._ws_health_blocked is False


def test_unhealthy_beyond_grace_downgrades_normal_and_graceful_stop():
    since = 1_000_000.0
    modes = {
        "long": {SYMBOL: "normal", "A/USDC:USDC": "graceful_stop"},
        "short": {"B/USDC:USDC": "tp_only", "C/USDC:USDC": "manual", "D/USDC:USDC": "panic"},
    }
    bot = _bot(subscribed=False, unhealthy_since=since, modes=modes)
    bot._apply_ws_health_modes(now_ms=since + GRACE_S * 1000.0)
    # Entry-permitting modes -> tp_only; non-entry modes untouched.
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot.PB_modes["long"]["A/USDC:USDC"] == "tp_only"
    assert bot.PB_modes["short"]["B/USDC:USDC"] == "tp_only"   # already tp_only
    assert bot.PB_modes["short"]["C/USDC:USDC"] == "manual"
    assert bot.PB_modes["short"]["D/USDC:USDC"] == "panic"
    assert bot._ws_health_blocked is True


def test_dead_socket_beyond_grace_downgrades():
    # _ws_subscribed True but the socket is dead -> still unhealthy.
    since = 500.0
    bot = _bot(subscribed=True, dead=True, unhealthy_since=since)
    bot._apply_ws_health_modes(now_ms=since + GRACE_S * 1000.0 + 1.0)
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"


def test_probe_error_while_subscribed_does_not_block():
    # Probe/introspection failures are not definitive socket death and must not restart the bot.
    bot = _bot(subscribed=True, dead=False)

    def _raise_probe():
        raise RuntimeError("probe failed")

    bot._ws_connection_dead = _raise_probe
    bot._apply_ws_health_modes(now_ms=1_000_000.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"
    assert bot._ws_unhealthy_since_ms == 0.0
    assert bot._ws_health_blocked is False


def test_unsubscribed_still_blocks_when_probe_would_raise():
    # Subscription state alone is enough to mark unhealthy; no probe call is needed.
    since = 1_000_000.0
    bot = _bot(subscribed=False, unhealthy_since=since)

    def _raise_probe():
        raise RuntimeError("probe should not be called")

    bot._ws_connection_dead = _raise_probe
    bot._apply_ws_health_modes(now_ms=since + GRACE_S * 1000.0 + 1.0)
    assert bot.PB_modes["long"][SYMBOL] == "tp_only"
    assert bot._ws_health_blocked is True


# --------------------------------------------------------------------------- #
# Recovery
# --------------------------------------------------------------------------- #
def test_recovery_resets_timer_and_reenables():
    # Was blocked; WS healthy again -> reset timer, do not downgrade, log re-enable transition.
    bot = _bot(subscribed=True, dead=False, unhealthy_since=1_000_000.0, was_blocked=True)
    bot._apply_ws_health_modes(now_ms=2_000_000.0)
    assert bot._ws_unhealthy_since_ms == 0.0
    assert bot.PB_modes["long"][SYMBOL] == "normal"
    assert bot._ws_health_blocked is False


# --------------------------------------------------------------------------- #
# Enforcement-flag parsing (string "false" must disable the gate)
# --------------------------------------------------------------------------- #
def test_string_false_disables_gate():
    # bool("false") is True, so a string override must be parsed, not bool()-coerced.
    since = 1_000_000.0
    bot = _bot(subscribed=False, dead=True, enforcement="false", unhealthy_since=since)
    assert bot._ws_health_cfg()[0] is False
    bot._apply_ws_health_modes(now_ms=since + GRACE_S * 1000.0 + 1.0)
    assert bot.PB_modes["long"][SYMBOL] == "normal"  # gate disabled -> no downgrade


def test_enforcement_flag_parsing():
    assert _bot(enforcement=True)._ws_health_cfg()[0] is True
    assert _bot(enforcement=False)._ws_health_cfg()[0] is False
    assert _bot(enforcement="false")._ws_health_cfg()[0] is False
    assert _bot(enforcement="0")._ws_health_cfg()[0] is False
    assert _bot(enforcement="no")._ws_health_cfg()[0] is False
    assert _bot(enforcement="off")._ws_health_cfg()[0] is False
    assert _bot(enforcement="true")._ws_health_cfg()[0] is True
    assert _bot(enforcement="on")._ws_health_cfg()[0] is True
